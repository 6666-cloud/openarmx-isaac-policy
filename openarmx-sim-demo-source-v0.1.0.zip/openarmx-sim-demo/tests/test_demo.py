import ast
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DemoTests(unittest.TestCase):
    def test_syntax(self):
        for path in ROOT.rglob('*.py'):
            ast.parse(path.read_text(), filename=str(path))

    def test_local_module_closure(self):
        std = set(sys.stdlib_module_names)
        external = {'PIL', 'av', 'carb', 'h5py', 'imageio', 'isaacsim', 'numpy', 'omni', 'pxr', 'scipy'}
        local = {x.stem for x in (ROOT / 'expert').glob('*.py')}
        for path in (ROOT / 'expert').glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text())):
                names = [x.name.split('.')[0] for x in node.names] if isinstance(node, ast.Import) else (
                    [node.module.split('.')[0]] if isinstance(node, ast.ImportFrom) and node.module else [])
                self.assertFalse(set(names) - std - external - local, (path.name, names))

    def test_plan_ab(self):
        plans = []
        for variant in 'AB':
            r = subprocess.run([sys.executable, '-B', str(ROOT / 'scripts/demo.py'),
                                '--plan-only', '--variant', variant], capture_output=True, text=True, check=True)
            doc = json.loads(r.stdout)
            self.assertFalse(doc['simulation_started'])
            self.assertFalse(doc['training_eligible'])
            self.assertTrue(json.dumps(doc['instructions'], ensure_ascii=False).isascii())
            plans.append(doc)
        self.assertEqual(plans[0]['expected']['query_placements'], [['blue', 'P']])
        self.assertEqual(plans[1]['expected']['query_placements'], [['red', 'P']])

    def test_execution_needs_explicit_paths(self):
        r = subprocess.run([sys.executable, '-B', str(ROOT / 'scripts/demo.py')], capture_output=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn(b'explicit', r.stderr)

    def test_no_private_workstation_paths(self):
        for folder in ('expert', 'scripts'):
            for path in (ROOT / folder).glob('*.py'):
                text = path.read_text()
                self.assertNotRegex(text, r'/home/[^/\s]+/', path)
                self.assertNotIn('172.26.', text, path)
                self.assertNotIn("Path('/data/openarmx_isaac')", text, path)

    def test_asset_hash_and_path_escape_rejected(self):
        # Pure temporary data is unnecessary: mock the tiny manifest and file reads.
        from unittest.mock import patch
        spec = importlib.util.spec_from_file_location('demo_under_test', ROOT / 'scripts/demo.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with patch.object(Path, 'read_text', return_value=json.dumps({
                'schema': 'openarmx_ctx01_portable_assets_v1',
                'files': [{'path': 'README.md', 'bytes': 1, 'sha256': '0' * 64}]})):
            with self.assertRaisesRegex(ValueError, 'Asset changed'):
                module.verify_assets(ROOT)

    def test_source_hashes(self):
        import hashlib
        doc = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_text())
        for row in doc['files']:
            self.assertEqual(hashlib.sha256((ROOT / row['file']).read_bytes()).hexdigest(),
                             row['release_sha256'])

    def test_camera_config(self):
        doc = json.loads((ROOT / 'configs/context_camera_rig_pilot.json').read_text())
        self.assertEqual(set(doc['cameras']), {'chest', 'left_wrist', 'right_wrist'})
        self.assertEqual(doc['recording_fps'], 30)
        self.assertEqual(doc['camera_frequency'], -1)


if __name__ == '__main__':
    unittest.main()
