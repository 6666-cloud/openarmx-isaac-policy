import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'expert'))
"""CPU-only unit tests; no Isaac Sim import, renderer, robot or GPU required."""
import unittest
from unittest.mock import patch
import numpy as np
from scipy.spatial.transform import Rotation

from context_motion_planning import (
    MotionPlanningError, MotionPlanningTimeout, command_metrics, plan_cartesian, plan_sequence,
)


class CartesianFakeModel:
    lower = np.full(6, -10.0)
    upper = np.full(6, 10.0)

    def forward(self, q):
        transform = np.eye(4)
        transform[:3, 3] = q[:3]
        transform[:3, :3] = Rotation.from_rotvec(q[3:]).as_matrix()
        return transform

    def solve(self, position, rotation, seed):
        return np.r_[position, Rotation.from_matrix(rotation).as_rotvec()]


class MotionPlanningTests(unittest.TestCase):
    def setUp(self):
        self.model = CartesianFakeModel()
        self.start = np.zeros(6)
        self.goal = np.array([0.2, -0.1, 0.3])
        self.rotation = Rotation.from_euler('z', 0.6).as_matrix()

    def test_caps_retiming_endpoint_and_previous_command(self):
        trajectory, info = plan_cartesian(self.model, self.start, self.goal, self.rotation,
                                           0.10, velocity_cap=0.5, acceleration_cap=1.0)
        self.assertGreater(info['retime_count'], 0)
        self.assertGreater(info['duration_s'], 0.1)
        np.testing.assert_allclose(self.model.forward(trajectory[-1])[:3, 3], self.goal, atol=1e-10)
        np.testing.assert_allclose(self.model.forward(trajectory[-1])[:3, :3], self.rotation, atol=1e-10)
        metrics = command_metrics(self.start, trajectory, 30)
        self.assertLessEqual(metrics['peak_velocity_by_joint'].max(), 0.5 + 1e-8)
        self.assertLessEqual(metrics['peak_acceleration_by_joint'].max(), 1.0 + 1e-8)
        self.assertLessEqual(abs(trajectory[0] - self.start).max() * 30, 0.5 + 1e-8)
        self.assertFalse(info['collision_and_contact_validated'])
        self.assertGreaterEqual(info['planning_wall_seconds'], 0)
        self.assertEqual(info['max_planning_seconds'], 180.0)
        self.assertEqual(info['max_planning_thread_cpu_seconds'],45.0)

    def test_zero_endpoint_velocities_are_in_acceleration(self):
        metrics = command_metrics(np.array([0.0]), np.array([[0.01], [0.02]]), 10)
        self.assertAlmostEqual(metrics['peak_velocity_by_joint'][0], 0.1)
        self.assertAlmostEqual(metrics['peak_acceleration_by_joint'][0], 1.0)

    def test_zero_motion_is_finite(self):
        trajectory, info = plan_cartesian(self.model, self.start, [0, 0, 0], np.eye(3), 0.1)
        np.testing.assert_array_equal(trajectory, np.zeros_like(trajectory))
        self.assertEqual(info['retime_count'], 0)

    def test_per_joint_caps(self):
        caps = np.array([0.1, 0.2, 0.2, 0.3, 0.3, 0.3])
        trajectory, _ = plan_cartesian(self.model, self.start, self.goal, self.rotation, 1,
                                       velocity_cap=caps)
        self.assertTrue(np.all(command_metrics(self.start, trajectory, 30)['peak_velocity_by_joint'] <= caps + 1e-8))

    def test_ik_failure_is_fail_closed(self):
        class FailingModel(CartesianFakeModel):
            def solve(self, position, rotation, seed):
                if position[0] > 0.05:
                    raise RuntimeError('unreachable test region')
                return super().solve(position, rotation, seed)
        with self.assertRaisesRegex(MotionPlanningError, 'IK preflight failed'):
            plan_cartesian(FailingModel(), self.start, self.goal, self.rotation, 1)

    def test_invalid_solver_output_rejected(self):
        class BadModel(CartesianFakeModel):
            def solve(self, position, rotation, seed):
                return np.full(6, np.nan)
        with self.assertRaisesRegex(MotionPlanningError, 'invalid joint vector'):
            plan_cartesian(BadModel(), self.start, self.goal, self.rotation, 1)

    def test_finite_but_wrong_ik_solution_rejected(self):
        class WrongModel(CartesianFakeModel):
            def solve(self, position, rotation, seed):
                return np.zeros(6)
        with self.assertRaisesRegex(MotionPlanningError, 'IK pose residual exceeds tolerance'):
            plan_cartesian(WrongModel(), self.start, self.goal, self.rotation, 1)

    def test_invalid_inputs(self):
        changes = [dict(goal=[np.nan, 0, 0]), dict(R=np.ones((3, 3))), dict(duration=0),
                   dict(fps=-1), dict(velocity_cap=0), dict(acceleration_cap=np.nan),
                   dict(start_q=[0, 0]), dict(max_retimes=-1), dict(max_retimes=True),
                   dict(max_planning_seconds=0), dict(max_planning_seconds=np.inf),
                   dict(max_planning_seconds=True)]
        changes += [dict(max_planning_cpu_seconds=x) for x in (0,np.inf,True)]
        for changed in changes:
            arguments = dict(model=self.model, start_q=self.start, goal=self.goal,
                             R=self.rotation, duration=1)
            arguments.update(changed)
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                plan_cartesian(**arguments)

    def test_joint_limits_rejected(self):
        with self.assertRaisesRegex(ValueError, 'outside model joint limits'):
            plan_cartesian(self.model, np.full(6, 20), self.goal, self.rotation, 1)

    def test_retime_budget_is_bounded(self):
        with self.assertRaises(MotionPlanningError):
            plan_cartesian(self.model, self.start, self.goal, self.rotation, 0.1,
                           velocity_cap=0.001, max_duration=1)
        with self.assertRaises(MotionPlanningError):
            plan_cartesian(self.model, self.start, self.goal, self.rotation, 0.1,
                           velocity_cap=0.001, max_retimes=0)

    def test_sequence_continuity_and_failure(self):
        segments = [dict(label='first', goal=self.goal, R=self.rotation, duration=2),
                    dict(label='second', goal=[0, 0, 0], R=np.eye(3), duration=2)]
        trajectories, metadata = plan_sequence(self.model, self.start, segments)
        self.assertEqual(len(trajectories), 2)
        self.assertEqual(metadata[1]['label'], 'second')
        self.assertEqual(metadata[0]['sequence_planning_wall_seconds'],
                         metadata[1]['sequence_planning_wall_seconds'])
        self.assertEqual(metadata[1]['sequence_max_planning_seconds'], 180.0)
        self.assertEqual(metadata[1]['sequence_max_planning_thread_cpu_seconds'],45.0)
        m = command_metrics(trajectories[0][-1], trajectories[1], 30)
        self.assertLessEqual(m['peak_acceleration_by_joint'].max(), 5 + 1e-8)
        with self.assertRaises(ValueError):
            plan_sequence(self.model, self.start, [])

    def test_deadline_checked_immediately_after_nonpreemptible_ik(self):
        clock = [0.0]
        class SlowModel(CartesianFakeModel):
            calls = 0
            def solve(self, position, rotation, seed):
                self.calls += 1
                clock[0] += 0.11
                return super().solve(position, rotation, seed)
        model = SlowModel()
        with patch('context_motion_planning.time.monotonic', side_effect=lambda: clock[0]):
            with self.assertRaisesRegex(MotionPlanningError, 'wall-time budget exceeded.*after IK'):
                plan_cartesian(model, self.start, [0, 0, 0], np.eye(3), 1,
                               max_planning_seconds=0.2)
        self.assertEqual(model.calls, 2)

    def test_deadline_is_shared_across_retimes(self):
        clock = [0.0]
        class TimedModel(CartesianFakeModel):
            calls = 0
            def solve(self, position, rotation, seed):
                self.calls += 1
                clock[0] += 0.01
                return super().solve(position, rotation, seed)
        model = TimedModel()
        with patch('context_motion_planning.time.monotonic', side_effect=lambda: clock[0]):
            with self.assertRaisesRegex(MotionPlanningError, 'wall-time budget exceeded.*attempt 1'):
                plan_cartesian(model, self.start, self.goal, self.rotation, 0.1,
                               velocity_cap=0.5, max_planning_seconds=0.035)
        self.assertEqual(model.calls, 4)

    def test_sequence_uses_one_total_wall_budget(self):
        clock = [0.0]
        class TimedModel(CartesianFakeModel):
            calls = 0
            def solve(self, position, rotation, seed):
                self.calls += 1
                clock[0] += 0.1
                return super().solve(position, rotation, seed)
        model = TimedModel()
        segments = [dict(goal=[0, 0, 0], R=np.eye(3), duration=0.2) for _ in range(2)]
        with patch('context_motion_planning.time.monotonic', side_effect=lambda: clock[0]):
            with self.assertRaisesRegex(MotionPlanningTimeout, 'wall-time budget exceeded in sequence segment 1'):
                plan_sequence(model, self.start, segments, fps=10, max_planning_seconds=0.35)
        self.assertEqual(model.calls, 4)
        with self.assertRaises(ValueError):
            plan_sequence(model, self.start, segments, max_planning_seconds=0)

    def test_cpu_budget_not_reset_between_retimes(self):
        cpu=[0.0]
        class TimedModel(CartesianFakeModel):
            calls=0
            def solve(self,position,rotation,seed):
                self.calls+=1;cpu[0]+=.01
                return super().solve(position,rotation,seed)
        model=TimedModel()
        with patch('context_motion_planning.time.thread_time',side_effect=lambda:cpu[0]),\
             patch('context_motion_planning.time.monotonic',return_value=0.0),\
             self.assertRaisesRegex(MotionPlanningTimeout,'thread-CPU budget exceeded.*attempt 1'):
            plan_cartesian(model,self.start,self.goal,self.rotation,.1,velocity_cap=.5,
                           max_planning_cpu_seconds=.035)
        self.assertEqual(model.calls,4)

    def test_scheduler_wait_does_not_consume_cpu_budget_but_wall_is_finite(self):
        wall=[0.0]
        class DescheduledModel(CartesianFakeModel):
            calls=0
            def solve(self,position,rotation,seed):
                self.calls+=1;wall[0]+=30
                return super().solve(position,rotation,seed)
        model=DescheduledModel()
        with patch('context_motion_planning.time.thread_time',return_value=0.0),\
             patch('context_motion_planning.time.monotonic',side_effect=lambda:wall[0]):
            path,info=plan_cartesian(model,self.start,[0,0,0],np.eye(3),.2,fps=10)
            self.assertEqual(info['planning_wall_seconds'],60.0)
            self.assertEqual(info['planning_thread_cpu_seconds'],0.0)
            with self.assertRaisesRegex(MotionPlanningTimeout,'wall-time budget exceeded.*after IK'):
                plan_cartesian(model,self.start,[0,0,0],np.eye(3),1,fps=10)
        self.assertEqual(model.calls,8)

    def test_sequence_cpu_budget_shared(self):
        cpu=[0.0]
        class TimedModel(CartesianFakeModel):
            def solve(self,position,rotation,seed):
                cpu[0]+=.1
                return super().solve(position,rotation,seed)
        with patch('context_motion_planning.time.thread_time',side_effect=lambda:cpu[0]),\
             patch('context_motion_planning.time.monotonic',return_value=0.0),\
             self.assertRaisesRegex(MotionPlanningTimeout,'thread-CPU budget exceeded in sequence segment 1'):
            plan_sequence(TimedModel(),self.start,
                [dict(goal=[0,0,0],R=np.eye(3),duration=.2) for _ in range(2)],
                fps=10,max_planning_cpu_seconds=.35)


if __name__ == '__main__':
    unittest.main(verbosity=2)
