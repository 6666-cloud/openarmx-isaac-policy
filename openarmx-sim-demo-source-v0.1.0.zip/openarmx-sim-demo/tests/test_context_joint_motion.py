import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'expert'))
"""Pure CPU regression tests; fake kinematics only, no simulation or hardware."""
import unittest
from unittest.mock import patch

import numpy as np
from scipy.spatial.transform import Rotation

from context_joint_motion import MotionPlanningError, plan_joint_reorientation
from context_motion_planning import command_metrics


class LinearArm:
    def __init__(self):
        self.lower = np.full(6, -4.)
        self.upper = np.full(6, 4.)
        self.solve_calls = 0

    def forward(self, q):
        transform = np.eye(4)
        transform[:3, 3] = q[:3]
        transform[:3, :3] = Rotation.from_rotvec(q[3:]).as_matrix()
        return transform

    def solve(self, goal, R, seed):
        self.solve_calls += 1
        self.last_seed = seed.copy()
        return np.r_[goal, Rotation.from_matrix(R).as_rotvec()]


class JointMotionTests(unittest.TestCase):
    def plan(self, model=None, **updates):
        args = dict(model=model or LinearArm(), start_q=np.array([.28, .17, .38, 0, 0, 0]),
                    goal=np.array([.30, .18, .39]), R=Rotation.from_rotvec([.5, -.2, .1]).as_matrix(),
                    duration=.2, corridor_min=[.24, .12, .34], corridor_max=[.35, .22, .43])
        args.update(updates)
        return plan_joint_reorientation(**args)

    def test_single_ik_caps_endpoint_and_metadata(self):
        arm = LinearArm()
        q, meta = self.plan(arm)
        self.assertEqual(arm.solve_calls, 1)
        self.assertGreater(meta['retime_count'], 0)
        metrics = command_metrics(arm.last_seed, q, 30)
        self.assertLessEqual(max(metrics['peak_velocity_by_joint']), 1.5 + 1e-8)
        self.assertLessEqual(max(metrics['peak_acceleration_by_joint']), 5 + 1e-8)
        np.testing.assert_allclose(q[-1, :3], [.30, .18, .39])
        self.assertEqual(meta['corridor_sample_count'], len(q) + 1)
        self.assertEqual(meta['required_final_hold_frames_min'], 1)
        self.assertFalse(meta['collision_and_contact_validated'])
        self.assertFalse(meta['hardware_deployment_validated'])

    def test_exact_corridor_and_joint_boundaries(self):
        arm = LinearArm()
        arm.lower[:3] = [.24, .12, .34]
        arm.upper[:3] = [.35, .22, .43]
        q, _ = self.plan(arm, start_q=[.24, .12, .34, 0, 0, 0], goal=[.35, .22, .43], R=np.eye(3))
        np.testing.assert_allclose(q[-1], [.35, .22, .43, 0, 0, 0])

    def test_negative_y_corridor(self):
        q, _ = self.plan(start_q=[.28, -.17, .38, 0, 0, 0], goal=[.30, -.18, .39],
                         corridor_min=[.24, -.22, .34], corridor_max=[.35, -.12, .43])
        self.assertTrue(np.all(q[:, 1] < 0))

    def test_stationary_segment_and_input_not_mutated(self):
        start = np.array([.28, .17, .38, 0, 0, 0]); original = start.copy()
        q, meta = self.plan(start_q=start, goal=start[:3], R=np.eye(3))
        np.testing.assert_array_equal(start, original)
        np.testing.assert_array_equal(q, np.broadcast_to(start, q.shape))
        self.assertEqual(max(meta['peak_acceleration_by_joint']), 0)

    def test_invalid_inputs(self):
        cases = [dict(start_q=[]), dict(start_q=[np.nan] * 6), dict(goal=[0, 0]),
                 dict(R=np.zeros((3, 3))), dict(duration=0), dict(fps=True),
                 dict(velocity_cap=True), dict(acceleration_cap=[1, 2]),
                 dict(corridor_min=[.36, .12, .34]), dict(corridor_max=[np.inf, 1, 1]),
                 dict(max_retimes=-1), dict(max_frames=1), dict(position_tolerance=.007),
                 dict(rotation_tolerance=.09), dict(max_planning_seconds=0)]
        for case in cases:
            with self.subTest(case=case), self.assertRaises(ValueError):
                self.plan(**case)

    def test_joint_limit_and_start_goal_corridor_failures(self):
        with self.assertRaises(MotionPlanningError):
            self.plan(start_q=[5, .17, .38, 0, 0, 0])
        with self.assertRaises(MotionPlanningError):
            self.plan(start_q=[.23, .17, .38, 0, 0, 0])
        with self.assertRaises(MotionPlanningError):
            self.plan(goal=[.36, .18, .39])
        arm = LinearArm(); arm.upper[3:] = .1
        with self.assertRaises(MotionPlanningError):
            self.plan(arm)
        arm = LinearArm(); arm.lower = None
        with self.assertRaises(ValueError):
            self.plan(arm)

    def test_wrong_endpoint_ik_fails_closed(self):
        for bad in [np.array([.31, .18, .39, .5, -.2, .1]),
                    np.array([.30, .18, .39, 0, 0, 0]), np.full(6, np.nan), np.zeros(5)]:
            arm = LinearArm()
            with patch.object(arm, 'solve', return_value=bad), self.assertRaises(MotionPlanningError):
                self.plan(arm)

    def test_intermediate_fk_corridor_violation(self):
        class CurvedArm(LinearArm):
            def forward(self, q):
                t = super().forward(q)
                t[1, 3] += .1 * np.sin(np.pi * q[3])
                return t
        with self.assertRaisesRegex(MotionPlanningError, 'corridor'):
            self.plan(CurvedArm(), goal=[.28, .17, .38], R=Rotation.from_rotvec([1., 0, 0]).as_matrix())

    def test_invalid_fk_and_ik_exception(self):
        arm = LinearArm()
        with patch.object(arm, 'forward', return_value=np.full((4, 4), np.nan)), self.assertRaises(MotionPlanningError):
            self.plan(arm)
        with patch.object(arm, 'solve', side_effect=RuntimeError('unreachable')), self.assertRaises(MotionPlanningError):
            self.plan(arm)

    def test_nonpreemptible_ik_deadline_checked_after_call(self):
        arm = LinearArm(); clock = [0.]
        solve = arm.solve
        def slow(goal, R, seed):
            clock[0] = 46.
            return solve(goal, R, seed)
        with patch('context_joint_motion.time.monotonic', side_effect=lambda: clock[0]), \
             patch.object(arm, 'solve', side_effect=slow), self.assertRaisesRegex(MotionPlanningError, 'after endpoint IK'):
            self.plan(arm)

    def test_retime_and_allocation_budgets(self):
        for case in [dict(max_retimes=0), dict(max_duration=.2), dict(max_frames=3), dict(duration=121)]:
            with self.subTest(case=case), self.assertRaises(MotionPlanningError):
                self.plan(**case)


if __name__ == '__main__':
    unittest.main()
