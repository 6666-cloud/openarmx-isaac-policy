"""Visual-only white worktop and broad neutral lighting for the context suite.

No new physical table/cloth, collider, friction, object transform or camera
calibration is introduced. The white finish approximates the user's worktop;
the soft lights are a simulation appearance preset, not measured photometry.
"""
from copy import deepcopy


APPEARANCE_VERSION = 'white_matte_soft_neutral_v2'
TABLE_TOP = '/world/table/table_01/top'
MATERIAL = '/world/Looks/ContextWhiteMatteWorktop'
PROFILE = {
    'version': APPEARANCE_VERSION,
    'table': {'prim': TABLE_TOP, 'material': MATERIAL,
              'diffuse_color_linear': [0.90, 0.90, 0.90],
              'roughness': 0.90, 'metallic': 0.0, 'ior': 1.35,
              'shader_workflow': 'UsdPreviewSurface dielectric metallic workflow',
              'texture': None, 'finish': 'neutral matte white'},
    'lights': {'environment_intensity': 1100.0,
               'old_distant_key_enabled': False,
               'softboxes': [
                   {'name': 'Top', 'position_m': [0.45, 0.0, 1.8],
                    'size_m': [1.6, 1.6], 'intensity': 250.0},
                   {'name': 'LeftFill', 'position_m': [0.45, 0.8, 1.5],
                    'size_m': [1.1, 1.1], 'intensity': 125.0},
                   {'name': 'RightFill', 'position_m': [0.45, -0.8, 1.5],
                    'size_m': [1.1, 1.1], 'intensity': 125.0}],
               'color_linear': [1.0, 1.0, 1.0],
               'contact_shadows_retained': True},
    'physics_changed': False,
    'real_photometric_calibration': False,
    'scope': 'White visual finish and reduced directional shadow contrast; no cloth physics or real lighting calibration',
}


def apply_scene_appearance(stage):
    """Author local overrides only; leave referenced asset files unchanged."""
    from pxr import Gf, Sdf, UsdGeom, UsdLux, UsdShade
    tabletop = stage.GetPrimAtPath(TABLE_TOP)
    if not tabletop or not tabletop.IsActive() or not tabletop.IsA(UsdGeom.Gprim):
        raise ValueError('Expected the existing active physical table-top Gprim: ' + TABLE_TOP)
    material = UsdShade.Material.Define(stage, MATERIAL)
    shader = UsdShade.Shader.Define(stage, MATERIAL + '/Surface')
    shader.CreateIdAttr('UsdPreviewSurface')
    shader.CreateInput('diffuseColor', Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*PROFILE['table']['diffuse_color_linear']))
    for name in ('roughness', 'metallic', 'ior'):
        shader.CreateInput(name, Sdf.ValueTypeNames.Float).Set(PROFILE['table'][name])
    shader.CreateOutput('surface', Sdf.ValueTypeNames.Token)
    material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), 'surface')
    UsdShade.MaterialBindingAPI.Apply(tabletop).Bind(material,
        bindingStrength=UsdShade.Tokens.strongerThanDescendants)
    UsdGeom.Gprim(tabletop).CreateDisplayColorAttr([Gf.Vec3f(*PROFILE['table']['diffuse_color_linear'])])

    key = stage.GetPrimAtPath('/world/KeyLight')
    if key:
        key.SetActive(False)
    dome = UsdLux.DomeLight.Define(stage, '/world/EnvironmentLight')
    dome.GetPrim().SetActive(True)
    dome.CreateIntensityAttr(PROFILE['lights']['environment_intensity'])
    dome.CreateExposureAttr(0.0)
    dome.CreateColorAttr(Gf.Vec3f(1.0))
    dome.CreateEnableColorTemperatureAttr(False)
    UsdLux.ShadowAPI.Apply(dome.GetPrim()).CreateShadowEnableAttr(True)
    # An inherited HDRI would reintroduce a sharp directional key.
    dome.CreateTextureFileAttr(Sdf.AssetPath(''))
    for light in PROFILE['lights']['softboxes']:
        rect = UsdLux.RectLight.Define(stage, '/world/ContextSoftLights/' + light['name'])
        rect.CreateWidthAttr(light['size_m'][0])
        rect.CreateHeightAttr(light['size_m'][1])
        rect.CreateIntensityAttr(light['intensity'])
        rect.CreateExposureAttr(0.0)
        rect.CreateColorAttr(Gf.Vec3f(1.0))
        rect.CreateEnableColorTemperatureAttr(False)
        UsdLux.ShadowAPI.Apply(rect.GetPrim()).CreateShadowEnableAttr(True)
        transform = UsdGeom.Xformable(rect)
        transform.ClearXformOpOrder()
        transform.AddTransformOp().Set(Gf.Matrix4d().SetLookAt(
            Gf.Vec3d(*light['position_m']), Gf.Vec3d(0.40, 0, 0.30),
            Gf.Vec3d(0, 1, 0)).GetInverse())
    return deepcopy(PROFILE)
