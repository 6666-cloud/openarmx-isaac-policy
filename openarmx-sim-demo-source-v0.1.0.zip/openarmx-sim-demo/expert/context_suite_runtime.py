"""Physical full-task expert; task plans and oracle checks never enter policy inputs.

Loaded only after SimulationApp by run_context_collection.py --suite. Objects
move through contact forces: no attachments, mid-episode pose resets or kinematic
object animation. Every operation fails closed on physical verification failure.
"""
import json
import time
import numpy as np
from scipy.spatial.transform import Rotation
from context_motion_planning import MotionPlanningError, plan_cartesian, plan_sequence
from context_joint_motion import plan_joint_reorientation
from context_grasp_geometry import load_finger_geometry, plan_block_bowl_regrasp
from context_push_geometry import derive_push_geometry, measured_finger_openings, load_bounding_cube_world_vertices
from context_bowl_exit import (build_bowl_exit_segments, check_measured_bowl_exit,
                               check_rim_crossing, held_vertices_in_tcp, BowlExitError)
from context_stable_block_return import (plan_stable_block_return, measured_grasp,
                                         landing_geometry, StableReturnError)
from context_container_geometry import contains_xy_compatible
from context_table_block_yaw import initial_table_block_yaw


def episode_class(base):
    class SuiteEpisode(base.Episode):
        def __init__(self, stage, config):
            super().__init__(stage, config)
            self.plan = config['protocol_plan']
            self.held = None
            self.operation_results = []
            self.locations = {name: 'initial:' + name for name in self.objects}
            self.geometry = {}
            self.finger_geometry = {}
            cache = base.UsdGeom.XformCache()
            for name, path in config['objects'].items():
                root = stage.GetPrimAtPath(path)
                pieces = []
                for prim in base.Usd.PrimRange(root):
                    if prim.IsA(base.UsdGeom.Mesh):
                        points = np.asarray(base.UsdGeom.Mesh(prim).GetPointsAttr().Get(), dtype=float)
                        matrix = np.array(cache.ComputeRelativeTransform(prim, root)[0]).T
                        pieces.append(points @ matrix[:3, :3].T + matrix[:3, 3])
                if pieces:
                    points = np.concatenate(pieces)
                else:
                    bounds = base.UsdGeom.BBoxCache(0, ['default', 'render']).ComputeUntransformedBound(root).ComputeAlignedRange()
                    lo, hi = bounds.GetMin(), bounds.GetMax()
                    points = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
                scale = np.asarray(config['parameters'][name].get('applied_scale', config['parameters'][name].get('scale', 1.0)))
                self.geometry[name] = points * scale
            np.savez_compressed(base.args.output / 'local_geometry.npz', **self.geometry)
            self.recorder.demo.attrs['support_surface_names'] = json.dumps(list(config['support_paths']))
            self.recorder.demo.attrs['suite_protocol'] = json.dumps(self.plan)
            self.recorder.demo.attrs['supervision_note'] = 'Unspecified expert demonstration prefixes are visible history but action_loss_mask=0.'
            self.recorder.demo.attrs['layout_mirror'] = False

        def object_vertices(self, name):
            p, q = self.objects[name].get_world_pose()
            return Rotation.from_quat(np.r_[q[1:], q[0]]).apply(self.geometry[name]) + p

        def step(self, target):
            result = super().step(target)
            guard = getattr(self, '_loaded_exit_guard', None)
            if guard is not None:
                # Includes hold/settle frames, not only Cartesian motion loops.
                # This is still 30 Hz evidence, not every 240 Hz substep.
                guard()
                self.verify_held()
            return result

        def move(self, side, goal, duration, orientation=None, phase='move'):
            rotation = self.down if orientation is None else orientation
            ids = self.arm_ids[side]
            # The original CTX01 empty final-home pair38 needs a seventh
            # sampling/IK retime. Retain every original pose/derivative/collision
            # cap and the original CPU/wall budget; no other motion is changed.
            options = ({'max_retimes': 12}
                       if self.config['task'] == 'CTX01' and self.held is None
                       and phase == side + '_home' else {})
            trajectory, metadata = plan_cartesian(
                self.models[side], self.target[ids], goal, rotation, self.sampled_duration(duration),
                fps=base.FPS, **options)
            self.execute_motion(side, goal, trajectory, metadata, phase)

        def sampled_duration(self, duration):
            sample = self.config.get('episode_sampling')
            name = self.active_color
            if sample is None or name is None:
                return duration
            from context_episode_sampling import slowed_duration
            return slowed_duration(duration, sample['objects'][name])

        def sampled_outside_pick(self, point):
            name = self.active_color
            sample = self.config.get('episode_sampling')
            if (sample is None or name is None or self.config['task'] == 'CTX08'
                    or abs(point[1]) < .12 or self.locations.get(name) != 'initial:' + name):
                return None
            return sample['objects'][name]

        def move_reference_to_waiting(self, side, goal, rotation):
            """Empty-hand, endpoint-constrained startup motion, not a task action.

            The reference wrists are oblique. Straight Cartesian interpolation
            exhausted the existing IK preflight budget without issuing commands.
            Use the existing bounded quintic joint planner instead; never relax
            the contact/tracking gates or overwrite live joint positions.
            """
            if self.held or not self.config.get('reference_start_pose') or side not in ('left', 'right'):
                raise RuntimeError('Reference preparation requires a named side, explicit profile and empty hands')
            if not {'robot_table', 'robot_torso', 'arm_arm'} <= self.suite_collision_views.keys():
                raise RuntimeError('Reference preparation requires native collision sensors')
            lower = [.07, .08 if side == 'left' else -.30, .32]
            upper = [.36, .30 if side == 'left' else -.08, .52]
            q0 = self.target[self.arm_ids[side]].copy()
            trajectory, metadata = plan_joint_reorientation(
                self.models[side], q0, goal, rotation, 3.0, fps=base.FPS,
                corridor_min=lower, corridor_max=upper)
            # Conservative native mesh AABBs of the hand and both fingers,
            # transformed using joint-frame FK at every command. This is only
            # sampled distal-link table clearance, not an all-body certificate.
            from inspect_context_start_pose import native_usd_tree, body_mesh_bounds
            boxes = {}
            for suffix in ('hand', 'left_finger', 'right_finger'):
                path = '/world/OpenArmX/openarmx_' + side + '_' + suffix
                bounds = body_mesh_bounds(self.stage, path, np.eye(4))
                lo, hi = bounds['min_xyz_m'], bounds['max_xyz_m']
                boxes[path] = np.array([[x, y, z, 1.] for x in (lo[0], hi[0])
                    for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
            named = dict(zip(self.names, self.target.tolist()))
            minimum_z = float('inf')
            for q in np.vstack([q0, trajectory]):
                poses, _ = native_usd_tree(self.stage, {**named, **dict(zip(self.models[side].names, q))})
                minimum_z = min(minimum_z, *[(corners @ poses[path].T)[:, 2].min()
                    for path, corners in boxes.items()])
            margin = minimum_z - self.config['tabletop']
            if margin < .008:
                raise RuntimeError(f'Reference preparation distal-link table clearance too small: {margin:.6f} m')
            metadata['reference_distal_table_preflight'] = {
                'minimum_z_m': float(minimum_z), 'tabletop_m': self.config['tabletop'],
                'minimum_clearance_m': float(margin), 'required_clearance_m': .008,
                'sample_count': len(trajectory) + 1,
                'scope': 'Native hand/finger mesh AABB FK samples only; all-body actual contacts remain runtime gates',
                'hardware_calibrated': False}
            self.execute_motion(side, goal, trajectory, metadata, 'reference_start_to_waiting_' + side)

        def reorientation_plan(self, side, q, goal, rotation, duration, *, sample_duration=True, **kwargs):
            lower = [0.24, 0.12 if side == 'left' else -0.23, 0.34]
            upper = [0.36, 0.23 if side == 'left' else -0.12, 0.43]
            return plan_joint_reorientation(self.models[side], q, goal, rotation,
                                            self.sampled_duration(duration) if sample_duration else duration,
                                            fps=base.FPS, corridor_min=lower, corridor_max=upper, **kwargs)

        def reorient(self, side, goal, rotation, duration, phase):
            trajectory, metadata = self.reorientation_plan(side, self.target[self.arm_ids[side]], goal, rotation, duration)
            if self.held:
                # Planning projection only: the object is NOT attached or moved
                # by this transform. Actual motion remains contact-driven.
                name = self.held['object']
                p, quat = self.objects[name].get_world_pose()
                obj = np.eye(4)
                obj[:3, :3] = Rotation.from_quat(np.r_[quat[1:], quat[0]]).as_matrix()
                obj[:3, 3] = p
                relative = np.linalg.inv(self.models[side].forward(self.robot.get_joint_positions()[self.arm_ids[side]])) @ obj
                bottom = float('inf')
                for joints in trajectory:
                    predicted = self.models[side].forward(joints) @ relative
                    vertices = self.geometry[name] @ predicted[:3, :3].T + predicted[:3, 3]
                    bottom = min(bottom, float(vertices[:, 2].min()))
                if bottom < self.config['tabletop'] + 0.005:
                    raise RuntimeError(f'Held object prealignment would enter tabletop clearance: bottom={bottom}')
                metadata['predicted_carried_bottom_m'] = bottom
            self.execute_motion(side, goal, trajectory, metadata, phase)
            if self.held:
                self.verify_held()

        def execute_motion(self, side, goal, trajectory, metadata, phase):
            ids = self.arm_ids[side]
            self.event('motion_preflight', side=side, phase=phase, goal=list(np.asarray(goal, dtype=float)), **metadata)
            self.phase = phase
            for joints in trajectory:
                target = self.target.copy()
                target[ids] = joints
                self.step(target)
            self.hold(0.15, phase + '_settle')
            error = float(np.max(np.abs(self.robot.get_joint_positions()[ids] - self.target[ids])))
            expected = self.models[side].forward(self.target[ids])
            expected_quat = Rotation.from_matrix(expected[:3, :3]).as_quat()
            position, quaternion = self.tips[side].get_world_pose()
            actual_rotation = Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix()
            position_error = float(np.linalg.norm(position - np.asarray(goal)))
            commanded_error = float(np.linalg.norm(position - expected[:3, 3]))
            rotation_error = float(Rotation.from_matrix(expected[:3, :3].T @ actual_rotation).magnitude())
            limits = {'position_m': 0.01, 'rotation_rad': 0.08, 'joint_rad': 0.08}
            self.event('motion_tracking', side=side, phase=phase, goal=list(np.asarray(goal, dtype=float)),
                       commanded_tcp_pose_wxyz=np.r_[expected[:3, 3], expected_quat[3], expected_quat[:3]].tolist(),
                       actual_tcp_pose_wxyz=np.r_[position, quaternion].tolist(),
                       position_error_m=position_error, commanded_position_error_m=commanded_error,
                       rotation_error_rad=rotation_error, joint_error_rad=error, thresholds=limits)
            if (error > limits['joint_rad'] or position_error > limits['position_m']
                    or commanded_error > limits['position_m'] or rotation_error > limits['rotation_rad']):
                raise RuntimeError(f'{side} failed to track planned motion {phase}: '
                                   f'joint={error:.4f}rad TCP={position_error:.4f}m rotation={rotation_error:.4f}rad')

        def pick_orientation(self, side, point, preferred, front_shared=False, bowl_block_regrasp=False, strict_pitch=False, grasp_yaw=0.0, preserve_table_yaw=False):
            if (not np.isfinite(grasp_yaw) or abs(grasp_yaw) > .12
                    or (grasp_yaw != 0.0 and (bowl_block_regrasp or strict_pitch or front_shared
                                             or abs(point[1]) < .12))):
                raise ValueError('Yaw-aligned pick requires the reviewed outside-table candidate')
            if preserve_table_yaw and (self.config.get('task') != 'CTX01' or preferred != 0.0
                    or bowl_block_regrasp or strict_pitch or front_shared or abs(point[1]) < .12):
                raise ValueError('CTX01 yaw-preserving grasp is reviewed only at zero wrist pitch')
            central = abs(point[1]) < 0.12
            approach = point + [0, 0, 0.025 if bowl_block_regrasp else (0.05 if central else 0.065)]
            lift = point + [0, 0, 0.04 if bowl_block_regrasp else (0.055 if central else 0.07)]
            sampled_pick = self.sampled_outside_pick(point)
            if sampled_pick is not None and not central and not bowl_block_regrasp:
                lift = point + [0, 0, sampled_pick['lift_height_m']]
            bridge_y = float(self.config.get('container_bridge_abs_y', .15))
            bridge = np.array([0.30, bridge_y if side == 'left' else -bridge_y, 0.38])
            inner = np.array([0.30, 0.06 if side == 'left' else -0.06, 0.38]) if front_shared else None
            failures = []
            # Do not let the CTX01 yaw-preserving candidate silently fall back
            # to a steep grip whose old table-return path reorients at yaw=0.
            pitches = [preferred] if preserve_table_yaw or bowl_block_regrasp or strict_pitch else ([-1.1] if front_shared else dict.fromkeys([preferred, 0.0, -0.2, -0.4, -0.7, -0.9]))
            for pitch in pitches:
                rotation = Rotation.from_euler('xyz', [np.pi, pitch, grasp_yaw]).as_matrix()
                segments = []
                if central:
                    segments.append({'goal': bridge, 'R': self.down, 'duration': 0.8, 'label': 'empty_entry_bridge'})
                    segments.append({'goal': bridge, 'R': rotation, 'duration': 1.5, 'label': 'empty_prealign'})
                if inner is not None:
                    segments.append({'goal': inner, 'R': rotation, 'duration': 1.0, 'label': 'front_inner_entry'})
                segments += [{'goal': p, 'R': rotation, 'duration': d, 'label': label}
                             for p, d, label in [(approach, 1.0, 'approach'), (point, 1.1, 'descend'), (lift, 0.9, 'lift')]]
                if inner is not None:
                    segments.append({'goal': inner, 'R': rotation, 'duration': 1.0, 'label': 'front_inner_exit'})
                exit_plan = None
                if bowl_block_regrasp:
                    exit_plan = build_bowl_exit_segments(side, lift, rotation,
                        bridge=bridge, neutral=self.config['held_neutral'][side])
                    segments.extend(exit_plan['segments'])
                elif central:
                    segments.append({'goal': bridge, 'R': rotation, 'duration': 0.8, 'label': 'held_exit_bridge'})
                if exit_plan is None:
                    segments.append({'goal': self.config['held_neutral'][side], 'R': rotation, 'duration': 1.1, 'label': 'held_neutral'})
                try:
                    deadline = time.monotonic() + 45.0
                    previous = self.target[self.arm_ids[side]].copy()
                    for segment in segments:
                        budget = deadline - time.monotonic()
                        if budget <= 0:
                            raise MotionPlanningError('Complete pick preflight exceeded 45 seconds')
                        if segment['label'] == 'empty_prealign' or segment.get('kind') == 'joint_reorientation':
                            path, _ = self.reorientation_plan(side, previous, segment['goal'], segment['R'],
                                                               segment['duration'], max_planning_seconds=budget)
                        else:
                            path, _ = plan_cartesian(self.models[side], previous, segment['goal'], segment['R'],
                                                     self.sampled_duration(segment['duration']), fps=base.FPS, max_planning_seconds=budget)
                        previous = path[-1]
                    return rotation, approach, lift, bridge if central else None, inner, exit_plan
                except MotionPlanningError as exc:
                    failures.append(f'pitch={pitch}: {exc}')
            raise RuntimeError('No complete pick trajectory: ' + '; '.join(failures))

        def native_block_vertices(self, name):
            position, quaternion = self.objects[name].get_world_pose()
            rotation = Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix()
            if not hasattr(self, '_native_block_local'):
                self._native_block_local = {}
            if name not in self._native_block_local:
                asset = self.config['asset_metadata'][name]
                if len(asset['colliders']) != 1:
                    raise BowlExitError('Expected exactly one native block boundingCube')
                vertices = load_bounding_cube_world_vertices(
                    self.stage, asset['colliders'][0], self.config['objects'][name],
                    position, rotation, applied_scale=self.config['parameters'][name]['applied_scale'])
                self._native_block_local[name] = (vertices - position) @ rotation
            return self._native_block_local[name] @ rotation.T + position

        def measured_bowl_exit_guard(self, name, side, bowl, *, require_outside):
            vertices = self.native_block_vertices(name)
            position, quaternion = self.tips[side].get_world_pose()
            rotation = Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix()
            local = held_vertices_in_tcp(vertices, position, rotation)
            transform = np.eye(4)
            transform[:3, :3], transform[:3, 3] = rotation, position
            report = check_rim_crossing(local, [transform], bowl)
            if require_outside and report['over_bowl_sample_count'] != 0:
                raise BowlExitError('Whole measured block must be outside bowl before lowering/reorienting')
            return report

        def exit_bowl_loaded(self, name, side, bowl, plan):
            # The very same plan was included in the complete pick preflight.
            # Validate its unchanged geometry again against the actual grasp,
            # then preflight ALL exit commands before executing the first one.
            position, quaternion = self.tips[side].get_world_pose()
            rotation = Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix()
            measured = check_measured_bowl_exit(plan, self.native_block_vertices(name), position, rotation, bowl)
            local = np.asarray(measured['vertices_tcp'])
            previous = self.target[self.arm_ids[side]].copy()
            deadline = time.monotonic() + 45.0
            planned = []
            for segment in plan['segments']:
                budget = deadline - time.monotonic()
                if budget <= 0:
                    raise MotionPlanningError('Measured full bowl-exit preflight exceeded 45 seconds')
                goal, rot = np.asarray(segment['goal']), np.asarray(segment['R'])
                if segment['kind'] == 'joint_reorientation':
                    trajectory, metadata = self.reorientation_plan(side, previous, goal, rot,
                        segment['duration'], max_planning_seconds=budget)
                else:
                    trajectory, metadata = plan_cartesian(self.models[side], previous, goal, rot,
                        self.sampled_duration(segment['duration']), fps=base.FPS, max_planning_seconds=budget)
                if segment['label'] != 'extra_clearance':
                    transforms = [self.models[side].forward(q) for q in [previous, *trajectory]]
                    check = check_rim_crossing(local, transforms, bowl)
                    if segment['label'] != 'horizontal_exit' and check['over_bowl_sample_count']:
                        raise BowlExitError('Planned lowering/realignment re-enters bowl footprint')
                    metadata['native_carried_rim_check'] = check
                previous = trajectory[-1]
                planned.append((segment, trajectory, metadata))
            self.event('bowl_exit_preflight', object=name, side=side, source_slot=self.locations[name],
                       plan=plan, measured_geometry=measured)
            try:
                self._loaded_exit_guard = lambda: None  # grasp check during vertical clearance too
                for segment, trajectory, metadata in planned:
                    if segment['label'] != 'extra_clearance':
                        outside = segment['label'] != 'horizontal_exit'
                        self._loaded_exit_guard = lambda outside=outside: self.measured_bowl_exit_guard(
                            name, side, bowl, require_outside=outside)
                        self._loaded_exit_guard()
                    self.execute_motion(side, segment['goal'], trajectory, metadata,
                                        name + '_bowl_' + segment['label'])
                    self.verify_held()
                    self.event('bowl_exit_segment_verified', object=name, side=side,
                               segment=segment['label'], checks='measured native geometry and grasp at 30Hz motion/settle samples; initial vertical extraction checks grasp only')
            finally:
                self._loaded_exit_guard = None
            self.held['orientation'] = np.asarray(plan['segments'][-1]['R'])

        def orientation(self, side, point, preferred=0.0):
            seed = self.target[self.arm_ids[side]]
            candidates = list(dict.fromkeys([preferred, 0.0, -0.2, -0.4, -0.7, -0.9]))
            failures = []
            for pitch in candidates:
                rotation = Rotation.from_euler('xyz', [np.pi, pitch, 0]).as_matrix()
                try:
                    self.models[side].solve(np.asarray(point), rotation, seed)
                    return rotation
                except RuntimeError as exc:
                    failures.append(str(exc))
            raise RuntimeError(f'No safe IK candidate for {side} at {point}: {failures[-1]}')

        def force(self, name, side):
            matrix = self.fingers[side].get_contact_force_matrix(dt=base.DT)
            return np.linalg.norm(matrix[:, list(self.objects).index(name), :], axis=-1)

        def support_force(self, name, surface):
            matrix = self.supports[name].get_contact_force_matrix(dt=base.DT)
            return float(np.linalg.norm(matrix[:, list(self.config['support_paths']).index(surface), :]))

        def home(self, side):
            if self.held and self.held['side'] == side:
                raise RuntimeError('home requires an empty hand; use held neutral pose instead')
            current = self.tips[side].get_world_pose()[0]
            rotation = self.models[side].forward(self.target[self.arm_ids[side]])[:3, :3]
            steep = Rotation.from_matrix(rotation.T @ self.down).magnitude() > 0.5
            if (abs(current[1]) < 0.12 or steep) and self.config['task'] != 'CTX08':
                # A simultaneous upward + outward retreat and wrist rotation
                # from the central bowl can leave the IK workspace. First
                # rotate in a lower ipsilateral corridor, then raise to home.
                # Empty-hand return needs a more outward bridge than entry:
                # at y=+/-0.15 the joint-space wrist rotation can bow inward
                # outside the unchanged ipsilateral safety corridor.
                bridge = [0.30, 0.20 if side == 'left' else -0.20, 0.38]
                self.move(side, bridge, 0.8, rotation, side + '_home_bridge')
                self.reorient(side, bridge, self.down, 1.5, side + '_home_reorient')
            self.move(side, self.config['home'][side], 0.9, self.down, side + '_home')
            self.gripper(side, 0.044, side + '_empty_open')
            self.hold(0.5, side + '_home_stable')

        def goal(self, slot, name):
            if slot.startswith('initial:'):
                return self.initial[slot.split(':', 1)[1]].copy(), 'table'
            value = self.config['goals'][slot]
            point = np.asarray(value['position'] if isinstance(value, dict) else value, dtype=float).copy()
            surface = self.config.get('goal_surfaces', {}).get(slot, slot if slot in self.config['support_paths'] else 'table')
            allocation = self.config.get('container_landing_offsets', {}).get(slot, {}).get(name)
            if slot != surface and surface in self.config.get('container_geometry', {}):
                allocation = self.config.get('container_landing_offsets', {}).get(surface, {}).get(name)
                if allocation is None:
                    raise RuntimeError('Container subslot requires a fixed parent allocation')
                expected = np.asarray(self.config['goals'][surface], dtype=float).copy()
                expected[:2] += allocation
                if not np.allclose(point, expected, atol=1e-9, rtol=0):
                    raise RuntimeError('Explicit plate subslot disagrees with parent allocation')
                return point, surface
            if allocation is not None:
                point[:2] += allocation
                return point, surface
            # Multiple objects share containers without requiring inter-object
            # collision/stacking. Allocated landing points remain expert-only.
            occupied = [other for other, location in self.locations.items()
                        if other != name and self.location_surface(location) == surface]
            if occupied and surface in self.config.get('container_geometry', {}):
                container = self.config['container_geometry'][surface]
                if container.get('footprint_schema'):
                    # New noncircular multi-object scenes must have reviewed,
                    # explicit cells; no invented enclosing-circle packing.
                    raise RuntimeError('Noncircular co-occupancy requires a fixed landing allocation')
                radius = float(container['inner_radius'])
                preferred_side = self.config['parameters'][name]['side']
                sign = 1 if preferred_side == 'left' else -1
                candidates = [(0, sign * radius * 0.48), (radius * 0.45, 0), (-radius * 0.45, 0),
                              (radius * 0.35, sign * radius * 0.30), (-radius * 0.35, sign * radius * 0.30)]
                points = [point + [dx, dy, 0] for dx, dy in candidates]
                point = max(points, key=lambda p: min(np.linalg.norm(p[:2] - self.objects[o].get_world_pose()[0][:2]) for o in occupied))
            return point, surface

        def location_surface(self, slot):
            if slot.startswith('initial:'):
                return 'table'
            return self.config.get('goal_surfaces', {}).get(slot,
                slot if slot in self.config['support_paths'] else 'table')

        def physical_slot(self, slot):
            if slot.startswith('initial:'):
                return self.config['parameters'][slot.split(':', 1)[1]]['slot']
            return slot

        def grasp_pitch_profile(self, name, location):
            slot = self.physical_slot(location)
            fixed = self.config.get('fixed_grasp_pitch_by_slot')
            if fixed is not None:
                if self.config['task'] != 'CTX05' or slot not in fixed:
                    raise RuntimeError('Fixed grasp profile requires a reviewed CTX05 physical slot')
                return dict(physical_slot=slot, pitch=float(fixed[slot]), strict_pitch=True)
            return dict(physical_slot=slot,
                pitch=float(self.config['parameters'][name].get('grasp_pitch', 0.0)), strict_pitch=False)

        def approach(self, name, side):
            if self.held:
                raise RuntimeError('Cannot approach with another object already held')
            p = self.objects[name].get_world_pose()[0].copy()
            point = p + [0, 0, 0.075]
            rotation = self.orientation(side, point, self.config['parameters'][name].get('grasp_pitch', 0.0))
            self.gripper(side, 0.044, name + '_open')
            self.move(side, point, 1.0, rotation, name + '_approach_only')
            self.event('approach_complete', object=name, side=side, object_not_grasped=True)

        def pick(self, name, side):
            if self.held:
                raise RuntimeError('Only one active grasp is permitted in this serial dual-arm suite')
            self.active_color = name
            before = self.objects[name].get_world_pose()[0].copy()
            obj_q = self.objects[name].get_world_pose()[1]
            parameters = self.config['parameters'][name]
            offset = np.array([0, 0, 0.006])
            if 'grasp_local_offset' in parameters:
                offset = Rotation.from_quat(np.r_[obj_q[1:], obj_q[0]]).apply(parameters['grasp_local_offset'])
            elif name == 'banana':
                scale = float(self.config['parameters'][name].get('scale', 1.0))
                offset = Rotation.from_quat(np.r_[obj_q[1:], obj_q[0]]).apply([-0.025 * scale, 0, 0.006])
            point = before + offset
            location = self.locations[name]
            surface = self.location_surface(location)
            container_kind = self.config.get('container_geometry', {}).get(surface, {}).get('kind')
            if surface == 'F' and container_kind in ('bowl', 'plate'):
                raise RuntimeError('v0.7 forbids retrieval from a far container')
            bowl_block_regrasp = (
                container_kind == 'bowl'
                and self.plan['props'][name]['asset'].endswith('_block.usd')
                and abs(point[1]) < 0.12)
            candidate = None
            pitch_profile = self.grasp_pitch_profile(name, location)
            grasp_pitch = pitch_profile['pitch']
            measured_table_yaw = None
            if self.config.get('task') == 'CTX01':
                measured_table_yaw = initial_table_block_yaw(
                    task=self.config['task'], name=name, asset=self.plan['props'][name]['asset'],
                    location=location, surface=surface, point=point,
                    object_quaternion_wxyz=obj_q, strict_pitch=pitch_profile['strict_pitch'])
            if measured_table_yaw is not None:
                self.event('initial_table_block_yaw_candidate', object=name, side=side,
                           measured_object_quaternion_wxyz=np.asarray(obj_q).tolist(),
                           grasp_yaw_rad=measured_table_yaw,
                           scope='CTX01 initial outside-table block only; actual contact and A/B pose checks remain mandatory',
                           object_pose_written=False, physics_verified=False)
            if pitch_profile['strict_pitch']:
                self.event('fixed_grasp_orientation_candidate', object=name, side=side, **pitch_profile,
                           source='scene_config.fixed_grasp_pitch_by_slot', physics_verified=False)
            if bowl_block_regrasp:
                # A block can settle tilted against the curved bowl. Use its
                # measured geometry to center the fingers near the upper part;
                # do not reuse the low tabletop grasp point or assume yaw=0
                # means the object itself is axis aligned. This is expert-only
                # planning, with actual contact/lift checks still mandatory.
                if side not in self.finger_geometry:
                    self.finger_geometry[side] = load_finger_geometry(self.stage, side, self.models[side])
                    self.recorder.demo.attrs['finger_geometry_' + side] = json.dumps(self.finger_geometry[side]['metadata'])
                grasp_pitch = float(self.config.get('bowl_block_grasp_pitch', {}).get(location, -0.7))
                candidate = plan_block_bowl_regrasp(
                    self.geometry[name], before,
                    Rotation.from_quat(np.r_[obj_q[1:], obj_q[0]]).as_matrix(),
                    parameters['grasp_local_offset'],
                    Rotation.from_euler('xyz', [np.pi, grasp_pitch, 0]).as_matrix(),
                    self.finger_geometry[side], object_kind='block')
                point = candidate['point']
                self.event('grasp_geometry_candidate', object=name, side=side,
                           approach_clearance_m=0.025, lift_height_m=0.04, **candidate['metadata'])
            rotation, approach, lift, bridge, inner, exit_plan = self.pick_orientation(
                side, point, grasp_pitch,
                parameters.get('slot') == 'REPLACEMENT_SHARED' and point[0] < 0.14,
                bowl_block_regrasp=bowl_block_regrasp, strict_pitch=pitch_profile['strict_pitch'],
                grasp_yaw=0.0 if measured_table_yaw is None else measured_table_yaw,
                preserve_table_yaw=measured_table_yaw is not None)
            self.event('pick_start', object=name, side=side)
            opening = (0.036 if name == 'banana' else 0.031) if abs(point[1]) < 0.12 else 0.044
            if candidate is not None:
                opening = candidate['opening']
            self.gripper(side, opening, name + '_open')
            if bridge is not None:
                self.move(side, bridge, 0.8, self.down, name + '_empty_entry_bridge')
                self.reorient(side, bridge, rotation, 1.5, name + '_empty_prealign')
            if inner is not None:
                self.move(side, inner, 1.0, rotation, name + '_front_inner_entry')
            # Use the same orientation along the final vertical grasp approach.
            self.models[side].solve(approach, rotation, self.target[self.arm_ids[side]])
            self.move(side, approach, 1.0, rotation, name + '_approach')
            self.move(side, point, 1.1, rotation, name + '_descend')
            self.gripper(side, 0.0, name + '_close')
            self.hold(0.35, name + '_grasp_settle')
            self.move(side, lift, 0.9, rotation, name + '_lift')
            sampled_pick = self.sampled_outside_pick(point)
            self.hold(sampled_pick['lift_hold_s'] if sampled_pick is not None else 0.4, name + '_lift_hold')
            heights = np.asarray(self.recent[name])[-10:, 2] - before[2]
            forces = np.linalg.norm(np.asarray(self.recent_forces[side])[-10:, :, list(self.objects).index(name), :], axis=-1)
            if len(heights) != 10 or heights.min() < 0.03 or np.any(forces < 0.03):
                raise RuntimeError(f'Physical grasp failed {name}/{side}: lift={heights.tolist()}, forces={forces.tolist()}')
            self.held = {'object': name, 'side': side, 'orientation': rotation, 'source_z': float(before[2]),
                         'source_slot': location,
                         'source_surface': surface,
                         'source_kind': container_kind or 'table',
                         'table_yaw_aligned_initial': measured_table_yaw is not None,
                         'bowl_block_regrasp': bool(bowl_block_regrasp)}
            self.event('grasp_success', object=name, side=side, minimum_lift_m=float(heights.min()),
                       minimum_finger_force_N=float(forces.min()), verified_hold_s=9 / base.FPS)
            neutral = np.asarray(self.config['held_neutral'][side])
            if exit_plan is not None:
                self.exit_bowl_loaded(name, side, self.config['container_geometry'][location], exit_plan)
            else:
                if inner is not None:
                    self.move(side, inner, 1.0, rotation, name + '_front_inner_exit')
                if bridge is not None:
                    self.move(side, bridge, 0.8, rotation, name + '_held_exit_bridge')
                self.move(side, neutral, 1.1, rotation, name + '_neutral_held')
            self.hold(0.3, name + '_held_settle')
            self.verify_held()
            self.preview(name + '_held')

        def verify_held(self):
            if not self.held:
                raise RuntimeError('Expected a held object')
            name, side = self.held['object'], self.held['side']
            p = self.objects[name].get_world_pose()[0]
            tcp = self.tips[side].get_world_pose()[0]
            forces = self.force(name, side)
            if np.any(forces < 0.03) or np.linalg.norm(p - tcp) > 0.15:
                raise RuntimeError(f'Grasp lost: {name}, forces={forces.tolist()}, tcp_dist={np.linalg.norm(p-tcp)}')

        def placement(self, name, point, surface):
            p = self.objects[name].get_world_pose()[0]
            span = float(np.max(np.ptp(np.asarray(self.recent[name])[-15:], axis=0)))
            force = self.support_force(name, surface)
            fingers = sum(float(np.linalg.norm(self.force(name, side))) for side in base.SIDES)
            speed = float(np.linalg.norm(self.objects[name].get_linear_velocity()))
            error = float(np.linalg.norm(p[:2] - point[:2]))
            success = span < 0.003 and force > 0.03 and fingers < 0.05 and speed < 0.03
            if surface in self.config.get('container_geometry', {}):
                geometry = self.config['container_geometry'][surface]
                vertices = self.object_vertices(name)
                in_container = contains_xy_compatible(vertices, geometry)
                horizontal_fraction = float(np.mean(in_container))
                if geometry.get('kind') == 'bowl':
                    in_container &= vertices[:, 2] < float(geometry['rim_z']) + 0.002
                    contained_fraction = float(np.mean(in_container))
                    success = success and horizontal_fraction > 0.95 and contained_fraction > 0.10 and vertices[:, 2].min() < float(geometry['rim_z']) - 0.008
                else:
                    contained_fraction = float(np.mean(in_container))
                    success = success and contained_fraction > 0.95
            else:
                contained_fraction = None
                success = success and error < 0.02
            return {'success': bool(success), 'position': p.tolist(), 'horizontal_error_m': error,
                    'support_force_N': force, 'finger_force_N': fingers, 'pose_span_m': span,
                    'speed_m_s': speed, 'contained_fraction': contained_fraction}

        def stable_return_eligible(self, name, side, point, surface):
            # Recorded at the successful grasp, not inferred from wrist pitch.
            return (surface == 'table' and self.held.get('bowl_block_regrasp') is True
                    and self.held.get('source_kind') == 'bowl'
                    and self.plan['props'][name]['asset'].endswith('_block.usd')
                    and side in ('left', 'right')
                    and (1 if side == 'left' else -1) * point[1] >= 0.12)

        def stable_return_measurement(self, name, side):
            # Native collision vertices, not visual bounds. Transforming these
            # measured vertices is a planning prediction, never an object write.
            world = self.native_block_vertices(name)
            position, quaternion = self.objects[name].get_world_pose()
            rotation = Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix()
            local = (world - position) @ rotation
            tcp, tcp_quaternion = self.tips[side].get_world_pose()
            return np.r_[tcp, tcp_quaternion], np.r_[position, quaternion], local

        def execute_stable_return_segment(self, name, side, segment):
            # execute_motion writes float64 planner rows into self.target,
            # normally a float32 simulation command buffer. Compare exactly at
            # that storage precision, never with a relaxed physical tolerance.
            actual_start = self.target[self.arm_ids[side]]
            expected_start = np.asarray(segment['start_q'], dtype=actual_start.dtype)
            if not np.array_equal(actual_start, expected_start):
                raise StableReturnError('Commanded joints changed after stable-return preflight')
            previous_guard = getattr(self, '_loaded_exit_guard', None)
            try:
                if segment['loaded']:
                    bowl = self.config['container_geometry'][self.held['source_slot']]
                    def loaded_guard():
                        if previous_guard is not None:
                            previous_guard()
                        self.measured_bowl_exit_guard(name, side, bowl, require_outside=True)
                    self._loaded_exit_guard = loaded_guard
                    self._loaded_exit_guard()
                    self.verify_held()
                # No move()/reorient(): execute exactly the accepted array.
                self.execute_motion(side, segment['goal'], segment['trajectory'], segment['metadata'],
                                    name + '_stable_return_' + segment['label'])
                if segment['loaded']:
                    self.verify_held()
                    self.held['orientation'] = np.asarray(segment['R'])
            finally:
                self._loaded_exit_guard = previous_guard

        def refresh_stable_return_tail(self, name, side, point, plan):
            tcp, obj, native = self.stable_return_measurement(name, side)
            grasp = measured_grasp(tcp, obj, native)
            rotation = np.asarray(plan['segments'][3]['R'])
            desired_object = np.asarray(plan['metadata']['desired_object_rotation'])
            predicted_object = rotation @ grasp['object_rotation_in_tcp']
            stable_error = float(Rotation.from_matrix(desired_object.T @ predicted_object).magnitude())
            if stable_error > 0.08:
                # Re-aligning to a new face here would invalidate the full
                # corridor plan. Fail closed instead of dropping a tilted block.
                raise StableReturnError(f'Grasp slipped away from selected stable face: {stable_error}rad')
            geometry = landing_geometry(grasp, point[:2], rotation, tabletop=self.config['tabletop'])
            changed = (not np.allclose(geometry['lower'], plan['segments'][3]['goal'], atol=1e-9, rtol=0)
                       or not np.allclose(geometry['withdraw'], plan['segments'][4]['goal'], atol=1e-9, rtol=0))
            previous = self.target[self.arm_ids[side]].copy()
            deadline = time.monotonic() + 45.0
            tail = []
            for original in plan['segments'][3:]:
                segment = dict(original)
                if segment['label'] == 'table_lower':
                    segment['goal'] = geometry['lower']
                elif segment['label'] == 'empty_withdraw':
                    segment['goal'] = geometry['withdraw']
                segment['start_q'] = previous.copy()
                if changed:
                    budget = deadline - time.monotonic()
                    if budget <= 0:
                        raise StableReturnError('Measured stable-return tail preflight exceeded 45 seconds')
                    if segment['kind'] == 'joint_reorientation':
                        trajectory, metadata = self.reorientation_plan(side, previous, segment['goal'],
                            segment['R'], segment['duration'], sample_duration=False, max_planning_seconds=budget)
                    else:
                        trajectory, metadata = plan_cartesian(self.models[side], previous, segment['goal'],
                            segment['R'], segment['duration'], fps=base.FPS, max_planning_seconds=budget)
                    segment.update(trajectory=trajectory, metadata=metadata)
                if segment['loaded']:
                    transforms = [self.models[side].forward(q) for q in [previous, *segment['trajectory']]]
                    bottom = min(float((grasp['vertices_in_tcp'] @ t[:3, :3].T + t[:3, 3])[:, 2].min())
                                 for t in transforms)
                    if bottom < self.config['tabletop'] - 1e-8:
                        raise StableReturnError('Fresh held native block would enter table during lower')
                    bowl = self.config['container_geometry'][self.held['source_slot']]
                    rim = check_rim_crossing(grasp['vertices_in_tcp'], transforms, bowl)
                    if rim['over_bowl_sample_count']:
                        raise StableReturnError('Stable-return lower would re-enter source bowl')
                    segment['metadata'] = {**segment['metadata'], 'fresh_predicted_native_bottom_m': bottom,
                                           'fresh_native_bowl_check': rim}
                previous = segment['trajectory'][-1]
                tail.append(segment)
                if time.monotonic() > deadline:
                    raise StableReturnError('Measured stable-return tail preflight exceeded 45 seconds')
            # Publish only after ALL five segments succeed. No partial tail is
            # executed if lower/withdraw/home planning or geometry checks fail.
            plan['segments'] = plan['segments'][:3] + tail
            self.event('stable_return_landing_refresh', object=name, side=side, replanned=bool(changed),
                       actual_tcp_pose_wxyz=tcp.tolist(), actual_object_pose_wxyz=obj.tolist(),
                       object_origin_in_tcp=grasp['object_origin_in_tcp'].tolist(),
                       selected_face_error_rad=stable_error, selected_face_tolerance_rad=0.08,
                       lower_goal=geometry['lower'].tolist(), withdraw_goal=geometry['withdraw'].tolist(),
                       tail_labels=[s['label'] for s in tail],
                       planning_scope='Complete tail checked before lower; physical guards remain mandatory')

        def stable_bowl_block_return_loaded(self, name, side, point, surface):
            if not self.stable_return_eligible(name, side, point, surface):
                raise StableReturnError('Stable return is only for bowl-regrasped blocks on the same-side table')
            if self.locations[name] != self.held['source_slot']:
                raise StableReturnError('Held source slot no longer matches the recorded bowl grasp')
            self.verify_held()
            tcp, obj, native = self.stable_return_measurement(name, side)
            previous = self.target[self.arm_ids[side]].copy()
            plan = plan_stable_block_return(self.models[side], previous, tcp, obj, native, point[:2],
                self.config['parameters'][name]['object_yaw'], side, tabletop=self.config['tabletop'], fps=base.FPS)
            labels = ['loaded_bridge', 'loaded_realign', 'table_transfer', 'table_lower',
                      'empty_withdraw', 'empty_home_bridge', 'empty_home_realign', 'home']
            if ([s['label'] for s in plan['segments']] != labels
                    or [s['loaded'] for s in plan['segments']] != [True]*4 + [False]*4
                    or plan['metadata']['release_after_label'] != 'table_lower'
                    or not np.allclose(plan['segments'][-1]['goal'], self.config['home'][side], atol=1e-9, rtol=0)):
                raise StableReturnError('Unexpected stable-return sequence or home target')
            for segment in plan['segments']:
                segment['start_q'] = previous.copy()
                previous = segment['trajectory'][-1]
            self.event('stable_return_preflight', object=name, side=side, source_slot=self.held['source_slot'],
                       planning=plan['metadata'], segment_labels=labels)
            for segment in plan['segments'][:3]:
                self.execute_stable_return_segment(name, side, segment)
            self.refresh_stable_return_tail(name, side, point, plan)
            self.execute_stable_return_segment(name, side, plan['segments'][3])
            return plan

        def place(self, name, side, slot):
            if not self.held or (self.held['object'], self.held['side']) != (name, side):
                raise RuntimeError('place does not match the current physical grasp')
            point, surface = self.goal(slot, name)
            begin_frame = self.frame_index
            container = self.config.get('container_geometry', {}).get(surface)
            stable_plan = None
            if self.stable_return_eligible(name, side, point, surface):
                stable_plan = self.stable_bowl_block_return_loaded(name, side, point, surface)
                rotation = stable_plan['segments'][3]['R']
                target = stable_plan['segments'][3]['goal']
            else:
                support_z = float(container['rim_z']) + 0.004 if container else self.config['tabletop'] + 0.002
                # Move the held object over the support before releasing. Actual
                # object-to-TCP offset is re-read after orientation changes.
                fixed_table_pitches = self.config.get('fixed_table_place_pitch_by_slot', {})
                configured_pitch = fixed_table_pitches.get(self.physical_slot(slot)) if surface == 'table' else None
                if configured_pitch is None:
                    configured_pitch = self.config.get('container_place_pitch_by_object', {}).get(name, {}).get(surface)
                if configured_pitch is None:
                    configured_pitch = self.config.get('container_place_pitch', {}).get(surface)
                if configured_pitch is not None:
                    # A geometry-tested container pose is a fixed candidate. Do
                    # not silently fall back to a different wrist orientation.
                    rotation = Rotation.from_euler('xyz', [np.pi, float(configured_pitch), 0]).as_matrix()
                elif not container and abs(point[1]) >= 0.12:
                    # A lateral tabletop return should retain the successful
                    # grasp orientation. Re-selecting vertical at only the high
                    # transit endpoint made the forward L2 low release infeasible.
                    rotation = self.models[side].forward(self.target[self.arm_ids[side]])[:3, :3]
                else:
                    rotation = self.orientation(side, [*point[:2], max(support_z + 0.045, self.config['tabletop'] + 0.07)],
                                                -0.7 if abs(point[1]) < 0.08 else 0.0)
                transit = np.r_[point[:2], max(support_z + 0.055, self.config['tabletop'] + 0.08)]
                if abs(point[1]) < 0.12 and self.config['task'] != 'CTX08':
                    bridge_y = float(self.config.get('container_bridge_abs_y', .15))
                    bridge = [0.30, bridge_y if side == 'left' else -bridge_y, 0.38]
                    current_rotation = self.models[side].forward(self.target[self.arm_ids[side]])[:3, :3]
                    self.move(side, bridge, 0.8, current_rotation, name + '_transfer_bridge')
                    self.reorient(side, bridge, rotation, 1.5, name + '_transfer_prealign')
                    self.verify_held()
                elif not container and Rotation.from_matrix(rotation.T @ self.down).magnitude() > 0.5:
                    if self.held.get('table_yaw_aligned_initial'):
                        # This initial-table candidate was admitted only at
                        # pitch=0. Never erase its yaw with the unrelated steep
                        # bowl-return recovery below; revalidate a new attempt.
                        raise RuntimeError('Yaw-aligned initial block reached an unreviewed steep table-return pose')
                    # Loaded bowl exits retain a steep wrist. A direct side-table
                    # return at that pitch can change IK branches repeatedly.
                    # Reorient in the exterior corridor, then recompute the lower
                    # target from the actual grasp after transfer as usual.
                    bridge = [0.30, 0.20 if side == 'left' else -0.20, 0.38]
                    self.move(side, bridge, 0.8, rotation, name + '_lateral_loaded_bridge')
                    rotation = Rotation.from_euler('xyz', [np.pi, -0.4, 0]).as_matrix()
                    self.reorient(side, bridge, rotation, 1.5, name + '_lateral_loaded_realign')
                    self.verify_held()
                self.move(side, transit, 1.3, rotation, name + '_transfer')
                self.verify_held()
                p = self.objects[name].get_world_pose()[0]
                tcp = self.tips[side].get_world_pose()[0]
                offset = tcp - p
                bottom = float(self.object_vertices(name)[:, 2].min() - p[2])
                target = np.r_[point[:2] + offset[:2], support_z - bottom + offset[2]]
                self.move(side, target, 1.0, rotation, name + '_lower')
                self.verify_held()
            opening = (0.036 if name == 'banana' else 0.031) if container else 0.044
            if container:
                # A fruit can require more aperture than the old fixed release
                # command. Contact-constrained measured joints, not command=0,
                # provide a conservative opening candidate; contacts below
                # must still prove that it actually released.
                measured = self.robot.get_joint_positions()[self.finger_ids[side]]
                opening = max(opening, float(np.max(measured)) + 0.004)
                if opening > 0.044:
                    raise RuntimeError(f'Release needs opening beyond admitted joint range: {opening}')
            self.gripper(side, opening, name + '_release')
            self.hold(0.4, name + '_release_settle')
            # Do not carry a supposedly released object away during withdrawal.
            # Require three consecutive 30 Hz samples of target support and
            # detached fingers; fixed waiting time alone is not evidence.
            object_index = list(self.objects).index(name)
            support_index = list(self.config['support_paths']).index(surface)
            group = self.recorder.demo
            release_forces = [np.linalg.norm(group[f'contacts/{arm}_finger_object'][-3:, :, object_index, :], axis=-1)
                              for arm in base.SIDES]
            support_forces = np.linalg.norm(group[f'contacts/{name}_surfaces'][-3:, 0, support_index, :], axis=-1)
            maximum_finger_force = float(max(value.max() for value in release_forces))
            minimum_support_force = float(support_forces.min())
            if maximum_finger_force >= 0.05 or minimum_support_force <= 0.03:
                raise RuntimeError(f'Object not released onto {surface} before withdrawal: '
                                   f'{name}, fingers={maximum_finger_force}, support={minimum_support_force}')
            self.event('release_verified_before_withdraw', object=name, side=side, surface=surface,
                       commanded_opening_m=opening, maximum_finger_force_N=maximum_finger_force,
                       minimum_support_force_N=minimum_support_force, consecutive_frames=3)
            # Do not rise into the high central workspace hole. At a central
            # support, clear the released object then retreat outward at the
            # same wrist pitch before raising in the ipsilateral corridor.
            # After a bowl regrasp the wrist can remain steep on a lateral
            # tabletop return. A 5 cm vertical retreat then leaves the arm's
            # workspace; clear by 2.5 cm and reorient empty at the home bridge.
            if stable_plan is not None:
                self.held = None  # Only after the unchanged detached/support guard above.
                for segment in stable_plan['segments'][4:]:
                    self.execute_stable_return_segment(name, side, segment)
                # Same open/settle as home(), without replanning its trajectory.
                self.gripper(side, 0.044, side + '_empty_open')
                self.hold(0.5, side + '_home_stable')
            else:
                steep = Rotation.from_matrix(rotation.T @ self.down).magnitude() > 0.5
                clearance = 0.025 if abs(point[1]) < 0.12 or steep else 0.05
                self.move(side, target + [0, 0, clearance], 0.8, rotation, name + '_withdraw')
                self.held = None
                self.home(side)
            self.hold(0.6, name + '_placement_stable')
            metrics = self.placement(name, point, surface)
            if slot in self.config.get('table_regions', {}):
                region = self.config['table_regions'][slot]
                vertices = self.object_vertices(name)
                inside = np.all(np.abs(vertices[:, :2] - np.asarray(region['center'])[:2])
                                < np.asarray(region['half_extents_xy']), axis=1)
                metrics['region_contained_fraction'] = float(inside.mean())
                metrics['success'] = bool(metrics['success'] and inside.all())
            if not metrics['success']:
                raise RuntimeError(f'Failed physical placement {name}/{slot}: {metrics}')
            self.locations[name] = slot
            self.stationary_reference[name] = self.objects[name].get_world_pose()[0].copy()
            self.active_color = None
            self.event('place_success', object=name, side=side, target_slot=slot, surface=surface,
                       selected_target=point.tolist(), begin_frame=begin_frame, end_frame=self.frame_index, **metrics)
            return metrics

        def cycle(self, name, side=None):
            side = side or self.config['parameters'][name]['side']
            self.event('cycle_start', object=name, side=side)
            self.pick(name, side)
            self.place(name, side, 'initial:' + name)
            self.completed.append(name)
            self.event('cycle_complete', object=name, side=side)

        def push(self, name, side, slot):
            if self.held:
                raise RuntimeError('Push requires an empty hand')
            point, surface = self.goal(slot, name)
            if surface != 'table':
                raise RuntimeError('Push target must be a tabletop region')
            self.active_color = name
            start = self.objects[name].get_world_pose()[0].copy()
            direction = point[:2] - start[:2]
            length = np.linalg.norm(direction)
            if length < 0.05:
                raise RuntimeError('Push requires a meaningful horizontal displacement')
            direction /= length
            yaw = np.arctan2(direction[0], -direction[1])
            yaw = (yaw + np.pi / 2) % np.pi - np.pi / 2
            rotation = Rotation.from_euler('z', yaw).as_matrix() @ self.down
            self.gripper(side, 0, name + '_pusher_close')
            if side not in self.finger_geometry:
                self.finger_geometry[side] = load_finger_geometry(self.stage, side, self.models[side])
                self.recorder.demo.attrs['finger_geometry_' + side] = json.dumps(self.finger_geometry[side]['metadata'])
            # Commanded zero does not mean the actual aperture is zero. Use
            # measured joints and native collision volumes, including their
            # contact-height overlap, rather than a fixed center offset.
            openings, opening_evidence = measured_finger_openings(
                self.stage, side, self.names, self.robot.get_joint_positions())
            asset = self.config['asset_metadata'][name]
            colliders = asset['colliders']
            if len(colliders) != 1:
                raise RuntimeError('Native push supports exactly one boundingCube block collider')
            position, quaternion = self.objects[name].get_world_pose()
            if np.linalg.norm(position - start) > 0.001:
                raise RuntimeError('Push object moved before the approach was planned')
            vertices = load_bounding_cube_world_vertices(
                self.stage, colliders[0], self.config['objects'][name], position,
                Rotation.from_quat(np.r_[quaternion[1:], quaternion[0]]).as_matrix(),
                applied_scale=asset['applied_scale'])
            candidate = derive_push_geometry(self.finger_geometry[side], openings, vertices,
                                             start, rotation, np.r_[direction, 0], start[2] + 0.006)
            self.event('push_geometry_candidate', object=name, side=side,
                       direction=np.r_[direction, 0].tolist(), collider=colliders[0],
                       measured_finger_mapping=opening_evidence, **candidate)
            behind = start - np.r_[direction * candidate['behind_offset_m'], -0.006]
            self.move(side, behind + [0, 0, 0.05], 1, rotation, name + '_push_approach')
            self.move(side, behind, 1, rotation, name + '_push_lower')
            pre_contact_drift = float(np.linalg.norm(self.objects[name].get_world_pose()[0] - start))
            if pre_contact_drift > 0.002:
                raise RuntimeError(f'Push approach displaced the object before intended contact: {pre_contact_drift}')
            self.event('push_approach_clear', object=name, side=side, object_displacement_m=pre_contact_drift)
            begin = self.frame_index
            end_pose = np.r_[point[:2] - direction * candidate['endpoint_offset_m'], behind[2]]
            self.move(side, end_pose, 2.5, rotation, name + '_push_contact')
            end = self.frame_index
            self.move(side, end_pose + [0, 0, 0.07], 0.8, rotation, name + '_push_withdraw')
            self.home(side)
            self.hold(0.6, name + '_push_stable')
            group = self.recorder.demo
            rise = float(np.max(group[f'next_obs/{name}_pose'][begin:end, 2]) - start[2])
            support = np.linalg.norm(group[f'contacts/{name}_surfaces'][begin:end, 0, 0], axis=-1)
            contacts = np.linalg.norm(group[f'contacts/{side}_finger_object'][begin:end, :, list(self.objects).index(name)], axis=-1)
            metrics = self.placement(name, point, surface)
            supported = float(np.mean(support > 0.03))
            if not metrics['success'] or rise > 0.012 or supported < 0.90 or contacts.max() < 0.03:
                raise RuntimeError(f'Push verification failed {name}: {metrics}, rise={rise}, supported={supported}')
            self.locations[name] = slot
            self.stationary_reference[name] = self.objects[name].get_world_pose()[0].copy()
            self.active_color = None
            self.event('method_success', object=name, side=side, method='push', maximum_lift_m=rise,
                       support_fraction=supported, **metrics)

        def route(self, name, side, slot, route):
            pitch = self.config['route_orientation_pitch'][route]
            rotation = Rotation.from_euler('xyz', [np.pi, pitch, 0]).as_matrix()
            for waypoint in self.config['route_empty_approach'][side][route]:
                self.move(side, waypoint, 0.8, rotation, name + '_empty_corridor_approach')
            self.pick(name, side)
            routes = self.config.get('routes', {}).get(side, {})
            if route not in routes:
                raise RuntimeError(f'No verified route geometry for {side}/{route}')
            begin = self.frame_index
            for waypoint in routes[route]:
                self.move(side, waypoint, 1.0, rotation, name + '_route_' + route)
                self.verify_held()
            box = np.asarray(self.config['route_geometry'][side]['aabb_m'])
            poses = self.recorder.demo[f'next_obs/{name}_pose'][begin:self.frame_index]
            crossed = 0
            for pose in poses:
                vertices = Rotation.from_quat(np.r_[pose[4:7], pose[3]]).apply(self.geometry[name]) + pose[:3]
                overlaps_lateral_slab = vertices[:, 1].max() > box[0, 1] and vertices[:, 1].min() < box[1, 1]
                if not overlaps_lateral_slab:
                    continue
                crossed += 1
                outside_end = vertices[:, 0].max() < box[0, 0] - 0.002 if route == 'near' else vertices[:, 0].min() > box[1, 0] + 0.002
                if not outside_end or vertices[:, 2].min() > box[1, 2]:
                    raise RuntimeError(f'Wrong/over-top obstacle corridor for {name}/{route}')
            if crossed < 3:
                raise RuntimeError('No observed obstacle crossing segment')
            self.event('route_traversed', object=name, side=side, route=route,
                       begin_frame=begin, end_frame=self.frame_index, verified_crossing_frames=crossed)
            self.place(name, side, slot)

        def run(self):
            reference_start = self.config.get('reference_start_pose')
            if reference_start:
                from context_reference_start import verify_reference_initial, prepare_operational_waiting
                self.event('reference_start_verified', **verify_reference_initial(self))
                first = self.plan['timeline'][0]
                if first['op'] != 'command' or first.get('role') == 'query':
                    raise RuntimeError('Reference preparation requires an initial common setup command')
            else:
                self.verify_waiting_pose()
            if base.args.probe:
                self.command(self.plan['timeline'][0]['text'])
                self.hold(0.5, 'probe')
                if reference_start:
                    self.event('reference_start_verified', **verify_reference_initial(self))
                else:
                    self.verify_waiting_pose()
                self.preview('probe')
                return {'success': False, 'probe_success': True, 'completed_order': []}
            for index, operation in enumerate(self.plan['timeline']):
                self.action_loss = bool(operation.get('action_loss', True))
                kind = operation['op']
                name, side = operation.get('object'), operation.get('side')
                self.event('operation_start', operation_index=index, operation=kind)
                if kind == 'command':
                    self.command(operation['text'])
                    default_hold = (self.config['episode_sampling']['instruction_hold_s']
                                    if index > 0 and self.config.get('episode_sampling') else 0.5)
                    self.hold(float(operation.get('seconds', default_hold)), 'instruction_' + operation.get('role', 'received'))
                    if index == 0 and reference_start:
                        preparation = prepare_operational_waiting(self)
                        self.preview('reference_start_waiting')
                        if getattr(base.args, 'setup_probe', False):
                            return {'success': False, 'probe_success': True,
                                    'setup_probe': True, 'training_data': False,
                                    'reference_preparation': preparation, 'completed_order': []}
                    if operation.get('role') == 'query':
                        self.preview('query_boundary')
                elif kind in ('wait', 'hold'):
                    if self.held:
                        start = self.objects[self.held['object']].get_world_pose()[0].copy()
                        begin = self.frame_index
                    self.hold(float(operation.get('seconds', 0.6)), operation.get('phase', kind))
                    if self.held:
                        self.verify_held()
                        poses = self.recorder.demo[f"next_obs/{self.held['object']}_pose"][begin:self.frame_index, :3]
                        drift = float(np.max(np.linalg.norm(poses - start, axis=1)))
                        if drift > 0.015:
                            raise RuntimeError(f'Excessive held-object pause drift {drift}')
                        self.event('hold_verified', object=self.held['object'], drift_m=drift)
                elif kind == 'cycle':
                    self.cycle(name, side)
                elif kind == 'pick_place':
                    self.pick(name, side)
                    self.place(name, side, operation['target_slot'])
                elif kind == 'pick':
                    self.pick(name, side)
                elif kind == 'place':
                    self.place(name, side, operation['target_slot'])
                elif kind == 'approach':
                    self.approach(name, side)
                elif kind == 'home':
                    self.home(side)
                elif kind == 'push':
                    self.push(name, side, operation['target_slot'])
                elif kind == 'route':
                    self.route(name, side, operation['target_slot'], operation['route'])
                else:
                    raise RuntimeError(f'Unsupported task operation: {kind}')
                self.operation_results.append({'operation_index': index, 'op': kind, 'object': name,
                                               'side': side, 'success': True, 'end_frame': self.frame_index})
                self.event('operation_complete', **self.operation_results[-1])
            if self.held:
                raise RuntimeError('Episode ended with a held object')
            self.action_loss = True
            self.hold(1.0, 'completed_hold')
            self.verify_waiting_pose()
            self.preview('final')
            result = {'success': True, 'task': base.args.task, 'variant': base.args.variant,
                      'frames': self.frame_index, 'duration_s': self.frame_index / base.FPS,
                      'camera_count': len(self.images or {}), 'status': 'pilot_uncalibrated',
                      'learned_policy': False, 'physical_grasp': True, 'mirror': False,
                      'operations': self.operation_results, 'completed_order': self.completed,
                      'locations': self.locations, 'max_non_target_drift_m': self.max_non_target_drift,
                      'validation_scope': 'Per-operation physical contact, lift, stable support, causal language and serial-arm execution; independent audit also required',
                      'thresholds_are_pilot_candidates': True}
            self.event('task_success', completed_order=self.completed)
            return result
    return SuiteEpisode
