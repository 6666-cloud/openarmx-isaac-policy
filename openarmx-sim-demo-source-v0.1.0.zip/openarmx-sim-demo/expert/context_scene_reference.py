"""Explicit, CPU-only reference-start authoring for a simulation diagnostic.

The caller must invoke this only for its explicit ``--reference-start-pose``
option. Importing this module has no scene side effects. The ordinary suite
start remains unchanged. This does not set live articulation state, advance
physics, save a layer, command hardware, or certify a task/training episode.

All profile/source/model/native-joint checks finish before any USD mutation.
The immutable candidate's false startup/calibration authorization is preserved.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from inspect_context_start_pose import (
    SIM, load_start_pose_reference, native_usd_tree, no_duplicate_keys, urdf_tree,
)

from runtime_paths import asset_root
ROOT = asset_root()
DEFAULT_PROFILE = ROOT / 'configs/context_start_pose_real_reference_v1.json'
ROBOT_PATH = '/world/OpenArmX'
CALIBRATION_STATUS = 'not_calibrated_visual_reference_only'
UNIT_ASSUMPTION = 'arm rad; reported finger1 m'


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def _absolute_path(value, label):
    _require(isinstance(value, str) and bool(value), label + ' must be a path string')
    path = Path(value)
    _require(path.is_absolute(), label + ' must be absolute, not inferred from cwd')
    return path.resolve(strict=True)


def _validated_profile(profile_path):
    path = Path(profile_path).resolve(strict=True)
    content = path.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    profile = json.loads(content, object_pairs_hook=no_duplicate_keys)
    _require(isinstance(profile, dict), 'Profile must be a JSON object')
    _require(profile.get('schema') == 'context_start_pose_real_reference_v1', 'Unsupported profile schema')
    _require(profile.get('status') == 'offline_visual_reference_candidate_not_calibrated',
             'Reference profile is not the declared visual candidate')
    _require(profile.get('candidate_only') is True and profile.get('startup_authorized') is False
             and profile.get('hardware_deployment_allowed') is False,
             'Candidate authorization flags must remain explicitly false')
    _require(profile.get('calibration_status') == CALIBRATION_STATUS, 'Reference is not a calibration')
    _require(profile.get('reference_model_hash_match') is True, 'Profile must declare exact model-hash check')
    _require(profile.get('units_assumption') == UNIT_ASSUMPTION,
             'Profile must explicitly declare the missing-source rad/metre assumption')
    _require(isinstance(profile.get('world_mount_note'), str) and bool(profile['world_mount_note'].strip()),
             'world_mount_note must be a nonempty provenance string')

    source = _absolute_path(profile.get('reference_file'), 'reference_file')
    urdf = _absolute_path(profile.get('reference_model_file'), 'reference_model_file')
    source_hash, urdf_hash = _sha(source), _sha(urdf)
    _require(source_hash == profile.get('reference_file_sha256'), 'Profile source SHA256 mismatch')
    _require(urdf_hash == profile.get('reference_model_sha256'), 'Profile URDF SHA256 mismatch')
    _require(_absolute_path(profile.get('input_source'), 'input_source') == source
             and profile.get('input_source_sha256') == source_hash,
             'Profile duplicated source provenance disagrees')

    loaded = load_start_pose_reference(source, urdf=urdf, assume_missing_rad_m=True)
    _require(loaded['reference_model_hash_match'] is True
             and loaded['reference_model_sha256'] == urdf_hash
             and loaded['source_file_sha256'] == source_hash,
             'Source/model changed during strict reference load')
    # Re-read only the two small known inputs, never hash a directory or a disk.
    _require(_sha(source) == source_hash and _sha(urdf) == urdf_hash,
             'Source/model changed during strict reference load')
    expected = loaded['nominal_joint_positions_by_name']
    values = profile.get('nominal_joint_positions_by_name')
    _require(isinstance(values, dict) and set(values) == set(SIM), 'Profile must contain exactly 18 named joints')
    _require(all(_number(values[name]) and values[name] == expected[name] for name in SIM),
             'Profile 18 named joint values differ from the immutable source/mimic expansion')
    _require(profile.get('mapping') == loaded['mapping'], 'Profile mapping differs from strict source mapping')
    mount = profile.get('world_mount_translation_m')
    _require(isinstance(mount, list) and len(mount) == 3 and all(_number(x) for x in mount),
             'world_mount_translation_m must have three finite numeric metres')
    _require(_sha(path) == digest, 'Reference profile changed during validation')
    return path, digest, profile, loaded


def apply_reference_start(stage, profile_path=DEFAULT_PROFILE):
    """Author only named drive targets and the existing robot mount translation.

    Returns a JSON-serializable ``reference_start_pose`` dict. The caller must
    remap ``joint_positions_by_name`` to its actual articulation DOF names and
    separately initialize/settle/inspect that articulation. Angular USD drive
    targets use degrees; prismatic targets use metres. No zero/sign offsets or
    finger-opening corrections are invented. All native validation is CPU-only.
    """
    from pxr import Gf, Usd, UsdGeom, UsdPhysics

    path, digest, profile, loaded = _validated_profile(profile_path)
    _require(isinstance(stage, Usd.Stage), 'Expected an existing native USD stage')
    _require(UsdGeom.GetStageMetersPerUnit(stage) == 1.0, 'Reference requires metre stage units')
    _require(UsdGeom.GetStageUpAxis(stage) == UsdGeom.Tokens.z, 'Reference requires Z-up stage')
    robot = stage.GetPrimAtPath(ROBOT_PATH)
    _require(bool(robot) and robot.IsActive() and bool(UsdGeom.Xformable(robot)), 'Missing active robot root')
    xform = UsdGeom.Xformable(robot)
    _require(not xform.GetResetXformStack(), 'Unexpected robot resetXformStack')
    ops = xform.GetOrderedXformOps()
    _require([str(op.GetOpName()) for op in ops] == ['xformOp:translate', 'xformOp:orient', 'xformOp:scale'],
             'Unexpected root xform stack; refusing to add/reorder transform ops')
    _require(all(not op.IsInverseOp() and not op.GetAttr().GetNumTimeSamples() for op in ops),
             'Animated/inverse root transforms are not supported by this static diagnostic')
    _require(ops[0].GetPrecision() == UsdGeom.XformOp.PrecisionDouble, 'Expected existing double translate')
    local = np.asarray(xform.GetLocalTransformation(), dtype=float)
    parent = np.asarray(UsdGeom.Xformable(robot.GetParent()).ComputeLocalToWorldTransform(0), dtype=float)
    _require(np.isfinite(local).all() and np.isfinite(parent).all(), 'Nonfinite root/parent transform')
    _require(np.allclose(parent, np.eye(4), rtol=0, atol=1e-12),
             'Nonidentity parent: local translate would not be the declared world mount')
    _require(np.allclose(local[:3, :3], np.eye(3), rtol=0, atol=1e-12)
             and np.allclose(np.asarray(ops[2].Get(), dtype=float), np.ones(3), rtol=0, atol=1e-12),
             'Nonidentity robot orientation/scale is outside this reference contract')

    positions = loaded['nominal_joint_positions_by_name']
    native = {}
    for prim in Usd.PrimRange(robot):
        if not prim.IsA(UsdPhysics.Joint):
            continue
        name = prim.GetName()
        if name in SIM:
            _require(name not in native, 'Duplicate named native joint: ' + name)
            native[name] = prim
        elif prim.IsA(UsdPhysics.RevoluteJoint) or prim.IsA(UsdPhysics.PrismaticJoint):
            raise ValueError('Unexpected movable native joint: ' + name)
    _require(set(native) == set(SIM), 'Missing native named joints')
    _, native_joints = native_usd_tree(stage, positions)
    _, urdf_joints = urdf_tree(loaded['reference_model_file'], positions, np.eye(4))
    writes, audit = [], []
    for name in SIM:
        prim = native[name]
        finger = 'finger' in name
        _require(prim.IsA(UsdPhysics.PrismaticJoint if finger else UsdPhysics.RevoluteJoint),
                 'Native joint type mismatch: ' + name)
        _require(name in native_joints, 'Native joint must have one parent/child: ' + name)
        native_info, urdf_info = native_joints[name], urdf_joints[name]
        _require(native_info['parent'] == ROBOT_PATH + '/' + urdf_info['parent']
                 and native_info['child'] == ROBOT_PATH + '/' + urdf_info['child'],
                 'Native joint bodies differ from exact URDF: ' + name)
        axis_child = native_info['local1'][:3, :3] @ native_info['axis']
        _require(np.linalg.norm(axis_child - urdf_info['axis']) < 1e-6,
                 'Native joint direction differs from URDF: ' + name)
        limits = native_info['limits']
        _require(limits is not None and np.isfinite(limits).all() and limits[0] <= limits[1]
                 and limits[0] <= positions[name] <= limits[1], 'Reference outside finite native limits: ' + name)
        mode = 'linear' if finger else 'angular'
        _require(prim.HasAPI(UsdPhysics.DriveAPI, mode), 'Missing native drive API: ' + name)
        attr = UsdPhysics.DriveAPI(prim, mode).GetTargetPositionAttr()
        _require(bool(attr) and not attr.GetNumTimeSamples(), 'Missing/animated targetPosition: ' + name)
        value = float(positions[name]) if finger else math.degrees(positions[name])
        writes.append((attr, value))
        audit.append({'name': name, 'joint_path': str(prim.GetPath()), 'drive': mode,
                      'target_position': value, 'target_unit': 'm' if finger else 'deg',
                      'source_value': positions[name], 'source_unit': 'm' if finger else 'rad'})

    edit = stage.GetEditTarget()
    layer = edit.GetLayer()
    _require(layer.permissionToEdit, 'Current USD edit layer is not writable')
    for attr, _ in [(ops[0].GetAttr(), None), *writes]:
        _require(bool(edit.MapToSpecPath(attr.GetPath())), 'Target cannot be mapped into current USD edit layer')
    # A final hash guard precedes any mutation. No source/profile is rewritten.
    _require(_sha(path) == digest and _sha(loaded['source_file']) == loaded['source_file_sha256']
             and _sha(loaded['reference_model_file']) == loaded['reference_model_sha256'],
             'Reference inputs changed before scene authoring')
    before = layer.ExportToString()
    try:
        _require(ops[0].Set(Gf.Vec3d(*profile['world_mount_translation_m'])), 'Failed to author mount translation')
        for attr, value in writes:
            _require(attr.Set(value), 'Failed to author native drive target: ' + str(attr.GetPath()))
    except Exception:
        # Restore only this in-memory edit layer if USD refuses a write; no Save.
        layer.ImportFromString(before)
        raise

    return {
        'schema': 'context_scene_reference_start_v1',
        'startup_scope': 'simulation_diagnostic_only',
        'activation_contract': 'Caller invokes only under explicit --reference-start-pose; default suite unchanged.',
        'candidate_only': True, 'startup_authorized': False,
        'training_eligible': False, 'hardware_deployment_allowed': False,
        'calibration_status': CALIBRATION_STATUS,
        'profile_path': str(path), 'profile_sha256': digest,
        'profile_file': str(path), 'profile_file_sha256': digest,
        'source_file': loaded['source_file'], 'source_file_sha256': loaded['source_file_sha256'],
        'reference_model_file': loaded['reference_model_file'],
        'reference_model_sha256': loaded['reference_model_sha256'], 'reference_model_hash_match': True,
        'joint_positions_by_name': dict(positions),
        'joint_units_by_name': {name: 'm' if 'finger' in name else 'rad' for name in SIM},
        'units_assumption': profile['units_assumption'], 'mapping': loaded['mapping'],
        'world_mount_translation_m': list(profile['world_mount_translation_m']),
        'world_mount_note': profile['world_mount_note'],
        'robot_prim_path': ROBOT_PATH, 'drive_target_audit': audit,
        'usd_initialization_targets_authored': True, 'live_articulation_positions_applied': False,
        'physics_advanced': False, 'layers_saved': False,
        'physical_startup_validated': False, 'full_task_execution_validated': False,
        'limitations': ['Visual approximation only; real encoder zero offsets and mounting are not calibrated.',
                        'Drive target authoring is not a measured pose, collision check, or training acceptance.'],
    }
