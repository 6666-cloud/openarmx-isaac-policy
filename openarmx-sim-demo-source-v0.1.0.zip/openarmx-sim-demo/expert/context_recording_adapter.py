"""Explicit raw-video-v2 frame transactions; no simulator or training acceptance.

Create before the numeric HDF. Bind its demo group and old numeric append method,
then begin_frame -> append(pre) -> seal_preaction -> physics -> append(post) ->
commit_frame. Finalize only AFTER closing numeric HDF and writing events/result.
The collector must not advance physics unless seal_preaction returned normally.
With opt-in asynchronous encoding this means independent immutable RGB/metadata
snapshots have been queued, not that codecs have finished. No partial/failed
queue is finalized; drain is required before numeric/video binding validation.
This module cannot police a caller that bypasses that hook.

RGB stays outside HDF. H264/yuv420p is lossy; only initial/current-event PNGs are
source-exact. Old raw-v1 files are never migrated, overwritten or relabelled.
"""
from __future__ import annotations

from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path

import h5py
import numpy as np

SCHEMA = 'context_raw_video_v2'
OUTER_SCHEMA = 'context_raw_video_commit_v1'
CAMERAS = ('chest', 'left_wrist', 'right_wrist')
INCOMPLETE = '.raw_incomplete'
FAILURE = 'RAW_FAILURE.json'
FINALIZED = 'RAW_FINALIZED.json'
KEYFRAME_EVENTS = {'instruction': 'instruction', 'grasp_success': 'grasp',
                   'release_verified_before_withdraw': 'release', 'release': 'release',
                   'place_success': 'annotation', 'placement_success': 'annotation',
                   'annotation': 'annotation'}


class RecordingAdapterError(RuntimeError):
    pass


def _require(condition, message):
    if not condition:
        raise RecordingAdapterError(message)


def _exists(path):
    try:
        path.lstat()
        return True
    except FileNotFoundError:
        return False


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _new_json(path, value):
    with path.open('xb') as handle:
        handle.write(json.dumps(value, allow_nan=False, ensure_ascii=False,
                                separators=(',', ':')).encode() + b'\n')
        handle.flush()
        os.fsync(handle.fileno())


def _sync_dir(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _plain(value):
    return np.asarray(value).tolist() if isinstance(value, (np.ndarray, np.generic)) else value


def _strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            _require(key not in result, 'Duplicate JSON key: ' + key)
            result[key] = value
        return result
    def constant(value):
        raise RecordingAdapterError('Nonfinite JSON value: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)


def _read_json(path):
    return _strict_json(path.read_text())


def _text(value):
    return value.decode() if isinstance(value, bytes) else str(value)


def _frame_datasets(group):
    datasets = {}
    def visit(name, item):
        if isinstance(item, h5py.Dataset) and not name.startswith('initial_state/'):
            datasets[name] = item
    group.visititems(visit)
    return datasets


def _validate_frame_bindings(group, video_root, count, events, *, numeric_block_size=256):
    """Compare every JSON/HDF field, using bounded HDF reads, never sampling.

    Zero selects the original per-frame HDF lookup/read path for equivalence
    diagnostics. Chunking changes only HDF access, not hashes, rows, dtypes or
    comparison tolerances (all values remain exactly equal, with no NaNs).
    """
    _require(type(numeric_block_size) is int and 0 <= numeric_block_size <= 4096,
             'Invalid numeric binding block size')
    _require(isinstance(events, list), 'Final event inventory must be a list')
    per_frame = {}
    for event in events:
        _require(isinstance(event, dict) and type(event.get('first_effective_frame')) is int
                 and 0 <= event['first_effective_frame'] <= count, 'Final event outside episode')
        index = event['first_effective_frame']
        # Terminal diagnostics have no subsequent pre-action observation.
        if index < count:
            per_frame.setdefault(index, []).append(event)
    streams = {}
    for camera in CAMERAS:
        for field, saved, shape in (('rendering_frame', 'rendering_frame', (count,)),
                                    ('rendering_time_s', 'rendering_time', (count,)),
                                    ('world_pose_wxyz', 'world_pose_wxyz', (count, 7)),
                                    ('observation_time_s', None, (count,))):
            path = f'camera/{camera}/{saved}' if saved else f'obs/{camera}_time'
            ds = group[path]
            _require(ds.shape == shape and ds.dtype.kind in 'fiu',
                     'Invalid numeric/video camera binding shape/dtype: ' + path)
            streams[(camera, field)] = (path, ds)
    block = {}
    with (video_root / 'frames.jsonl').open('rb') as index:
        for frame in range(count):
            if numeric_block_size and frame % numeric_block_size == 0:
                end = min(count, frame + numeric_block_size)
                block = {key: ds[frame:end] for key, (_, ds) in streams.items()}
                _require(all(np.isfinite(values).all() for values in block.values()),
                         'Nonfinite numeric/video camera binding')
            line = index.readline(96 * 1024 + 1)
            _require(0 < len(line) <= 96 * 1024 and line.endswith(b'\n'), 'Truncated/oversized frame index')
            row = _strict_json(line)
            _require(row['frame_id'] == frame and row['timestamp_ns'] == round(Fraction(frame * 1_000_000_000, 30)),
                     'Numeric/video frame lattice mismatch')
            _require(row.get('events') == effective_video_events(per_frame.get(frame, []), frame),
                     'Video current events differ from final numeric event inventory')
            render = row.get('render_metadata')
            _require(isinstance(render, dict) and set(render) == set(CAMERAS), 'Missing three-camera metadata')
            for camera in CAMERAS:
                metadata = render[camera]
                for field, saved in (('rendering_frame', 'rendering_frame'), ('rendering_time_s', 'rendering_time'),
                                     ('world_pose_wxyz', 'world_pose_wxyz')):
                    path, bound_ds = streams[(camera, field)]
                    ds = bound_ds if numeric_block_size else group[path]
                    actual = block[(camera, field)][frame % numeric_block_size] if numeric_block_size else ds[frame]
                    _require(np.isfinite(actual).all()
                             and np.array_equal(np.asarray(metadata[field], dtype=ds.dtype), actual),
                             'Numeric/video camera metadata mismatch: ' + camera + '/' + field)
                path, _ = streams[(camera, 'observation_time_s')]
                actual_time = (block[(camera, 'observation_time_s')][frame % numeric_block_size]
                               if numeric_block_size else group[path][frame])
                _require(np.isfinite(actual_time) and metadata['observation_time_s'] == float(actual_time),
                         'Numeric/video observation time mismatch')
        _require(index.read(1) == b'', 'Extra video metadata frame')


def effective_video_events(events, frame_id):
    """Only delivered events at this frame; never consult the protocol timeline.

    Only instruction/grasp/release/place and explicit annotations request PNGs;
    motion-preflight and other diagnostics remain in the complete event sidecar,
    avoiding a lossless PNG for every internal motion segment. Events at frame N
    have no image and belong only to that sidecar, not frame N-1. The caller
    supplies all newly effective events; selection never uses future task data.
    """
    _require(isinstance(events, (tuple, list)) and len(events) <= 64,
             'Current events must be a bounded list/tuple')
    output = []
    for event in events:
        _require(isinstance(event, dict), 'Event must be an object')
        _require(type(event.get('first_effective_frame')) is int and
                 event['first_effective_frame'] == frame_id,
                 'Only already-effective current-frame events are permitted')
        _require(type(event.get('time')) in (int, float) and
                 np.isfinite(event['time']) and abs(event['time'] - frame_id / 30) < 1e-6,
                 'Event time is not the current observation time')
        kind = event.get('kind')
        _require(isinstance(kind, str) and kind, 'Event kind is missing')
        mapped = KEYFRAME_EVENTS.get(kind)
        if mapped is None:
            continue
        item = {'kind': mapped, 'frame_id': frame_id,
                'timestamp_ns': round(Fraction(frame_id * 1_000_000_000, 30)),
                'raw_event': event}
        if kind == 'instruction':
            from context_instructions import require_policy_english
            require_policy_english(event.get('text'))
            item['instruction_en'] = event['text']
        output.append(item)
    return json.loads(json.dumps(output, allow_nan=False))


class RecordingAdapter:
    """Thin wrapper around existing numeric append; all failures are terminal.

    root may already contain scene assets, but not a prior numeric/video attempt.
    Construct before h5py.File(...,'w'); bind(group, original_append, contact_keys)
    afterward. Contact keys must enumerate the configured sensor inventory, not
    merely whichever sensors happened to write a row in the first frame.
    """
    def __init__(self, root, *, video_config=None):
        # Fail before creating any output if Isaac's Python lacks this dependency.
        from context_video_recorder import ContextVideoRecorder
        self.root = Path(root).resolve(strict=True)
        _require(self.root.is_dir(), 'Existing output directory required')
        for name in (INCOMPLETE, FAILURE, FINALIZED, 'trajectory.hdf5', 'rgb_stream'):
            _require(not _exists(self.root / name), 'Refusing an existing recording artifact: ' + name)
        self.state = 'recording'
        self.committed_frames = 0
        self.group = None
        self.video = None
        self._pending = None
        self._inventory = None
        _new_json(self.root / INCOMPLETE, {'schema': OUTER_SCHEMA,
                  'status': 'recording_or_interrupted', 'training_ready': False})
        _sync_dir(self.root)
        try:
            self.video = ContextVideoRecorder(self.root / 'rgb_stream', video_config)
        except BaseException as error:
            self._fail(error)
            raise

    def bind(self, group, numeric_append, *, contact_keys):
        try:
            _require(self.state == 'recording' and self.group is None, 'Already bound or failed')
            _require(callable(numeric_append), 'Numeric append callback must be callable')
            _require(group.name == '/data/demo_0', 'Expected existing canonical demo group')
            _require(Path(group.file.filename).resolve() == self.root / 'trajectory.hdf5',
                     'Numeric HDF must belong to this recording directory')
            _require(float(group.attrs.get('fps', 0)) == 30 and
                     _text(group.attrs.get('observation_timing', '')) == 'pre_action',
                     'Adapter requires 30 Hz pre-action observations')
            _require(isinstance(contact_keys, (list, tuple, set)) and len(set(contact_keys)) == len(contact_keys)
                     and {'contacts/left_finger_object', 'contacts/right_finger_object'} <= set(contact_keys)
                     and all(isinstance(k, str) and k.startswith('contacts/') for k in contact_keys),
                     'Explicit complete contact key inventory required')
            self.group, self.numeric_append = group, numeric_append
            self.contact_keys = set(contact_keys)
            group.attrs['schema_version'] = SCHEMA
            group.attrs['video_storage_path'] = 'rgb_stream'
            group.attrs['video_directory'] = 'rgb_stream'
            group.attrs['recording_commit_schema'] = OUTER_SCHEMA
            group.attrs['recording_committed_frames'] = 0
            group.attrs['recording_video_queue_size'] = self.video.config.cross_frame_queue_size
            group.attrs['recording_preaction_seal_policy'] = (
                'immutable_rgb_metadata_snapshot_owned_before_physics; video drain required before storage finalization'
                if self.video.config.cross_frame_queue_size else 'all_three_camera_encoders_join_before_physics')
            group.attrs['recording_committed_frames_scope'] = (
                'complete_numeric_frame_transactions; asynchronous_video_completion_verified_at_finalization'
                if self.video.config.cross_frame_queue_size else 'numeric_and_encoded_video_frame_transactions')
            group.attrs['recording_contact_keys'] = json.dumps(sorted(contact_keys))
            group.attrs['recording_keyframe_event_selection'] = json.dumps(KEYFRAME_EVENTS, sort_keys=True)
        except BaseException as error:
            self._fail(error)
            raise

    def begin_frame(self, frame_id, *, events=()):
        try:
            _require(self.state == 'recording' and self.group is not None and self._pending is None,
                     'Cannot begin a frame before bind/after failure/inside another frame')
            self.video.check_health()
            _require(type(frame_id) is int and frame_id == self.committed_frames, 'Noncontiguous frame ID')
            _require('initial_state' in self.group, 'Initial state must be saved before recording')
            state_keys = set(self.group['initial_state']) - {'joint_target'}
            _require({'joint_position', 'joint_velocity', 'left_tcp_pose', 'right_tcp_pose'} <= state_keys,
                     'Incomplete initial state inventory')
            core = {'actions', 'time', 'turn_id', 'instruction', 'phase', 'action_loss_mask',
                    'physics/step_index', 'physics/engine_time'}
            camera = {f'obs/{c}_time' for c in CAMERAS}
            camera |= {f'camera/{c}/{field}' for c in CAMERAS
                       for field in ('rendering_frame', 'rendering_time', 'world_pose_wxyz')}
            self._pre_keys = core | camera | {'obs/' + k for k in state_keys}
            self._post_keys = self.contact_keys | {'next_obs/' + k for k in state_keys}
            self._pending = {'id': frame_id, 'events': effective_video_events(events, frame_id),
                             'rgb': {}, 'values': {}, 'keys': set(), 'sealed': False}
        except BaseException as error:
            self._fail(error)
            raise

    def append(self, key, value):
        try:
            _require(self.state == 'recording' and self._pending is not None, 'No active frame')
            frame = self._pending
            _require(isinstance(key, str) and key not in frame['keys'], 'Duplicate/invalid frame key')
            _require(not key.startswith('initial_state/'), 'Initial state is not a per-frame append')
            image_keys = {f'obs/{c}_rgb': c for c in CAMERAS}
            if key in image_keys:
                _require(not frame['sealed'], 'RGB arrived after physics was permitted')
                _require(isinstance(value, np.ndarray) and value.shape == (480, 640, 3)
                         and value.dtype == np.uint8, 'Expected source uint8 RGB 480x640')
                frame['rgb'][image_keys[key]] = np.array(value, copy=True, order='C')
            else:
                _require(not key.endswith('_rgb'), 'Unknown RGB stream must not fall back to HDF')
                _require((not frame['sealed'] and not (key.startswith('next_obs/') or key.startswith('contacts/')))
                         or (frame['sealed'] and key in self._post_keys),
                         'Pre/post numeric append outside its frame phase')
                self.numeric_append(key, value)
                _require(key in self.group and len(self.group[key]) == frame['id'] + 1,
                         'Numeric append did not produce exactly one aligned row: ' + key)
                if key in self._pre_keys:
                    frame['values'][key] = _plain(value)
            frame['keys'].add(key)
        except BaseException as error:
            self._fail(error)
            raise

    def seal_preaction(self):
        """Must return successfully BEFORE caller applies action or steps physics."""
        try:
            _require(self.state == 'recording' and self._pending is not None, 'No active frame')
            frame = self._pending
            _require(not frame['sealed'], 'Pre-action frame already sealed')
            _require(self._pre_keys <= frame['keys'] and set(frame['rgb']) == set(CAMERAS),
                     'Incomplete pre-action state/action/language/camera evidence')
            values, index = frame['values'], frame['id']
            _require(abs(float(values['time']) - index / 30) < 1e-9, 'Invalid observation time lattice')
            from context_instructions import require_policy_english
            require_policy_english(values['instruction'])
            render = {}
            for camera in CAMERAS:
                rid = values[f'camera/{camera}/rendering_frame']
                rtime = values[f'camera/{camera}/rendering_time']
                relative = values[f'obs/{camera}_time']
                pose = values[f'camera/{camera}/world_pose_wxyz']
                _require(type(rid) is int and rid >= 0 and np.isfinite(rtime)
                         and abs(relative - index / 30) < 1e-4
                         and np.asarray(pose).shape == (7,) and np.isfinite(pose).all(),
                         'Invalid camera frame/time/pose evidence: ' + camera)
                render[camera] = {'frame_id': rid, 'timestamp_ns': round(float(rtime) * 1e9),
                                  'rendering_frame': rid, 'rendering_time_s': rtime,
                                  'observation_time_s': relative, 'world_pose_wxyz': pose}
            self.video.append(index, round(Fraction(index * 1_000_000_000, 30)), frame['rgb'],
                              events=frame['events'], render_metadata=render)
            frame['rgb'].clear()
            frame['values'].clear()
            frame['sealed'] = True
            return {'frame_id': index,
                    'preaction_encoded': self.video.config.cross_frame_queue_size == 0,
                    'preaction_snapshot_owned': True,
                    'preaction_queued': self.video.config.cross_frame_queue_size > 0,
                    'physics_may_advance': True,
                    'training_ready': False}
        except BaseException as error:
            self._fail(error)
            raise

    def commit_frame(self):
        try:
            _require(self.state == 'recording' and self._pending is not None
                     and self._pending['sealed'], 'Cannot commit before pre-action seal')
            self.video.check_health()
            frame = self._pending
            _require(self._post_keys <= frame['keys'], 'Missing next-state/contact data')
            numeric_keys = frame['keys'] - {f'obs/{c}_rgb' for c in CAMERAS}
            datasets = _frame_datasets(self.group)
            _require(set(datasets) == numeric_keys and all(len(ds) == frame['id'] + 1 for ds in datasets.values()),
                     'Numeric inventory/count differs from current complete frame')
            _require(self._inventory is None or numeric_keys == self._inventory, 'Frame inventory changed')
            if self._inventory is None:
                self._inventory = set(numeric_keys)
                self.group.attrs['recording_frame_keys'] = json.dumps(sorted(numeric_keys))
            self.group.attrs['recording_committed_frames'] = frame['id'] + 1
            self.group.file.flush()
            self.committed_frames += 1
            self._pending = None
            return self.committed_frames
        except BaseException as error:
            self._fail(error)
            raise

    def finalize(self):
        """Bind closed numeric HDF, event/result sidecars and source snapshots.

        Physical failure at a complete frame boundary may finalize storage. Any
        partial frame cannot. Neither outcome grants training eligibility.
        """
        try:
            _require(self.state == 'recording' and self._pending is None and self.committed_frames > 0,
                     'Cannot finalize an empty, failed or partial frame recording')
            _require(self.group is not None and not self.group.id.valid, 'Close numeric HDF before finalizing')
            # The asynchronous video's final rows must exist before we compare
            # them with the closed numeric action/state/event arrays.
            self.video.drain()
            for name in ('trajectory.hdf5', 'events.json', 'result.json', 'scene_config.json'):
                _require((self.root / name).is_file(), 'Missing outer episode artifact: ' + name)
            with h5py.File(self.root / 'trajectory.hdf5', 'r') as handle:
                group = handle['data/demo_0']
                _require(_text(group.attrs['schema_version']) == SCHEMA, 'Numeric schema changed')
                _require(int(group.attrs['num_samples']) == self.committed_frames
                         == int(group.attrs['recording_committed_frames']), 'Numeric committed count mismatch')
                datasets = _frame_datasets(group)
                _require(set(datasets) == self._inventory and all(len(x) == self.committed_frames for x in datasets.values()),
                         'Partial or changed numeric arrays at close')
                _require(json.loads(_text(group.attrs['events'])) == _read_json(self.root / 'events.json'),
                         'Numeric/sidecar events mismatch')
                result = _read_json(self.root / 'result.json')
                _require(json.loads(_text(group.attrs['result'])) == result, 'Numeric/sidecar result mismatch')
                _require(bool(group.attrs['success']) == (result.get('success') is True), 'Numeric/result success differs')
                _require(json.loads(_text(group.attrs['scene_config'])) == _read_json(self.root / 'scene_config.json'),
                         'Numeric/sidecar scene config mismatch')
                source_hashes = {k[:-7]: _text(v) for k, v in group.attrs.items() if k.endswith('.py_sha256')}
                _require({'context_recording_adapter.py', 'context_video_recorder.py'} <= set(source_hashes),
                         'Adapter/encoder source snapshots are required')
                for name, digest in source_hashes.items():
                    _require(Path(name).name == name and (self.root / name).is_file()
                             and file_sha256(self.root / name) == digest, 'Source snapshot hash mismatch: ' + name)
                _validate_frame_bindings(group, self.root / 'rgb_stream', self.committed_frames,
                                         _read_json(self.root / 'events.json'))
            video_receipt = self.video.finalize()
            _require(video_receipt['frame_count'] == self.committed_frames, 'Video and numeric frame counts differ')
            artifacts = {}
            # Snapshot every top-level raw file, not the lifecycle markers. This
            # binds calibration, USD/geometry, warmup and source evidence too.
            for path in sorted(self.root.iterdir()):
                if path.name in (INCOMPLETE, FAILURE, FINALIZED, 'rgb_stream'):
                    continue
                _require(not path.is_symlink() and path.is_file(), 'Unexpected unbound directory/symlink: ' + path.name)
                with path.open('rb') as stream:
                    os.fsync(stream.fileno())
                artifacts[path.name] = {'sha256': file_sha256(path), 'bytes': path.stat().st_size}
            receipt = {'schema': OUTER_SCHEMA, 'raw_schema': SCHEMA, 'status': 'storage_complete_only',
                       'frame_count': self.committed_frames, 'fps': 30,
                       'numeric_group': 'data/demo_0', 'artifacts': artifacts,
                       'source_hashes': source_hashes, 'video_directory': 'rgb_stream',
                       'video_finalized_sha256': file_sha256(self.root / 'rgb_stream/FINALIZED.json'),
                       'video_recording_config_sha256': file_sha256(self.root / 'rgb_stream/recording_config.json'),
                       'video_frames_jsonl_sha256': file_sha256(self.root / 'rgb_stream/frames.jsonl'),
                       'physical_result_success': result.get('success') is True,
                       'storage_finalized': True, 'training_ready': False,
                       'not_certified': ['physics/task/paired QA', 'pixel geometry and image quality',
                                         'official LeRobot compatibility', 'real hardware calibration']}
            _new_json(self.root / FINALIZED, receipt)
            _sync_dir(self.root)
            (self.root / INCOMPLETE).unlink()
            _sync_dir(self.root)
            self.state = 'finalized'
            return receipt
        except BaseException as error:
            self._fail(error)
            raise

    def _fail(self, error):
        if self.state != 'recording':
            return
        self.state = 'failed'
        if self.video is not None and self.video.state == 'recording':
            self.video.abort(str(error))
        try:
            if not _exists(self.root / INCOMPLETE):
                _new_json(self.root / INCOMPLETE, {'schema': OUTER_SCHEMA, 'status': 'failed', 'training_ready': False})
            _new_json(self.root / FAILURE, {'schema': OUTER_SCHEMA, 'error': str(error),
                      'committed_frames': self.committed_frames,
                      'pending_frame': None if self._pending is None else self._pending['id'],
                      'training_ready': False, 'storage_finalized': False})
            _sync_dir(self.root)
        except OSError:
            pass  # Precreated incomplete marker remains authoritative on ENOSPC.

    def abort(self, reason='caller aborted'):
        _require(self.state != 'finalized', 'Cannot abort finalized storage')
        self._fail(RecordingAdapterError(reason))


def validate_outer_recording(root, *, audit_video=True):
    """Read-only closed-storage audit. Never grants physical/training acceptance.

    audit_video=False verifies the outer immutable hash binding, not decoded
    integrity; callers must independently complete VideoEpisodeSource.audit().
    Returned hashes provide anchors to that reader; no metadata code is imported.
    """
    root = Path(root).resolve(strict=True)
    for location, markers in ((root, (INCOMPLETE, FAILURE)),
                              (root / 'rgb_stream', ('.incomplete', 'FAILURE.json'))):
        for marker in markers:
            _require(not _exists(location / marker), 'Incomplete/failed recording: ' + str(location / marker))
    manifest = _read_json(root / FINALIZED)
    _require(manifest.get('schema') == OUTER_SCHEMA and manifest.get('raw_schema') == SCHEMA
             and manifest.get('status') == 'storage_complete_only'
             and manifest.get('storage_finalized') is True and manifest.get('training_ready') is False,
             'Unsupported/missing outer completion evidence')
    count = manifest.get('frame_count')
    _require(type(count) is int and count > 0 and manifest.get('fps') == 30
             and manifest.get('numeric_group') == 'data/demo_0'
             and manifest.get('video_directory') == 'rgb_stream', 'Invalid outer frame/schema/path evidence')
    inventory = manifest.get('artifacts')
    _require(isinstance(inventory, dict) and
             {'trajectory.hdf5', 'events.json', 'result.json', 'scene_config.json',
              'context_recording_adapter.py', 'context_video_recorder.py'} <= set(inventory),
             'Missing bound numeric/source artifacts')
    for name, item in inventory.items():
        _require(isinstance(name, str) and name not in ('', '.', '..', INCOMPLETE, FAILURE, FINALIZED)
                 and Path(name).name == name and isinstance(item, dict), 'Invalid bound artifact path')
        path = root / name
        _require(path.is_file() and not path.is_symlink() and path.stat().st_size == item.get('bytes')
                 and file_sha256(path) == item.get('sha256'), 'Bound artifact changed: ' + name)
    video_root = root / 'rgb_stream'
    _require(video_root.is_dir() and not video_root.is_symlink(), 'Video directory alias is forbidden')
    for name, key in (('FINALIZED.json', 'video_finalized_sha256'),
                      ('recording_config.json', 'video_recording_config_sha256'),
                      ('frames.jsonl', 'video_frames_jsonl_sha256')):
        path = video_root / name
        _require(path.is_file() and not path.is_symlink() and file_sha256(path) == manifest.get(key),
                 'Bound video evidence changed: ' + name)
    with h5py.File(root / 'trajectory.hdf5', 'r') as handle:
        group = handle['data/demo_0']
        _require(_text(group.attrs.get('schema_version')) == SCHEMA
                 and _text(group.attrs.get('recording_commit_schema')) == OUTER_SCHEMA
                 and _text(group.attrs.get('video_directory')) == 'rgb_stream', 'Numeric schema/path mismatch')
        _require(group.attrs.get('num_samples') == count == group.attrs.get('recording_committed_frames'),
                 'Outer/numeric frame-count mismatch')
        datasets = _frame_datasets(group)
        expected = json.loads(_text(group.attrs['recording_frame_keys']))
        _require(set(datasets) == set(expected) and len(expected) == len(set(expected))
                 and not any(k.endswith('_rgb') for k in datasets)
                 and all(len(ds) == count for ds in datasets.values()), 'Numeric frame inventory/count mismatch')
        source_hashes = {k[:-7]: _text(v) for k, v in group.attrs.items() if k.endswith('.py_sha256')}
        _require(source_hashes == manifest.get('source_hashes') and all(
            name in inventory and inventory[name]['sha256'] == digest for name, digest in source_hashes.items()),
            'Source hash inventory mismatch')
        for attr, filename in (('events', 'events.json'), ('result', 'result.json'), ('scene_config', 'scene_config.json')):
            _require(json.loads(_text(group.attrs[attr])) == _read_json(root / filename), 'Sidecar/HDF mismatch: ' + attr)
        result = _read_json(root / 'result.json')
        _require(manifest.get('physical_result_success') == (result.get('success') is True),
                 'Physical-result label differs; storage must not promote it')
        times = group['time'][:]
        _require(times.shape == (count,) and np.isfinite(times).all()
                 and np.max(np.abs(times - np.arange(count) / 30)) < 1e-9, 'Numeric time lattice mismatch')
        _require(bool(group.attrs['success']) == (result.get('success') is True), 'Numeric/result success differs')
        _validate_frame_bindings(group, video_root, count, _read_json(root / 'events.json'))
    video_audit = None
    if audit_video:
        from context_video_source import VideoEpisodeSource
        source = VideoEpisodeSource(video_root, expected_receipt_sha256=manifest['video_finalized_sha256'])
        video_audit = source.audit()
        _require(video_audit.get('storage_integrity_passed') is True, 'Independent video storage audit failed')
    return {'schema': OUTER_SCHEMA, 'outer_hash_binding_passed': True,
            'storage_integrity_passed': bool(audit_video), 'decoded_video_audited': bool(audit_video),
            'frame_count': count, 'fps': 30, 'raw_schema': SCHEMA,
            'video_directory': str(video_root), 'outer_manifest_sha256': file_sha256(root / FINALIZED),
            'video_finalized_sha256': manifest['video_finalized_sha256'],
            'artifact_hashes': {k: v['sha256'] for k, v in inventory.items()},
            'video_storage_audit': video_audit, 'physical_result_success': manifest['physical_result_success'],
            'dataset_quality_passed': False, 'training_ready': False}
