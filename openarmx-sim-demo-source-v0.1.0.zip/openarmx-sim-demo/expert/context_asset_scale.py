"""Preserve and attest composed asset scale when Isaac normalizes xform ops.

This checks USD transforms, not cooked PhysX collision vertices. It assumes
unit-scale parents and positive, shear-free local scales, and fails closed
otherwise. Never changes a transform after object construction.
"""
import numpy as np

SCHEMA = 'context_asset_scale_v1'


def scale_vector(value):
    value = np.asarray(value, dtype=float)
    if value.shape != (3,) or not np.isfinite(value).all() or np.any(value <= 0):
        raise ValueError('Asset scale must be a positive finite length-three vector')
    return value.copy()


def matrix_scale(matrix):
    """USD/Gf uses row-vector matrices: row norms give scaled basis lengths."""
    matrix = np.asarray(matrix, dtype=float)
    if matrix.shape != (4, 4) or not np.isfinite(matrix).all():
        raise ValueError('Expected a finite 4x4 USD transform')
    if not np.allclose(matrix[:3, 3], 0, atol=1e-10) or not np.isclose(matrix[3, 3], 1):
        raise ValueError('Projective transforms are not supported')
    linear = matrix[:3, :3]
    scales = scale_vector(np.linalg.norm(linear, axis=1))
    basis = linear / scales[:, None]
    if np.linalg.det(basis) <= 0 or not np.allclose(basis @ basis.T, np.eye(3), atol=1e-5):
        raise ValueError('Reflected or sheared asset transforms are not supported')
    return scales


def expected_scales(stage, config):
    from pxr import UsdGeom
    result = {}
    for name, path in config['objects'].items():
        prim = stage.GetPrimAtPath(path)
        if not prim.IsValid():
            raise ValueError('Missing object prim: ' + path)
        expected = config['parameters'][name].get('applied_scale')
        source = 'scene_config.parameters.applied_scale'
        if expected is None:
            if 'protocol_plan' in config:
                raise ValueError('Suite object has no explicit applied_scale: ' + name)
            expected = matrix_scale(UsdGeom.Xformable(prim).GetLocalTransformation())
            source = 'legacy_composed_local_transform_before_wrapper'
        result[name] = dict(prim_path=path, expected_applied_scale=scale_vector(expected).tolist(),
                            expected_source=source)
    return result


def new_evidence(expected):
    return dict(schema=SCHEMA, expected=expected, checkpoints={}, success=False,
                scope='Composed USD local/world scale at initialization and finalization; unit parents, positive shear-free scale; not an independent cooked-collider audit')


def capture_checkpoint(stage, evidence, label):
    from pxr import UsdGeom
    cache = UsdGeom.XformCache()
    objects, errors = {}, []
    for name, spec in evidence['expected'].items():
        expected = scale_vector(spec['expected_applied_scale'])
        item = dict(spec, applied_scale_match=False)
        objects[name] = item
        try:
            prim = stage.GetPrimAtPath(spec['prim_path'])
            if not prim.IsValid():
                raise ValueError('Missing object prim')
            local_matrix = np.asarray(UsdGeom.Xformable(prim).GetLocalTransformation())
            world_matrix = np.asarray(cache.GetLocalToWorldTransform(prim))
            item.update(local_linear_basis=local_matrix[:3, :3].tolist(),
                        world_linear_basis=world_matrix[:3, :3].tolist())
            local = matrix_scale(local_matrix)
            world = matrix_scale(world_matrix)
            item.update(local_scale=local.tolist(), world_scale=world.tolist())
            item['applied_scale_match'] = bool(
                np.allclose(local, expected, rtol=1e-5, atol=1e-9)
                and np.allclose(world, expected, rtol=1e-5, atol=1e-9))
            if not item['applied_scale_match']:
                raise ValueError(f'Expected {expected.tolist()}, local {local.tolist()}, world {world.tolist()}')
        except Exception as exc:
            item['error'] = str(exc)
            errors.append(name + ': ' + str(exc))
    evidence['checkpoints'][label] = dict(objects=objects, success=not errors)
    evidence['success'] = all(check['success'] for check in evidence['checkpoints'].values())
    if errors:
        raise RuntimeError('Asset scale mismatch at ' + label + ': ' + '; '.join(errors))
    return evidence['checkpoints'][label]
