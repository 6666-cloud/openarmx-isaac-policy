"""Pure deterministic candidate sampling for the reviewed context task suite.

No Isaac, poses, actuator calls, file writes, variant input or safety certificate.
The caller must actually consume these values and record resulting measured
states/actions; sampler metadata and distinct seeds are NOT diversity evidence.
Ranges are bounded engineering candidates authorized for simulation exploration.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math

from context_task_protocols import BLOCK_PALETTE, TASK_IDS, get_protocol

SCHEMA = 'context_episode_sampling_candidate_v1'
DOMAIN_VERSION = 'reference_fixed_palette2_v07_small_workspace_v1'
STREAMS = ('scene_seed', 'nuisance_seed', 'motion_seed')
FRUITS = ('banana', 'apple', 'lemon')
DOMAINS = {
    'block_xy_offset_m_per_axis': [-0.006, 0.006],
    'fruit_xy_offset_m_per_axis': [-0.002, 0.002],
    'block_yaw_offset_rad': [-0.10, 0.10],
    'fruit_yaw_offset_rad': [0.0, 0.0],
    'per_object_duration_scale': [1.0, 1.25],
    'outside_lift_height_m': [0.065, 0.080],
    'outside_lift_hold_s': [0.4, 0.65],
    'instruction_hold_s': [0.5, 0.8],
}


def _require(ok, message):
    if not ok:
        raise ValueError(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False,
                      ensure_ascii=True).encode()


def _seed(value, name):
    _require(type(value) is int and 0 <= value < 2**32, name + ' must be uint32, not a boolean/float')
    return value


def _finite(value, label):
    _require(type(value) in (int, float) and math.isfinite(value), label + ' must be finite numeric, not bool')
    return float(value)


def _draw(task, seed, stream, object_name, field, limits):
    # Stateless per-field hash draws: stable under prop order changes, never
    # Python's randomized hash or a shared RNG affected by branch operations.
    key = [DOMAIN_VERSION, task, seed, stream, object_name, field]
    integer = int.from_bytes(hashlib.sha256(_canonical(key)).digest()[:8], 'big') >> 11
    unit = integer / 2**53  # exact 53-bit fraction, [0,1)
    return float(limits[0] + (limits[1] - limits[0]) * unit)


def object_names(task_id):
    _require(isinstance(task_id, str) and task_id in TASK_IDS, 'Unapproved context task')
    a, b = get_protocol(task_id, 'A')['props'], get_protocol(task_id, 'B')['props']
    _require(set(a) == set(b), 'A/B object inventories differ; explicit sampling design required')
    _require(all(a[name]['asset'] == b[name]['asset'] for name in a), 'A/B asset identities differ')
    _require(set(a) <= set(BLOCK_PALETTE) | set(FRUITS), 'Unsupported object kind requires a reviewed domain')
    return tuple(sorted(a))


def sample_episode(task_id, *, scene_seed, nuisance_seed, motion_seed):
    """Return paired expert configuration; all three explicit seeds are consumed.

    scene_seed: per-object source-area XY and block yaw.
    motion_seed: per-object slowdown, OUTSIDE-source lift height/hold.
    nuisance_seed: one common instruction-display hold for this episode.

    Fixed profile/mount, nominal slot centers, fixtures and branch semantics are
    not inputs or outputs. CTX05 may swap nominal locations by approved branch;
    the object-keyed offsets remain identical. Never pass this expert dictionary
    (or seeds/task IDs/variant) as model observations.
    """
    names = object_names(task_id)
    seeds = {key: _seed(value, key) for key, value in
             zip(STREAMS, (scene_seed, nuisance_seed, motion_seed))}
    objects = {}
    for name in names:
        block = name in BLOCK_PALETTE
        xy_domain = DOMAINS['block_xy_offset_m_per_axis' if block else 'fruit_xy_offset_m_per_axis']
        yaw_domain = DOMAINS['block_yaw_offset_rad' if block else 'fruit_yaw_offset_rad']
        draw_scene = lambda field, limits: _draw(task_id, scene_seed, 'scene_seed', name, field, limits)
        draw_motion = lambda field, limits: _draw(task_id, motion_seed, 'motion_seed', name, field, limits)
        objects[name] = {
            'kind': 'block' if block else 'fruit',
            'xy_offset_m': [draw_scene('source_dx', xy_domain), draw_scene('source_dy', xy_domain)],
            'yaw_offset_rad': draw_scene('source_yaw', yaw_domain),
            'duration_scale': draw_motion('slowdown', DOMAINS['per_object_duration_scale']),
            'lift_height_m': draw_motion('outside_lift_height', DOMAINS['outside_lift_height_m']),
            'lift_hold_s': draw_motion('outside_lift_hold', DOMAINS['outside_lift_hold_s']),
            'lift_scope': 'outside source-area tabletop picks only; do not alter shared-area/bowl extraction or obstacle routes',
        }
    body = {
        'schema': SCHEMA, 'domain_version': DOMAIN_VERSION, 'task_id': task_id,
        'seed_streams': seeds, 'domains': deepcopy(DOMAINS), 'objects': objects,
        'instruction_hold_s': _draw(task_id, nuisance_seed, 'nuisance_seed', 'episode',
                                   'instruction_hold', DOMAINS['instruction_hold_s']),
        'reference_pose_modified': False, 'robot_mount_modified': False,
        'nominal_slot_centers_modified': False, 'fixtures_modified': False,
        'object_scale_modified': False, 'mirrored': False,
        'branch_input_used': False, 'is_policy_input': False,
        'validated': False, 'collision_safety_certified': False,
        'trajectory_diversity_validated': False, 'training_ready': False,
        'hardware_deployment_allowed': False,
        'runtime_consumption_verified': False,
        'scope': 'Candidate sampling values only; complete physical/semantic/pixel/export and measured diversity checks remain mandatory',
    }
    return {**body, 'sample_sha256': hashlib.sha256(_canonical(body)).hexdigest()}


def validate_sample(sample):
    """Reject modified candidate values/claims; not a physical/dataset validator."""
    _require(isinstance(sample, dict), 'Sample must be a JSON object')
    seeds = sample.get('seed_streams')
    _require(isinstance(seeds, dict) and set(seeds) == set(STREAMS), 'Exactly three seed streams required')
    expected = sample_episode(sample.get('task_id'), **seeds)
    _require(_canonical(sample) == _canonical(expected), 'Sample differs from its deterministic domain/seed contract')
    return True


def perturb_initial_pose(nominal_position_m, nominal_yaw_rad, object_sample):
    """Pure arithmetic helper: change only XY/yaw; keep caller's Z unchanged.

    Use BEFORE creating/resetting the initial scene. This is not authorization
    to set object poses after the episode has started. The new yaw must be used
    when computing shape bottom-height/collision bounds by the scene builder.
    """
    _require(isinstance(nominal_position_m, (list, tuple)) and len(nominal_position_m) == 3,
             'Nominal position must be xyz')
    position = [_finite(v, 'Nominal position') for v in nominal_position_m]
    yaw = _finite(nominal_yaw_rad, 'Nominal yaw')
    _require(isinstance(object_sample, dict) and object_sample.get('kind') in ('block', 'fruit'), 'Unknown sample kind')
    offsets = object_sample.get('xy_offset_m')
    _require(isinstance(offsets, (list, tuple)) and len(offsets) == 2, 'Need two XY offsets')
    bound = .006 if object_sample['kind'] == 'block' else .002
    offsets = [_finite(v, 'XY offset') for v in offsets]
    _require(all(-bound <= value <= bound for value in offsets), 'XY offset outside candidate domain')
    yaw_offset = _finite(object_sample.get('yaw_offset_rad'), 'Yaw offset')
    _require(abs(yaw_offset) <= (.10 if object_sample['kind'] == 'block' else 0.0), 'Yaw offset outside candidate domain')
    return [position[0] + offsets[0], position[1] + offsets[1], position[2]], yaw + yaw_offset


def slowed_duration(nominal_seconds, object_sample):
    """Never speed up a planned segment; caller must apply once, consistently."""
    duration = _finite(nominal_seconds, 'Nominal duration')
    factor = _finite(object_sample.get('duration_scale'), 'Duration scale')
    _require(duration > 0 and 1.0 <= factor <= 1.25, 'Duration must be positive and slowdown within [1,1.25]')
    result = duration * factor
    _require(math.isfinite(result), 'Duration overflow')
    return result
