"""Explicit assets/cache/experience discovery; no workstation-specific paths."""
import os
from pathlib import Path


def asset_root():
    value = os.environ.get('OPENARMX_DEMO_ASSETS')
    if not value:
        raise RuntimeError('Set OPENARMX_DEMO_ASSETS to a prepared CTX01 asset bundle')
    root = Path(value).expanduser().resolve(strict=True)
    if not (root / 'ASSET_MANIFEST.json').is_file():
        raise RuntimeError('Asset bundle has no ASSET_MANIFEST.json; run prepare_assets.py')
    return root


def experience_path():
    explicit = os.environ.get('OPENARMX_ISAAC_EXPERIENCE')
    if explicit:
        return Path(explicit).expanduser().resolve(strict=True)
    import isaacsim
    path = Path(isaacsim.__file__).parent / 'apps/isaacsim.exp.full.kit'
    if not path.is_file():
        raise RuntimeError('Cannot locate full Kit experience; set OPENARMX_ISAAC_EXPERIENCE')
    return path
