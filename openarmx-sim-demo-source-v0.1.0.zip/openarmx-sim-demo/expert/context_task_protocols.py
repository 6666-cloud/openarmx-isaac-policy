"""Reviewed, coordinate-independent protocols for the 18 v0.7 context tasks.

This is an expert/audit specification, NOT a model observation. Only ``text``
from command operations may enter the language input. ``display_zh``, branch,
expected outcomes, object IDs, destination slots and route labels are not policy
inputs. CTX06--08 contain expert demonstrations whose unannounced choice cannot
be supervised as a policy action: their prefix action_loss is false, while the
recorded RGB/proprioception remains visible causal history.

The first suite requested on 2026-10-15 is one A/B pair per task, original layout
only. This does not replace the larger, independently randomized quota plan.
No geometry in this file is claimed physically validated; a runner must fail
closed on failed reachability, collisions, capacity, or semantic checks.
"""
from copy import deepcopy

from context_instructions import (
    CTX12_INSTRUCTIONS, LANGUAGE_CONTRACT, POLICY_LANGUAGE, require_policy_english,
)

PROTOCOL_VERSION = 'v0.7'
CATALOG_VERSION = 'context_task_protocols_en_v07_palette_v2'
BLOCK_PALETTE = ('red', 'blue', 'brown', 'flesh')
PALETTE_REVISION = {
    'version': 'red_blue_brown_flesh_v2',
    'date': '2026-10-15',
    'semantics': 'Keep the red/blue/brown/flesh palette. Task semantics are independently versioned by protocol_revision.',
    'historical_data_relabelled': False,
}
PROTOCOL_REVISION = {
    'version': PROTOCOL_VERSION,
    'changed_task_ids': ['CTX04', 'CTX05', 'CTX09', 'CTX10', 'CTX11'],
    'visual_change_task_ids': ['CTX06', 'CTX10'],
    'historical_data_relabelled': False,
    'physical_acceptance_required': True,
    'far_container_retrieval_permitted': False,
}
TASK_IDS = tuple(f'CTX{n:02d}' for n in (*range(1, 17), 18, 20))
REMOVED_TASK_IDS = ('CTX17', 'CTX19')
from runtime_paths import asset_root
ROOT = str(asset_root() / 'RoboLab/assets/objects')
ASSETS = {
    **{c: f'{ROOT}/basic/{c}_block.usd' for c in BLOCK_PALETTE},
    'banana': f'{ROOT}/ycb/banana.usd',
    'apple': f'{ROOT}/objaverse/apple_01.usd',
    'lemon': f'{ROOT}/fruits_veggies/lemon1.usd',
    'bowl': f'{ROOT}/ycb/bowl.usd',
    'plate': f'{ROOT}/vomp/plate_large/plate_large.usd',
    'brick': f'{ROOT}/ycb/brick.usd',
}

COMMON_SETUP_EN = (
    'Left and right refer to the robot. Use the left arm for objects in the left '
    'source area and the right arm for objects in the right source area. Move only '
    'one arm at a time; the other arm stays at its empty waiting pose. The near '
    'and far bowls or areas are closer to and farther from the robot, respectively. '
    'After releasing an object, withdraw that arm before the other arm enters '
    'the shared area. A pick-up-and-return step means lifting the object, holding '
    'it briefly, then releasing it stably at its starting position.'
)
COMMON_SETUP_ZH = (
    '左右以机器人为准；左侧物用左臂、右侧物用右臂。每次只动一臂，另一臂空载等待。'
    '近/远指距机器人较近/较远。释放并退出共享区后另一臂再进入。拿起放回含抬升、保持、稳定释放。'
)

COMMON_SUCCESS = {
    'stable_release_seconds_min': 0.5,
    'controlled_lift_m_min': 0.03,
    'controlled_lift_seconds_min': 0.3,
    'return_xy_error_m_max_candidate': 0.02,
    'non_target_xy_drift_m_max_candidate': 0.02,
    'completed_terminal_hold_seconds_min': 1.0,
    'candidate_thresholds_require_geometry_validation': True,
    'whole_episode': [
        'All commanded placements are supported stable releases, not hovering.',
        'No unauthorized object motion, dropped objects, arm-arm collision or simultaneous shared-area entry.',
        'A context error corrected later is still a context failure.',
        'No attachment, teleport, object-pose reset or forged historical action after initialization.',
    ],
}

TITLES_ZH = {
    'CTX01': '选择尚未操作的对象', 'CTX02': '根据所属关系选择水果',
    'CTX03': '根据历史分组关系选择伙伴', 'CTX04': '按放置顺序替换近碗对象',
    'CTX05': '单左臂对调两物的初始位置', 'CTX06': '复用历史放置区域',
    'CTX07': '继承过去的操作方式', 'CTX08': '继承绕行路线',
    'CTX09': '持续分类规则', 'CTX10': '三轮搬运中的一次性例外',
    'CTX11': '局部例外优先于一般规则', 'CTX12': '临时调换未完成步骤的顺序',
    'CTX13': '持物暂停后恢复原目标', 'CTX14': '执行中修改目标',
    'CTX15': '取消一个待办并保留其余', 'CTX16': '先完成插入任务，再返回原计划',
    'CTX18': '根据先验次数完成剩余循环', 'CTX20': '根据已完成前提执行剩余流程',
}


def _cmd(role, text, display_zh, *, action_loss=True):
    return {'op': 'command', 'role': role, 'text': require_policy_english(text),
            'display_zh': display_zh, 'action_loss': action_loss}


def _op(op, *, action_loss=True, **kwargs):
    return {'op': op, **kwargs, 'action_loss': action_loss}


def _wait(seconds=1.0, *, action_loss=True):
    return _op('wait', seconds=seconds, action_loss=action_loss)


def _home(side, *, action_loss=True):
    return _op('home', side=side, action_loss=action_loss)


def _cycle(obj, side, *, action_loss=True):
    return [_op('cycle', object=obj, side=side, action_loss=action_loss),
            _home(side, action_loss=action_loss)]


def _pp(obj, side, target, *, action_loss=True):
    return [_op('pick_place', object=obj, side=side, target_slot=target,
                action_loss=action_loss), _home(side, action_loss=action_loss)]


def _props(**slots):
    return {name: {'asset': ASSETS[name], 'slot': slot,
                   'side': 'shared' if slot == 'REPLACEMENT_SHARED'
                   else 'left' if slot.startswith('L') or slot.startswith('C_L')
                   else 'right' if slot.startswith('R') or slot.startswith('C_R')
                   else 'shared'} for name, slot in slots.items()}


def _containers(*slots, kind=None, side='shared'):
    return {slot: {'asset': ASSETS[kind or ('plate' if slot == 'P' else 'bowl')],
                   'kind': kind or ('plate' if slot == 'P' else 'bowl'),
                   'slot': slot, 'side': side, 'static': True} for slot in slots}


def _base(task_id, branch, props, containers=None):
    group = 'A' if task_id <= 'CTX04' else 'B' if task_id <= 'CTX08' else 'C' if task_id <= 'CTX12' else 'D' if task_id <= 'CTX16' else 'E'
    return {
        'task_id': task_id, 'variant': branch, 'protocol_version': PROTOCOL_VERSION,
        'catalog_version': CATALOG_VERSION, 'palette_revision': deepcopy(PALETTE_REVISION),
        'protocol_revision': deepcopy(PROTOCOL_REVISION),
        'instruction_language': POLICY_LANGUAGE,
        'language_contract': LANGUAGE_CONTRACT, 'display_language': 'zh',
        'title_zh_display': TITLES_ZH[task_id], 'capability_group': group,
        'mirror': False, 'requested_pair_count': 1,
        'props': props, 'containers': containers or {}, 'obstacles': {},
        'required_slots': [], 'timeline': [], 'expected': {},
        'success': deepcopy(COMMON_SUCCESS),
        'supervision': {
            'model_language_source': 'command.text only; current command plus causal past commands',
            'display_zh_is_model_input': False,
            'expert_hidden_fields_are_model_input': False,
            'prefix_history_recorded': True,
            'unannounced_expert_prefix_action_loss': False,
            'mask_semantics': 'Each operation action_loss applies to all pre-action frames generated until the next operation. Preserve observation/history frames even when action_loss is false.',
            'assumed_history_generates_actions': False,
        },
        'pairing': {
            'initial_physics_matching_required': task_id != 'CTX05',
            'query_state_matching_required': task_id not in ('CTX04', 'CTX10', 'CTX16'),
            'same_latest_query_required': task_id not in ('CTX04', 'CTX10'),
            'strict_memory_pair_metric_eligible': task_id not in ('CTX04', 'CTX10', 'CTX16'),
            'shared_scene_camera_motion_seed': True,
            'different_duration_does_not_justify_padding_actions': True,
        },
        'geometry_preconditions': [
            'Original layout only: L2/R2 are forward of L1/R1, not lateral substitutions.',
            'Validate all source, destination, full-arm trajectories, idle-arm clearance and retreat paths.',
            'Each target region must contain the whole supported object, with usable gripper clearance.',
            'No semantic success or calibration claim before physical validation.',
        ],
    }


def get_protocol(task_id, branch, *, query_owner='Tom'):
    """Return an independent complete episode specification for a normal A/B layout.

    ``query_owner`` selects the approved CTX02 paired query. The one-pair suite
    defaults to Tom; selecting Ben is supported but is not a third branch.
    """
    if task_id not in TASK_IDS:
        raise ValueError(f'Unsupported or removed task: {task_id}')
    if branch not in ('A', 'B'):
        raise ValueError('variant must be A or B')
    if query_owner not in ('Tom', 'Ben'):
        raise ValueError('CTX02 query owner must be Tom or Ben')
    a = branch == 'A'
    t = []
    if task_id == 'CTX01':
        p = _base(task_id, branch, _props(red='L1', blue='R1'), _containers('P'))
        seen, unseen, seen_side, target_side = ('red', 'blue', 'left', 'right') if a else ('blue', 'red', 'right', 'left')
        t += [_cmd('history', f'Pick up the {seen} block, hold it briefly, and return it to its original position.', f'拿起{("红" if a else "蓝")}块保持后放回原位。')]
        t += _cycle(seen, seen_side) + [_wait()]
        t += [_cmd('query', 'Put the block that was not picked up earlier onto the central plate.', '把刚才没拿过的那块放到中央盘子上。')]
        t += _pp(unseen, target_side, 'P')
        p['expected'] = {'historical_cycles': [seen], 'query_placements': [[unseen, 'P']], 'protected_after_query': [seen], 'arms': ['left', 'right']}
    elif task_id == 'CTX02':
        p = _base(task_id, branch, _props(apple='L1', lemon='R1'), _containers('P'))
        apple_owner, lemon_owner = ('Tom', 'Ben') if a else ('Ben', 'Tom')
        target = 'apple' if query_owner == apple_owner else 'lemon'
        t += [_cmd('history', f'The apple belongs to {apple_owner}, and the lemon belongs to {lemon_owner}.', f'苹果属于 {apple_owner}，柠檬属于 {lemon_owner}。'), _wait()]
        t += [_cmd('query', f"Please put {query_owner}'s fruit onto the central plate.", f'请把 {query_owner} 的水果放到中央盘子里。')]
        t += _pp(target, 'left' if target == 'apple' else 'right', 'P')
        p['expected'] = {'ownership': {'apple': apple_owner, 'lemon': lemon_owner}, 'query_owner': query_owner,
                         'query_placements': [[target, 'P']], 'protected': ['lemon' if target == 'apple' else 'apple'], 'cycles_before_query': 0}
        p['geometry_preconditions'] += ['Verify apple/lemon collision geometry, scale, stable grasp and plate containment; no ownership name labels in RGB.']
    elif task_id == 'CTX03':
        p = _base(task_id, branch, _props(red='L1', flesh='L2', blue='R1', brown='R2'), _containers('P'))
        partner = 'blue' if a else 'brown'
        text = 'The red and blue blocks form one group; the brown and flesh-colored blocks form another group.' if a else 'The red and brown blocks form one group; the blue and flesh-colored blocks form another group.'
        t += [_cmd('history', text, '红蓝一组、棕肉色一组。' if a else '红棕一组、蓝肉色一组。'), _wait()]
        t += [_cmd('query', 'Put the red block and its group partner onto the central plate.', '把红积木和它同组的另一块放到中央盘子上。')]
        t += _pp('red', 'left', 'P') + _pp(partner, 'right', 'P')
        p['expected'] = {'query_placements': [['red', 'P'], [partner, 'P']], 'protected': ['flesh', 'brown' if a else 'blue'], 'placement_order_required': False}
        p['geometry_preconditions'] += ['Plate must contain two independently supported blocks without stacking; grouping cannot be displayed by layout.']
    elif task_id == 'CTX04':
        p = _base(task_id, branch, _props(red='L1', blue='R1', brown='REPLACEMENT_SHARED'), _containers('N', 'F'))
        for obj, side, bowl in [('red', 'left', 'N' if a else 'F'),
                                ('blue', 'right', 'F' if a else 'N')]:
            t += [_cmd('history', f'Place the {obj} block into the {"near" if bowl == "N" else "far"} bowl.', f'把{("红" if obj == "red" else "蓝")}块放入{("近" if bowl == "N" else "远")}碗。')]
            t += _pp(obj, side, bowl)
        for text, zh in [('The recording label is ready.', '记录标签已经准备好。'), ('Please wait for the next instruction.', '请等待下一条指令。')]:
            t += [_cmd('distractor', text, zh), _wait()]
        ordinal = 'first' if a else 'second'
        t += [_cmd('query', f'Replace the block that was successfully placed into a bowl {ordinal} with the brown block. Set the removed block aside in the designated staging area. Place the brown block in that same bowl, and leave the other block untouched.', f'把第{("一" if a else "二")}次成功放进碗的方块换成棕色方块；旧物放本侧暂存区，棕块放原碗，另一个物体不动。')]
        selected, protected, side, staging = ('red', 'blue', 'left', 'S_L') if a else ('blue', 'red', 'right', 'S_R')
        t += _pp(selected, side, staging) + _pp('brown', side, 'N')
        p['expected'] = {'history_placement_order': ['red', 'blue'], 'selected_placement_ordinal': ordinal,
                         'query_placements': [[selected, staging], ['brown', 'N']],
                         'protected_after_query': [protected], 'replacement_arm': side,
                         'retrieval_container': 'N', 'far_container_retrieval_required': False}
        p['pairing']['metric'] = 'Order-reference workflow only: both branches select the near bowl, while query text and query-time object configurations differ.'
        p['pairing']['shortcut_warning'] = 'Always choosing the near bowl can solve both branches without remembering placement order; exclude from the strict matched-observation/matched-query memory metric.'
        p['geometry_preconditions'] += ['REPLACEMENT_SHARED is in front of N and reachable by either arm. Each staging area is ipsilateral and initially empty.']
    elif task_id == 'CTX05':
        props = _props(banana='S1' if a else 'S2', blue='S2' if a else 'S1')
        for prop in props.values():
            prop['side'] = 'left'
        p = _base(task_id, branch, props, _containers('P', kind='plate', side='left'))
        p['containers']['P']['placement_slots'] = {'banana': 'P_BANANA', 'blue': 'P_BLUE'}
        p['slot_parent_container'] = {'P_BANANA': 'P', 'P_BLUE': 'P'}
        t += [_cmd('history', 'Use the left arm to place the banana into the plate, then place the blue block into the same plate. Put both objects down separately without stacking them.', '只用左臂，先把香蕉放到盘里，再把蓝块放到同一盘里；两物分别稳定放下，不堆叠。')]
        t += _pp('banana', 'left', 'P_BANANA') + _pp('blue', 'left', 'P_BLUE') + [_wait()]
        t += [_cmd('query', 'Put the banana where the blue block was at the very start, and put the blue block where the banana was at the very start. Use only the left arm.', '把香蕉放到蓝块最初的位置，把蓝块放到香蕉最初的位置；只用左臂。')]
        t += _pp('banana', 'left', 'initial:blue') + _pp('blue', 'left', 'initial:banana')
        p['expected'] = {'history_placements': [['banana', 'P_BANANA'], ['blue', 'P_BLUE']],
                         'query_placements': [['banana', 'initial:blue'], ['blue', 'initial:banana']],
                         'query_arms': ['left', 'left'], 'final_empty_containers': ['P'],
                         'same_arm_all_moves': 'left', 'cross_side_grasp_required': False,
                         'far_container_retrieval_required': False}
        p['geometry_preconditions'] += ['S1, S2 and the low-rim plate must all lie in a physically validated comfortable left-arm workspace, not cross-side or maximum-extension reach.',
                                        'Both objects must fit the plate simultaneously without stacking and retain clear regrasp approaches. P_BANANA/P_BLUE are fixed, nonoverlapping expert-only slots and must match across branches at query.',
                                        'S1/S2 markers are neutral and identical across branches; never print object identity, initial assignment, branch, or internal plate-slot names.',
                                        'Only the left arm may move. The right arm remains at the identical safe waiting pose in both branches.']
        p['pairing']['initial_difference_reason'] = 'A/B exchange object identities between S1 and S2; query-time poses in the shared plate must match.'
    elif task_id == 'CTX06':
        p = _base(task_id, branch, _props(red='L1', blue='R1'))
        area = 'Z_N' if a else 'Z_F'
        t += [_cmd('history', 'First demonstrate one placement, then return the red block to its original position.', '先做一遍放置，再把红积木拿回原位。', action_loss=False)]
        t += _pp('red', 'left', area, action_loss=False) + _pp('red', 'left', 'initial:red', action_loss=False) + [_wait(action_loss=False)]
        t += [_cmd('query', 'Place the blue block in the area where the red block was placed earlier.', '把蓝积木放到刚才红积木放过的区域。')]
        t += _pp('blue', 'right', area)
        p['expected'] = {'demonstrated_area': area, 'query_placements': [['blue', area]], 'protected_after_query': ['red'], 'history_red_stable_release_then_return': True}
        p['required_slots'] += ['Z_N', 'Z_F']
        p['geometry_preconditions'] += ['Z_N/Z_F are two equally marked, empty, nonoverlapping table regions; both arms must reach either. Do not encode the demonstrated choice into text, marker, or model metadata.']
    elif task_id == 'CTX07':
        p = _base(task_id, branch, _props(red='L1', blue='R1'), _containers('P'))
        mode = 'push' if a else 'pick_place'
        t += [_cmd('history', 'Move the red block to the table area beside the plate.', '把红积木移到盘旁的桌面目标区。', action_loss=False)]
        t += [_op(mode, object='red', side='left', target_slot='BESIDE_P_L', action_loss=False), _home('left', action_loss=False), _wait(action_loss=False)]
        t += [_cmd('query', 'Using the same method as the other arm just used, move the blue block to its table area beside the plate.', '照刚才那条臂的方式，把蓝积木也移到盘旁的桌面目标区。')]
        t += [_op(mode, object='blue', side='right', target_slot='BESIDE_P_R'), _home('right')]
        p['expected'] = {'demonstrated_method': mode, 'query_method': mode, 'query_placements': [['blue', 'BESIDE_P_R']], 'protected_after_query': ['red'], 'push_height_m_max_candidate': 0.01, 'carry_lift_m_min_candidate': 0.03}
        p['required_slots'] += ['BESIDE_P_L', 'BESIDE_P_R']
        p['geometry_preconditions'] += ['Targets are on the table, NOT on the plate. Both push and carry must reach the same target without crossing the plate rim.']
    elif task_id == 'CTX08':
        p = _base(task_id, branch, _props(red='L1', blue='R1'))
        route = 'near' if a else 'far'
        p['obstacles'] = {side: {'asset': ASSETS['brick'], 'slot': f'BRICK_{side.upper()}', 'static': True} for side in ('left', 'right')}
        t += [_cmd('history', 'Move the red block around its obstacle to its receiving area.', '把红积木绕过本侧障碍搬到接收区。', action_loss=False)]
        t += [_op('route', object='red', side='left', target_slot='RECEIVE_L', route=route, action_loss=False), _home('left', action_loss=False), _wait(action_loss=False)]
        t += [_cmd('query', 'Move the blue block on the other side around its obstacle, using the same near-or-far side relative to the robot as before.', '按刚才相对于障碍的绕行侧，把另一边的蓝积木也搬过去。')]
        t += [_op('route', object='blue', side='right', target_slot='RECEIVE_R', route=route), _home('right')]
        p['expected'] = {'demonstrated_route': route, 'query_route': route, 'query_placements': [['blue', 'RECEIVE_R']], 'no_over_top_shortcut': True, 'no_obstacle_contact_or_motion': True}
        p['required_slots'] += ['RECEIVE_L', 'RECEIVE_R', 'BRICK_LEFT', 'BRICK_RIGHT']
        p['geometry_preconditions'] += ['Each side is ordered source-obstacle-receiver toward center. Bricks run front-to-back. The complete carried object and gripper must pass the near/far corridor without crossing above the obstacle. Validate BOTH corridors for BOTH arms.']
    elif task_id == 'CTX09':
        p = _base(task_id, branch, _props(banana='L1', blue='L2', apple='R1'), _containers('N', 'F', kind='plate'))
        fruit, block = ('N', 'F') if a else ('F', 'N')
        t += [_cmd('history', 'For this round, put fruit in the near plate and blocks in the far plate.' if a else 'For this round, put fruit in the far plate and blocks in the near plate.', '这轮水果放近盘、积木放远盘。' if a else '这轮水果放远盘、积木放近盘。')]
        for text, zh in [('The recording label is ready.', '记录标签已经准备好。'), ('Please wait for the next instruction.', '请等待下一条指令。')]:
            t += [_cmd('distractor', text, zh), _wait()]
        t += [_cmd('query', 'Tidy up these objects according to the sorting rule for this round.', '按这轮的分类规则，把桌上这些收好。')]
        t += _pp('banana', 'left', fruit) + _pp('apple', 'right', fruit) + _pp('blue', 'left', block)
        p['expected'] = {'query_placements': [['banana', fruit], ['apple', fruit], ['blue', block]], 'placement_order_required': False}
        p['geometry_preconditions'] += ['Both containers use the same low-rim plate model and scale. Either plate must fit banana AND apple simultaneously without stacking, with no contact-induced spill during the second placement. Both containers are placement-only targets.']
    elif task_id == 'CTX10':
        p = _base(task_id, branch, _props(red='L1'))
        p['required_slots'] += ['Z_N', 'Z_F']
        t += [_cmd('initial', 'Place the red block in the near area, then return it to its original position. Repeat this complete cycle three times. Use only the left arm.', '只用左臂把红块放到近桌面区，再放回原位，完整往返三次。')]
        targets = ['Z_N', 'Z_F' if a else 'Z_N', 'Z_N']
        for i, area in enumerate(targets):
            if i == 1:
                if a:
                    t += [_cmd('update', 'For the next cycle only, place the red block in the far area instead. Still return it to its original position afterward.', '仅下一轮改放远桌面区，之后仍放回原位。')]
                t += [_wait()]
            t += _pp('red', 'left', area) + _pp('red', 'left', 'initial:red')
        p['expected'] = {'cycle_area_sequence': targets, 'full_cycles': 3, 'same_arm_all_cycles': 'left',
                         'final_position': 'initial:red', 'no_restoration_instruction_before_third_cycle': True,
                         'far_container_retrieval_required': False,
                         'far_tabletop_retrieval_required': a}
        p['pairing']['metric'] = 'Process-scope evaluation, not a different-final-response memory query.'
        p['geometry_preconditions'] += ['Z_N/Z_F are flat, nonoverlapping table regions in a physically validated comfortable left-arm workspace. One left arm must stably release and regrasp in either region; no bowl or plate and no hovering-only pretend placement.',
                                        'Both regions carry the same static neutral N/NEAR and F/FAR sticky-note design in A and B. Markers stay outside landing areas and never change with the branch, instruction, or past action.']
    elif task_id == 'CTX11':
        p = _base(task_id, branch, _props(banana='L1', blue='L2', lemon='R1'), _containers('N', 'F', kind='plate'))
        exception = 'lemon' if a else 'banana'
        t += [_cmd('initial', 'Put fruit in the near plate and blocks in the far plate.', '水果放近盘，积木放远盘。')]
        t += [_cmd('update', f'The {exception} is an exception: put it in the far plate. Keep everything else unchanged.', f'{("柠檬" if a else "香蕉")}是例外，放远盘，其他不变。')]
        for text, zh in [('The recording label is ready.', '记录标签已经准备好。'), ('Please wait for the next instruction.', '请等待下一条指令。')]:
            t += [_cmd('distractor', text, zh), _wait()]
        t += [_cmd('query', 'Sort these objects according to the rules currently in effect.', '按有效规则整理这些物体。')]
        banana_bowl, lemon_bowl = ('N', 'F') if a else ('F', 'N')
        t += _pp('banana', 'left', banana_bowl) + _pp('lemon', 'right', lemon_bowl) + _pp('blue', 'left', 'F')
        p['expected'] = {'exception': exception, 'query_placements': [['banana', banana_bowl], ['lemon', lemon_bowl], ['blue', 'F']], 'placement_order_required': False}
        p['geometry_preconditions'] += ['Both containers use the same low-rim plate model and scale. Either plate must fit the larger of banana-plus-block and lemon-plus-block, without stacking. Both containers are placement-only targets.']
    elif task_id == 'CTX12':
        p = _base(task_id, branch, _props(red='L1', brown='L2', blue='R1'))
        t += [_cmd('initial', CTX12_INSTRUCTIONS['initial']['en'], CTX12_INSTRUCTIONS['initial']['zh_display'])]
        t += _cycle('red', 'left')
        if a:
            t += [_cmd('update', CTX12_INSTRUCTIONS['update']['en'], CTX12_INSTRUCTIONS['update']['zh_display'])]
        t += [_wait(), _cmd('query', CTX12_INSTRUCTIONS['query']['en'], CTX12_INSTRUCTIONS['query']['zh_display'])]
        for obj in (('brown', 'blue') if a else ('blue', 'brown')):
            t += _cycle(obj, 'right' if obj == 'blue' else 'left')
        p['expected'] = {'cycle_order': ['red', 'brown', 'blue'] if a else ['red', 'blue', 'brown'], 'cycle_count_by_object': {'red': 1, 'blue': 1, 'brown': 1}, 'repeat_completed_prefix': False}
    elif task_id in ('CTX13', 'CTX14'):
        p = _base(task_id, branch, _props(banana='L1'), _containers('N', 'F'))
        original, modified = ('N', 'F') if a else ('F', 'N')
        t += [_cmd('initial', f'Place the banana in the {"near" if original == "N" else "far"} bowl.', f'把香蕉放到{("近" if original == "N" else "远")}碗。')]
        t += [_op('pick', object='banana', side='left', target_slot='HOLD_NEUTRAL')]
        if task_id == 'CTX13':
            t += [_cmd('pause', 'Pause here and keep holding the banana.', '停一下，保持抓住香蕉。'), _op('hold', seconds=2.0)]
            t += [_cmd('query', 'Continue the original task.', '继续原来的任务。')]
            target = original
        else:
            t += [_cmd('update', f'Change the destination to the {"near" if modified == "N" else "far"} bowl. Keep holding the banana while waiting for confirmation.', f'把目标改成{("近" if modified == "N" else "远")}碗，保持抓持并等待确认。'), _op('hold', seconds=1.0)]
            t += [_cmd('query', 'Complete the task using the revised destination.', '按修改后的目标完成任务。')]
            target = modified
        t += [_op('place', object='banana', side='left', target_slot=target), _home('left')]
        p['expected'] = {'original_target': original, 'query_placements': [['banana', target]], 'continuous_grasp_before_release': True, 'single_grasp': True, 'neutral_hold_match': True, 'pause_drift_m_max_candidate': 0.02 if task_id == 'CTX13' else None}
        p['required_slots'] += ['HOLD_NEUTRAL']
        p['geometry_preconditions'] += ['Neutral held pose must be on a shared approach and not indicate N/F, clear of rims. Pause stops progress without releasing. No HOME movement while loaded.']
    elif task_id == 'CTX15':
        p = _base(task_id, branch, _props(red='L1', flesh='L2', blue='R1', brown='R2'), _containers('P'))
        cancelled = 'red' if a else 'blue'
        t += [_cmd('initial', 'Put all four blocks onto the central plate. Each arm is responsible for the objects on its own side.', '四块积木都放中央盘子，各臂负责本侧物体。')]
        t += [_cmd('update', f'Cancel the {cancelled} block. Leave it in place; keep the other tasks.', f'取消{("红" if a else "蓝")}块，保持它不动，其余任务保留。'), _wait()]
        t += [_cmd('query', 'Complete the tasks that are still active.', '把还保留的任务完成。')]
        # No task-level order is prescribed. Fill the far landing cells before
        # the near cell; brown precedes flesh because its open fingers sweep
        # through the neighboring flesh cell during release. Still both arms.
        objects = ('brown', 'flesh', 'blue') if a else ('brown', 'flesh', 'red')
        for obj in objects:
            t += _pp(obj, 'left' if obj in ('red', 'flesh') else 'right', 'P')
        p['expected'] = {'cancelled': cancelled, 'query_placements': [[obj, 'P'] for obj in objects], 'protected': [cancelled], 'placement_order_required': False, 'cancel_before_any_grasp': True}
        p['geometry_preconditions'] += ['Plate holds three blocks simultaneously, supported independently without stacking.']
    elif task_id == 'CTX16':
        p = _base(task_id, branch, _props(banana='L1', blue='R1'), _containers('N', 'F'))
        original, inserted = ('N', 'F') if a else ('F', 'N')
        t += [_cmd('initial', f'Place the banana in the {"near" if original == "N" else "far"} bowl.', f'把香蕉放到{("近" if original == "N" else "远")}碗。')]
        t += [_op('approach', object='banana', side='left', grasp=False)]
        t += [_cmd('interrupt', 'First put the blue block in the other bowl, relative to the destination of the original task. Leave the banana where it is for now.', '先把蓝积木放到原任务目标的另一只碗里，香蕉暂时不动。'), _home('left')]
        t += _pp('blue', 'right', inserted) + [_wait()]
        t += [_cmd('query', 'The urgent task is done. Continue the original task.', '紧急那件做完了，继续原来的任务。')]
        t += _pp('banana', 'left', original)
        p['expected'] = {'original_target': original, 'ordered_placements': [['blue', inserted], ['banana', original]], 'no_banana_grasp_before_insertion_complete': True, 'no_repeat_inserted_task': True}
        p['pairing']['metric'] = 'Interruption/recovery process; blue position at query reveals the opposite target, NOT strict current-view-matched memory.'
    elif task_id == 'CTX18':
        p = _base(task_id, branch, _props(red='L1', blue='R1'))
        assumed = 1 if a else 3
        t += [_cmd('initial', 'The complete plan has four successful pick-up-and-return cycles in total. Start with the left arm and the red block, then alternate arms, using each arm\'s own block.', '完整计划从左臂红块开始，两臂交替成功拿起并放回自己的积木，总共四次。')]
        t += [_cmd('premise', f'Assume that {"one cycle has" if a else "three cycles have"} already been successfully completed according to that plan.', f'假定已经按这个计划成功完成{("一次" if a else "三次")}。'), _wait()]
        t += [_cmd('query', 'Given that completed-progress premise, continue alternating until the remaining cycles are complete.', '根据这个已完成前提，继续交替，把剩下的次数补够。')]
        objects = ('blue', 'red', 'blue') if a else ('blue',)
        for obj in objects:
            t += _cycle(obj, 'left' if obj == 'red' else 'right')
        p['expected'] = {'assumed_completed_count': assumed, 'executed_this_episode_count': len(objects), 'cycle_order': list(objects), 'full_plan_count': 4, 'assumed_prefix_generates_physical_events': False, 'protected': [] if a else ['red']}
    else:  # CTX20
        p = _base(task_id, branch, _props(red='L1', brown='L2', blue='R1'))
        t += [_cmd('initial', 'The complete procedure is to pick up and briefly inspect each block, then return it to its original position, in the order red, blue, then brown.', '完整流程按红、蓝、棕的顺序逐个拿起检查，再放回原处。')]
        t += [_cmd('premise', 'Assume that the red block has already been completed.' if a else 'Assume that both the red and blue blocks have already been completed.', '假定红色已经完成。' if a else '假定红色和蓝色都已经完成。'), _wait()]
        t += [_cmd('query', 'Given that completion premise, finish the remaining inspections in the original order.', '根据这个已完成前提，按原顺序把剩下的检查完。')]
        objects = ('blue', 'brown') if a else ('brown',)
        for obj in objects:
            t += _cycle(obj, 'right' if obj == 'blue' else 'left')
        p['expected'] = {'assumed_completed': ['red'] if a else ['red', 'blue'], 'executed_this_episode': list(objects), 'cycle_order': list(objects), 'assumed_prefix_generates_physical_events': False, 'protected': ['red'] if a else ['red', 'blue']}
    # Setup is supplied to the policy in both branches, never a hidden convention.
    # A non-decisive setup command is masked only where the later expert prefix
    # also has an unannounced choice (CTX06--08).
    expert_prefix = task_id in ('CTX06', 'CTX07', 'CTX08')
    t.insert(0, _cmd('setup', COMMON_SETUP_EN, COMMON_SETUP_ZH, action_loss=not expert_prefix))
    t.append(_wait(1.0))
    p['timeline'] = t
    p['required_slots'] = sorted(set(p['required_slots']) | {v['slot'] for v in p['props'].values()} |
                                 {v['slot'] for v in p['containers'].values()} |
                                 {op['target_slot'] for op in t if 'target_slot' in op and not op['target_slot'].startswith('initial:')})
    p['supervision']['expert_observation_prefix'] = expert_prefix
    p['success']['task_specific'] = deepcopy(p['expected'])
    return p


def policy_commands(protocol):
    """Safe language projection. Never expose the full bilingual expert catalog."""
    return [require_policy_english(op['text']) for op in protocol['timeline'] if op['op'] == 'command']


def suite_protocols():
    """Return the requested 36 normal-layout complete episode specifications."""
    return [get_protocol(task, branch) for task in TASK_IDS for branch in ('A', 'B')]


def far_container_retrievals(protocol):
    """Find semantic far-container regrasp operations, not far-table regrasp.

    This tracks named expert slots only; it does not replace contact, geometry,
    whole-arm reachability, or physical success validation.
    """
    initial = {name: prop['slot'] for name, prop in protocol['props'].items()}
    location = dict(initial)
    parent = protocol.get('slot_parent_container', {})
    far = {slot for slot in protocol['containers'] if slot == 'F'}
    violations = []
    for index, op in enumerate(protocol['timeline']):
        obj = op.get('object')
        if obj is None:
            continue
        source = location[obj]
        if op['op'] in ('pick', 'pick_place', 'cycle', 'push', 'route'):
            if parent.get(source, source) in far:
                violations.append({'operation_index': index, 'object': obj,
                                   'source_slot': source, 'op': op['op']})
        if op['op'] == 'pick':
            location[obj] = '__held__'
        elif op['op'] in ('pick_place', 'place', 'push', 'route'):
            target = op['target_slot']
            location[obj] = initial[target.split(':', 1)[1]] if target.startswith('initial:') else target
    return violations


def validate_protocol(protocol):
    """Pure semantic/schema checks; not a physical feasibility certification."""
    valid_ops = {'command', 'wait', 'cycle', 'pick_place', 'pick', 'place', 'home', 'push', 'route', 'hold', 'approach'}
    assert protocol['task_id'] in TASK_IDS
    assert protocol['variant'] in ('A', 'B')
    assert protocol['mirror'] is False
    assert protocol['instruction_language'] == POLICY_LANGUAGE
    assert protocol['language_contract'] == LANGUAGE_CONTRACT
    assert protocol['protocol_version'] == PROTOCOL_VERSION
    assert protocol['catalog_version'] == CATALOG_VERSION
    timeline = protocol['timeline']
    assert timeline and timeline[0]['op'] == 'command'
    for op in timeline:
        assert op['op'] in valid_ops, op
        assert isinstance(op['action_loss'], bool), op
        if op['op'] == 'command':
            require_policy_english(op['text'])
            assert op['role'] in {'setup', 'initial', 'history', 'distractor', 'query', 'update', 'pause', 'interrupt', 'premise'}
            assert isinstance(op['display_zh'], str) and op['display_zh']
        if 'object' in op:
            assert op['object'] in protocol['props'], op
        if 'side' in op:
            assert op['side'] in ('left', 'right')
        if 'target_slot' in op and op['target_slot'].startswith('initial:'):
            assert op['target_slot'].split(':', 1)[1] in protocol['props']
        if op['op'] == 'route':
            assert op['route'] in ('near', 'far')
    if protocol['supervision']['expert_observation_prefix']:
        query_idx = next(i for i, op in enumerate(timeline) if op.get('role') == 'query')
        assert all(not op['action_loss'] for op in timeline[:query_idx])
        assert all(op['action_loss'] for op in timeline[query_idx:])
    assert timeline[-1]['op'] == 'wait' and timeline[-1]['seconds'] >= 1.0
    assert not far_container_retrievals(protocol), 'v0.7 forbids retrieval from a far bowl or far plate'
    return True


if __name__ == '__main__':
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', choices=TASK_IDS)
    parser.add_argument('--variant', choices=['A', 'B'], default='A')
    options = parser.parse_args()
    protocols = [get_protocol(options.task, options.variant)] if options.task else suite_protocols()
    for protocol in protocols:
        validate_protocol(protocol)
    print(json.dumps(protocols[0] if options.task else protocols, ensure_ascii=False, indent=2))
