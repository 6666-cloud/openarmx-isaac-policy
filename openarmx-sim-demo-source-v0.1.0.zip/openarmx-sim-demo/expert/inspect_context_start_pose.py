"""CPU-only named pose/URDF/USD audit; never launches Isaac or controls hardware.

Missing input units require an explicit rad/metre assumption. Finger targets are
preserved; only the URDF-declared unit-multiplier/zero-offset mimic is expanded.
The output is a visual-reference candidate, not calibration or a collision test.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import numpy as np
from scipy.spatial.transform import Rotation

from runtime_paths import asset_root
BASE = asset_root()
SOURCE = BASE / 'reference/start_pose.json'
URDF = BASE / 'reference/robot.urdf'
SCENE = BASE / 'datasets/context_suite_ab_v1/CTX01/A/attempt_002/raw/scene.usda'
REAL = [n for side in ('left', 'right') for n in
        [*[f'openarmx_{side}_joint{i}' for i in range(1, 8)], f'openarmx_{side}_finger_joint1']]
SIM = [n for side in ('left', 'right') for n in
       [*[f'openarmx_{side}_joint{i}' for i in range(1, 8)], *[f'openarmx_{side}_finger_joint{i}' for i in (1, 2)]]]


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def no_duplicate_keys(pairs):
    output = {}
    for key, value in pairs:
        require(key not in output, f'Duplicate JSON key: {key}')
        output[key] = value
    return output


def load_pose(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=no_duplicate_keys)


def map_named_pose(payload, *, assume_missing_rad_m=False):
    require(isinstance(payload, dict), 'Pose must be an object')
    names, values = payload.get('joint_names'), payload.get('positions')
    require(isinstance(names, list) and len(names) == 16 and all(isinstance(n, str) for n in names), 'Expected16 exact string joint names')
    require(len(set(names)) == 16 and set(names) == set(REAL), 'Missing/extra/duplicate joint names')
    require(isinstance(values, list) and len(values) == 16, 'Expected16 positions')
    require(all(type(v) in (int, float) and math.isfinite(v) for v in values), 'Positions must be finite numbers, not booleans/strings')
    model_hash = payload.get('model_sha256')
    require(isinstance(model_hash, str) and bool(re.fullmatch('[0-9a-f]{64}', model_hash)), 'Invalid model_sha256')
    expected_units = ['m' if 'finger' in n else 'rad' for n in names]
    units = payload.get('units')
    if units is None:
        require(assume_missing_rad_m, 'Input has no units; explicit arm-rad/finger-metre assumption required')
    else:
        require(units == expected_units, 'Input units must match named revolute rad/prismatic m, no implicit conversion')
    by_name = dict(zip(names, values))
    canonical16 = [by_name[n] for n in REAL]
    canonical18 = [by_name[n.replace('finger_joint2', 'finger_joint1')] for n in SIM]
    return {'input_joint_names': names, 'input_positions_preserved': values,
            'units_missing_in_source': units is None,
            'unit_assumption': 'arm rad; reported finger1 m' if units is None else None,
            'real_nominal_joint_names': REAL, 'real_nominal_positions': canonical16,
            'simulation_joint_names': SIM, 'simulation_positions': canonical18,
            'simulation_units': ['m' if 'finger' in n else 'rad' for n in SIM],
            'source_index_for_simulation_joint': [names.index(n.replace('finger_joint2', 'finger_joint1')) for n in SIM],
            'finger2_expansion_requires_native_URDF_mimic_check': True,
            'finger_targets_modified': False, 'unknown_sign_or_zero_offsets_applied': False,
            'must_remap_to_articulation_dof_names_by_name': True, 'model_sha256': model_hash}


def pose_record(matrix):
    quat = Rotation.from_matrix(matrix[:3, :3]).as_quat()
    return {'xyz_m': matrix[:3, 3].tolist(), 'orientation_wxyz': [float(quat[3]), *quat[:3].tolist()]}


def urdf_tree(path, positions, root_transform):
    tree = ET.parse(path).getroot()
    joints = {}
    children = {}
    for element in tree.findall('joint'):
        parent = element.find('parent').get('link'); child = element.find('child').get('link')
        require(child not in children, 'URDF child has multiple parents')
        origin = element.find('origin')
        xyz = np.fromstring(origin.get('xyz', '0 0 0') if origin is not None else '0 0 0', sep=' ')
        rpy = np.fromstring(origin.get('rpy', '0 0 0') if origin is not None else '0 0 0', sep=' ')
        T = np.eye(4); T[:3, 3] = xyz; T[:3, :3] = Rotation.from_euler('xyz', rpy).as_matrix()
        axis_element = element.find('axis')
        axis = np.fromstring(axis_element.get('xyz') if axis_element is not None else '1 0 0', sep=' ')
        limit = element.find('limit')
        info = {'name': element.get('name'), 'kind': element.get('type'), 'parent': parent, 'child': child,
                'axis': axis, 'origin': T,
                'limits': [float(limit.get('lower')), float(limit.get('upper'))] if limit is not None else None,
                'mimic': element.find('mimic')}
        children[child] = info; joints[info['name']] = info
    roots = {link.get('name') for link in tree.findall('link')} - set(children)
    require(roots == {'world'}, f'Unexpected URDF roots: {roots}')
    result = {'world': root_transform}
    def visit(link):
        if link in result: return result[link]
        j = children[link]; q = positions.get(j['name'], 0.0); motion = np.eye(4)
        if j['kind'] == 'revolute': motion[:3, :3] = Rotation.from_rotvec(j['axis'] * q).as_matrix()
        elif j['kind'] == 'prismatic': motion[:3, 3] = j['axis'] * q
        else: require(j['kind'] == 'fixed', 'Unsupported URDF joint type')
        result[link] = visit(j['parent']) @ j['origin'] @ motion
        return result[link]
    for link in children: visit(link)
    return result, joints


def load_start_pose_reference(source=SOURCE, *, urdf=URDF, assume_missing_rad_m=False):
    """Load immutable source by name; validate exact URDF hash/limits/mimics.

    This API does not import pxr/Isaac, apply a pose, change the mount, open the
    fingers, or certify hardware. Caller must index returned18 names against the
    actual articulation dof_names and independently validate physical startup.
    """
    mapped = map_named_pose(load_pose(source), assume_missing_rad_m=assume_missing_rad_m)
    require(sha(urdf) == mapped['model_sha256'], 'Reference model hash mismatch')
    positions = dict(zip(SIM, mapped['simulation_positions']))
    _, joints = urdf_tree(urdf, positions, np.eye(4))
    for name in SIM:
        j = joints[name]
        require(j['kind'] == ('prismatic' if 'finger' in name else 'revolute'), 'URDF joint type mismatch')
        require(j['limits'][0] <= positions[name] <= j['limits'][1], 'Reference pose outside URDF limits: ' + name)
        if name.endswith('finger_joint2'):
            mimic = j['mimic']
            require(mimic is not None and mimic.get('joint') == name.replace('finger_joint2', 'finger_joint1')
                    and float(mimic.get('multiplier', '1')) == 1 and float(mimic.get('offset', '0')) == 0,
                    'Finger2 expansion not supported by exact URDF mimic')
    return {'source_file': str(Path(source).resolve()), 'source_file_sha256': sha(source),
            'reference_model_file': str(Path(urdf).resolve()), 'reference_model_sha256': sha(urdf),
            'reference_model_hash_match': True, 'nominal_joint_positions_by_name': positions,
            'mapping': mapped, 'calibration_status': 'not_calibrated_visual_reference_only',
            'hardware_deployment_allowed': False, 'pose_applied': False}


def native_usd_tree(stage, positions):
    from pxr import UsdGeom, UsdPhysics
    def joint_frame(position, quaternion):
        T = np.eye(4); T[:3, 3] = position
        T[:3, :3] = Rotation.from_quat([*quaternion.GetImaginary(), quaternion.GetReal()]).as_matrix()
        return T
    children, joints = {}, {}
    for prim in stage.Traverse():
        if not str(prim.GetPath()).startswith('/world/OpenArmX/') or not prim.IsA(UsdPhysics.Joint): continue
        joint = UsdPhysics.Joint(prim); parents, targets = joint.GetBody0Rel().GetTargets(), joint.GetBody1Rel().GetTargets()
        if not parents: continue
        require(len(parents) == len(targets) == 1, 'Expected one native parent and child')
        axis, limits, kind = None, None, 'fixed'
        if prim.IsA(UsdPhysics.RevoluteJoint):
            dof = UsdPhysics.RevoluteJoint(prim); kind = 'revolute'
            limits = np.deg2rad([dof.GetLowerLimitAttr().Get(), dof.GetUpperLimitAttr().Get()])
        elif prim.IsA(UsdPhysics.PrismaticJoint):
            dof = UsdPhysics.PrismaticJoint(prim); kind = 'prismatic'
            limits = np.array([dof.GetLowerLimitAttr().Get(), dof.GetUpperLimitAttr().Get()])
        if kind != 'fixed': axis = np.eye(3)['XYZ'.index(dof.GetAxisAttr().Get())]
        local0 = joint_frame(joint.GetLocalPos0Attr().Get(), joint.GetLocalRot0Attr().Get())
        local1 = joint_frame(joint.GetLocalPos1Attr().Get(), joint.GetLocalRot1Attr().Get())
        info = {'name': prim.GetName(), 'parent': str(parents[0]), 'child': str(targets[0]),
                'kind': kind, 'axis': axis, 'limits': limits, 'local0': local0, 'local1': local1}
        require(info['child'] not in children, 'Native child has multiple parents')
        children[info['child']] = info; joints[info['name']] = info
    result = {}
    def visit(path):
        if path in result: return result[path]
        if path not in children:
            result[path] = np.asarray(UsdGeom.Xformable(stage.GetPrimAtPath(path)).ComputeLocalToWorldTransform(0)).T
            return result[path]
        j = children[path]; motion = np.eye(4); q = positions.get(j['name'], 0.0)
        if j['kind'] == 'revolute': motion[:3, :3] = Rotation.from_rotvec(j['axis'] * q).as_matrix()
        if j['kind'] == 'prismatic': motion[:3, 3] = j['axis'] * q
        result[path] = visit(j['parent']) @ j['local0'] @ motion @ np.linalg.inv(j['local1'])
        return result[path]
    for path in children: visit(path)
    return result, joints


def body_mesh_bounds(stage, link_path, world_transform):
    from pxr import Usd, UsdGeom
    root = stage.GetPrimAtPath(link_path); cache = UsdGeom.XformCache()
    pieces = []
    for prim in Usd.PrimRange(root, Usd.TraverseInstanceProxies()):
        if not prim.IsA(UsdGeom.Mesh): continue
        points = np.asarray(UsdGeom.Mesh(prim).GetPointsAttr().Get(), dtype=float)
        relative, resets = cache.ComputeRelativeTransform(prim, root)
        require(not resets, 'Reset transform in native link mesh')
        local = np.c_[points, np.ones(len(points))] @ np.asarray(relative)
        pieces.append((local @ world_transform.T)[:, :3])
    require(bool(pieces), 'Missing native link mesh: ' + link_path)
    points = np.concatenate(pieces)
    return {'min_xyz_m': points.min(0).tolist(), 'max_xyz_m': points.max(0).tolist(),
            'native_vertex_count': len(points), 'scope': 'Authored mesh vertices, not cooked PhysX contact geometry.'}


def inspect(source=SOURCE, scene=SCENE, urdf=URDF, *, assume_missing_rad_m=False):
    from pxr import Usd, UsdGeom
    loaded_reference = load_start_pose_reference(source, urdf=urdf, assume_missing_rad_m=assume_missing_rad_m)
    mapped = loaded_reference['mapping']
    stage = Usd.Stage.Open(str(scene)); require(bool(stage), 'Cannot open native scene')
    positions = dict(zip(SIM, mapped['simulation_positions']))
    usd_poses, usd_joints = native_usd_tree(stage, positions)
    root_transform = usd_poses['/world/OpenArmX/world']
    urdf_poses, urdf_joints = urdf_tree(urdf, positions, root_transform)
    contract = json.loads((BASE / 'configs/context_real_mapping.json').read_text())
    require(contract['joint_order'] == REAL, 'Real nominal contract order changed')
    limits = []
    for name in SIM:
        j, u = usd_joints[name], urdf_joints[name]; q = positions[name]
        require(j['kind'] == u['kind'], 'Native/URDF joint type differs')
        native_axis_child = j['local1'][:3, :3] @ j['axis']
        axis_error = float(np.linalg.norm(native_axis_child - u['axis']))
        require(axis_error < 1e-6, 'Native joint direction differs from URDF child-coordinate axis')
        require(j['limits'][0] <= q <= j['limits'][1] and u['limits'][0] <= q <= u['limits'][1], 'Pose outside USD or URDF limit: ' + name)
        if name.endswith('finger_joint2'):
            mimic = u['mimic']; require(mimic is not None, 'Finger2 lacks native URDF mimic')
            require(mimic.get('joint') == name.replace('finger_joint2', 'finger_joint1') and float(mimic.get('multiplier', '1')) == 1 and float(mimic.get('offset', '0')) == 0, 'Unsupported finger mimic')
        limits.append({'name': name, 'position': q, 'unit': 'rad' if j['kind'] == 'revolute' else 'm',
                       'USD_limits': j['limits'].tolist(), 'URDF_limits': u['limits'],
                       'USD_axis_in_joint_frame': j['axis'].tolist(), 'USD_axis_in_child_link_frame': native_axis_child.tolist(),
                       'URDF_axis_in_child_link_frame': u['axis'].tolist(), 'axis_error': axis_error, 'within_both_limits': True})
    table_box = UsdGeom.BBoxCache(0, ['default', 'render', 'proxy']).ComputeWorldBound(stage.GetPrimAtPath('/world/table')).ComputeAlignedBox()
    table_min, table_max = np.array(table_box.GetMin()), np.array(table_box.GetMax())
    bodies, sides = {}, {}
    max_position_error = max_rotation_error = 0.0
    for side in ('left', 'right'):
        link_records = {}
        for suffix in [*[f'link{i}' for i in range(8)], 'hand', 'hand_tcp', 'left_finger', 'right_finger']:
            name = f'openarmx_{side}_{suffix}'; T = usd_poses['/world/OpenArmX/' + name]; U = urdf_poses[name]
            ep = float(np.linalg.norm(T[:3, 3] - U[:3, 3])); er = float(Rotation.from_matrix(T[:3, :3] @ U[:3, :3].T).magnitude())
            max_position_error = max(max_position_error, ep); max_rotation_error = max(max_rotation_error, er)
            link_records[name] = {**pose_record(T), 'independent_URDF_position_error_m': ep, 'independent_URDF_angle_error_rad': er}
            if suffix in ('hand', 'left_finger', 'right_finger'):
                bodies[name] = body_mesh_bounds(stage, '/world/OpenArmX/' + name, T)
        tcp = usd_poses[f'/world/OpenArmX/openarmx_{side}_hand_tcp']
        home = np.array([.30, .20 if side == 'left' else -.20, .44]); down = Rotation.from_euler('xyz', [np.pi, 0, 0]).as_matrix()
        sides[side] = {'TCP': pose_record(tcp), 'TCP_positive_z_world': tcp[:3, 2].tolist(),
            'angle_tool_z_from_vertical_down_deg': float(np.rad2deg(np.arccos(np.clip(-tcp[2, 2], -1, 1)))),
            'orientation_difference_from_current_down_home_deg': float(np.rad2deg(Rotation.from_matrix(tcp[:3, :3] @ down.T).magnitude())),
            'current_home_xyz_m': home.tolist(), 'TCP_minus_home_xyz_m': (tcp[:3, 3] - home).tolist(),
            'distance_to_current_home_m': float(np.linalg.norm(tcp[:3, 3] - home)),
            'TCP_minus_table_top_z_m': float(tcp[2, 3] - table_max[2]), 'links': link_records}
    minimum_z = min(v['min_xyz_m'][2] for v in bodies.values())
    delta_z = max(0.0, float(table_max[2] + .06 - minimum_z))
    max_gripper_x = max(v['max_xyz_m'][0] for v in bodies.values())
    zero_usd, _ = native_usd_tree(stage, dict.fromkeys(SIM, 0.0))
    zero_urdf, _ = urdf_tree(urdf, dict.fromkeys(SIM, 0.0), root_transform)
    zero_errors = []
    for path, matrix in zero_usd.items():
        name = path.rsplit('/', 1)[-1]
        if name not in zero_urdf: continue
        reference = zero_urdf[name]
        zero_errors.append((float(np.linalg.norm(matrix[:3, 3] - reference[:3, 3])),
                            float(Rotation.from_matrix(matrix[:3, :3] @ reference[:3, :3].T).magnitude())))
    require(max_position_error < 1e-5 and max_rotation_error < 1e-5, 'Native/URDF FK mismatch; do not create candidate')
    known_models = [urdf, BASE / 'openarmx_robot_import_test.usd', *[BASE / 'configuration' / ('openarmx_robot_import_test_' + n + '.usd') for n in ('base', 'physics', 'sensor')]]
    return {'schema': 'context_start_pose_real_reference_v1', 'status': 'offline_visual_reference_candidate_not_calibrated',
        'candidate_only': True, 'startup_authorized': False, 'hardware_deployment_allowed': False,
        'world_mount_translation_m': [-.08, 0.0, .10],
        'world_mount_note': 'Explicit preview-only simulation scene adaptation; keep source joints unchanged. Not a real-world mounting calibration.',
        'FK_and_mesh_audit_mount_translation_m': root_transform[:3, 3].tolist(),
        'preview_expected_TCP_world_at_config_mount': {side: {
            'xyz_m': (np.asarray(sides[side]['TCP']['xyz_m']) + np.array([-.08, 0, .10]) - root_transform[:3, 3]).tolist(),
            'orientation_wxyz': sides[side]['TCP']['orientation_wxyz'],
            'scope': 'Offline rigid mount translation prediction, not a settled physical measurement.'} for side in ('left', 'right')},
        'nominal_joint_positions_by_name': loaded_reference['nominal_joint_positions_by_name'],
        'reference_model_hash_match': True,
        'reference_file': loaded_reference['source_file'], 'reference_file_sha256': loaded_reference['source_file_sha256'],
        'reference_model_file': loaded_reference['reference_model_file'], 'reference_model_sha256': loaded_reference['reference_model_sha256'],
        'units_assumption': mapped['unit_assumption'], 'calibration_status': 'not_calibrated_visual_reference_only',
        'input_source': str(source), 'input_source_sha256': sha(source), 'mapping': mapped,
        'model_hash_matched_exact_file': str(urdf), 'known_model_hashes_only': {str(p): sha(p) for p in known_models},
        'scene_geometry_reference': str(scene), 'scene_sha256': sha(scene),
        'scene_reference_note': 'Read-only saved suite composition with the actual current table placement/scale and robot mount, not the active simulator.',
        'robot_world_mount': pose_record(root_transform), 'joint_audit': limits,
        'independent_URDF_vs_USD_max_position_error_m': max_position_error,
        'independent_URDF_vs_USD_max_orientation_error_rad': max_rotation_error,
        'model_zero_pose_URDF_vs_USD_max_position_error_m': max(x[0] for x in zero_errors),
        'model_zero_pose_URDF_vs_USD_max_orientation_error_rad': max(x[1] for x in zero_errors),
        'zero_pose_scope': 'Model-coordinate mathematical zero only, not independently measured real encoder zero.',
        'world_table_bounds_m': {'minimum': table_min.tolist(), 'maximum': table_max.tolist()},
        'gripper_native_mesh_world_bounds': bodies, 'sides': sides,
        'mount_height_visual_candidate': {'apply': False, 'base_delta_z_m': delta_z,
            'new_robot_root_translation_m': [float(root_transform[0, 3]), float(root_transform[1, 3]), float(root_transform[2, 3] + delta_z)],
            'lowest_gripper_after_world_z_m': minimum_z + delta_z, 'target_mesh_clearance_above_table_m': .06,
            'joint_values_and_relative_link_shape_unchanged': True,
            'rounded_up_preview_mount_z_m': math.ceil((root_transform[2, 3] + delta_z) * 100) / 100,
            'meaning': 'Rigid robot mounting translation for simulation-scene adaptation, not a joint zero correction or real calibration. Native visual mesh clearance only, not a full collision or reachability certificate.'},
        'table_forward_visual_candidate': {'apply': False, 'minimum_table_delta_x_for_60mm_initial_gripper_gap_m': max(0.0, float(max_gripper_x + .06 - table_min[0])),
            'meaning': 'Move rear table edge beyond all initial hand/finger visual bounds; whole arm/table/support/task reachability must be rechecked.'},
        'calibration_limits': ['Missing source units accepted only by explicit rad/m assumption.',
            'Exact URDF file hash and nominal FK agreement do not prove real joint zeros, motor directions, base mounting, fingertip gap, or camera calibration.',
            'Finger0 remains0, finger2 copies native URDF mimic only; no automatic opening or pose correction.',
            'Original pose has low TCP/gripper bounds relative to current table; unsafe to apply dynamically without scene/collision checks.',
            'Parent reviews user photograph visually. No photograph metrology or learned-policy/hardware validation is asserted.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--source', type=Path, default=SOURCE)
    parser.add_argument('--scene', type=Path, default=SCENE); parser.add_argument('--urdf', type=Path, default=URDF)
    parser.add_argument('--assume-missing-rad-m', action='store_true'); parser.add_argument('--summary', action='store_true')
    args = parser.parse_args(); result = inspect(args.source, args.scene, args.urdf, assume_missing_rad_m=args.assume_missing_rad_m)
    if args.summary:
        result = {k: result[k] for k in ('model_hash_matched_exact_file', 'robot_world_mount', 'world_table_bounds_m', 'gripper_native_mesh_world_bounds', 'mount_height_visual_candidate', 'table_forward_visual_candidate', 'independent_URDF_vs_USD_max_position_error_m', 'independent_URDF_vs_USD_max_orientation_error_rad')}
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == '__main__': main()
