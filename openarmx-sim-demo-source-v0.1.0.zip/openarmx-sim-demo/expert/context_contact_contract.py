"""Shape/finite checks only; zero contact does not certify a physical path."""
import numpy as np


def check_contact_matrix(value, *, actors, filters, label):
    array = np.asarray(value)
    expected = (int(actors), int(filters), 3)
    if min(expected[:2]) < 1 or array.shape != expected or not np.isfinite(array).all():
        raise RuntimeError(f'Invalid contact matrix {label}: {array.shape}, expected {expected}, finite required')
    return {'shape': list(array.shape), 'actor_count': expected[0], 'filter_count': expected[1],
            'finite': True, 'scope': 'dimensions only, not nonzero contact or collision certification'}
