"""Three rigidly mounted cameras for the OpenArmX context-data pilot.

Import after SimulationApp startup; initialize after World.reset(). The caller
owns every physics step, render and warmup. This module never advances time.
Typical use::

    rig = ContextCameraRig(world.stage)
    rig.initialize()
    # Caller renders until CameraFrameError no longer reports warmup pending.
    frames = rig.capture(expected_time=world.current_time)

The JSON poses are approximate pilot poses, NOT measured real-robot calibration.
All returned poses use metres and scalar-first quaternions. A camera pose maps
USD camera coordinates (+X right, +Y up, -Z forward) into its reference frame.
Calibration also contains parent-from-optical transforms for the usual pinhole
convention (+X right, +Y down, +Z forward), which is the convention of K.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "configs/context_camera_rig_pilot.json"
VIEW_NAMES = ("chest", "left_wrist", "right_wrist")


class CameraFrameError(RuntimeError):
    """Frame unavailable, old, or unsynchronized; do not record this observation."""


def _numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    return np.asarray(value)


def _pose_matrix(position: np.ndarray, quaternion: np.ndarray) -> np.ndarray:
    """Column-vector transform, without adding a scipy dependency."""
    w, x, y, z = quaternion / np.linalg.norm(quaternion)
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = [
        [1 - 2 * (y*y + z*z), 2 * (x*y - z*w), 2 * (x*z + y*w)],
        [2 * (x*y + z*w), 1 - 2 * (x*x + z*z), 2 * (y*z - x*w)],
        [2 * (x*z - y*w), 2 * (y*z + x*w), 1 - 2 * (x*x + y*y)],
    ]
    result[:3, 3] = position
    return result


class ContextCameraRig:
    """Attach three Camera prims to body/hand links, preserving parent motion.

    ``capture()`` makes copies of the latest camera buffers. By default it
    rejects repeat simulation times, old frame IDs, unequal view frame IDs,
    and cross-camera time mismatch. Pass ``expected_time`` to additionally
    reject a synchronized but stale set relative to the current physics state.
    Call ``reset_capture_history()`` only at an episode/time reset boundary.
    """

    def __init__(self, stage: Any, config_path: str | Path | None = None):
        from pxr import Sdf, UsdGeom

        self.stage = stage
        self.config_path = Path(config_path or DEFAULT_CONFIG).resolve()
        config_bytes = self.config_path.read_bytes()
        self.config = json.loads(config_bytes)
        self.config_sha256 = hashlib.sha256(config_bytes).hexdigest()
        self.cameras: dict[str, Any] = {}
        self._last: dict[str, tuple[int, float]] = {}
        self._initialized = False

        if self.config.get("schema_version") != 1:
            raise ValueError("Unsupported camera rig schema_version")
        if set(self.config.get("cameras", {})) != set(VIEW_NAMES):
            raise ValueError(f"Camera config must contain exactly {VIEW_NAMES}")
        if self.config.get("camera_frequency") != -1:
            raise ValueError("Pilot cameras must acquire every render (camera_frequency=-1)")
        if self.config.get("recording_fps", 0) <= 0:
            raise ValueError("recording_fps must be positive")
        for key in ("synchronization_tolerance_s", "expected_time_tolerance_s"):
            if not np.isfinite(self.config[key]) or self.config[key] < 0:
                raise ValueError(f"{key} must be finite and nonnegative")
        self.stage_meters_per_unit = float(UsdGeom.GetStageMetersPerUnit(stage))
        self.stage_up_axis = str(UsdGeom.GetStageUpAxis(stage))
        if not np.isclose(self.stage_meters_per_unit, 1.0, rtol=0, atol=1e-12):
            raise ValueError(
                f"Camera rig requires a metre stage; found metersPerUnit={self.stage_meters_per_unit}. "
                "Set World(stage_units_in_meters=1.0) before constructing the rig."
            )
        if self.stage_up_axis != "Z":
            raise ValueError("Camera rig requires a Z-up stage; author stage metadata before construction")
        robot_root = str(self.config["robot_root"]).rstrip("/")
        used_paths = set()
        for name in VIEW_NAMES:
            spec = self.config["cameras"][name]
            parent_path = spec["parent_prim"]
            if not parent_path.startswith(robot_root + "/"):
                raise ValueError(f"{name}: mount must be below robot_root")
            parent = stage.GetPrimAtPath(parent_path)
            if not parent or not parent.IsActive() or parent.IsInstanceProxy() or parent.IsInstance():
                raise ValueError(f"{name}: mount is absent, inactive, or instanced: {parent_path}")
            if not Sdf.Path.IsValidIdentifier(spec["prim_name"]):
                raise ValueError(f"{name}: prim_name must be a single USD identifier")
            path = parent_path + "/" + spec["prim_name"]
            if path in used_paths:
                raise ValueError(f"Camera path reused: {path}")
            used_paths.add(path)
            if spec.get("camera_axes") != "usd":
                raise ValueError(f"{name}: config poses must explicitly use camera_axes=usd")
            for key, size in (("position_m", 3), ("orientation_wxyz", 4)):
                value = np.asarray(spec[key], dtype=np.float64)
                if value.shape != (size,) or not np.isfinite(value).all():
                    raise ValueError(f"{name}: invalid {key}")
            q_norm = np.linalg.norm(spec["orientation_wxyz"])
            if not np.isclose(q_norm, 1, rtol=0, atol=1e-5):
                raise ValueError(f"{name}: quaternion must have unit norm")
            resolution = spec["resolution_wh"]
            if len(resolution) != 2 or any(type(v) is not int or v <= 0 for v in resolution):
                raise ValueError(f"{name}: resolution_wh must be positive integer width,height")
            for key in ("focal_length_mm", "horizontal_aperture_mm"):
                if not np.isfinite(spec[key]) or spec[key] <= 0:
                    raise ValueError(f"{name}: invalid {key}")
            clip = np.asarray(spec["clipping_range_m"], dtype=float)
            if clip.shape != (2,) or not np.isfinite(clip).all() or not 0 < clip[0] < clip[1]:
                raise ValueError(f"{name}: invalid clipping_range_m")

    def initialize(self) -> None:
        """Create sensors after World.reset(); no stepping or rendering occurs."""
        from isaacsim.sensors.camera import Camera
        from pxr import UsdGeom

        if self._initialized:
            raise RuntimeError("This rig is already initialized")
        for name in VIEW_NAMES:
            spec = self.config["cameras"][name]
            path = spec["parent_prim"] + "/" + spec["prim_name"]
            existing = self.stage.GetPrimAtPath(path)
            if existing and not existing.IsA(UsdGeom.Camera):
                raise ValueError(f"Refusing to overwrite non-camera prim: {path}")
            prim = UsdGeom.Camera.Define(self.stage, path)
            prim.GetPrim().SetCustomDataByKey("contextCamera:calibrationStatus", self.config["calibration_status"])
            camera = Camera(path, name="context_" + name, frequency=-1,
                            resolution=tuple(spec["resolution_wh"]))
            camera.initialize()
            camera.set_frequency(-1)
            # Always parent-local: a wrist sensor follows hand motion physically.
            quaternion = np.asarray(spec["orientation_wxyz"], dtype=np.float64)
            camera.set_local_pose(
                translation=np.asarray(spec["position_m"], dtype=np.float64),
                orientation=quaternion / np.linalg.norm(quaternion), camera_axes="usd",
            )
            UsdGeom.Xformable(camera.prim).SetResetXformStack(False)
            camera.set_projection_mode("perspective")
            camera.set_projection_type("pinhole")
            # Isaac 4.5 setters multiply by 10. Keep conventional USD/RTX lens
            # magnitudes (e.g. focalLength=10.5, horizontalAperture=20.955).
            # Dividing nominal mm by 1000 produces focalLength=.105, below
            # renderer-supported lens magnitudes: the pilot image then zoomed
            # ~4.76x although get_intrinsics_matrix still returned the intended
            # K. The pinhole projection depends on the ratio, not physical lens
            # size. These are nominal optics, explicitly not real calibration.
            camera.set_focal_length(float(spec["focal_length_mm"]) / 10.0)
            camera.set_horizontal_aperture(float(spec["horizontal_aperture_mm"]) / 10.0)
            camera.set_lens_aperture(0.0)  # No depth-of-field blur in this pilot.
            camera.set_clipping_range(*map(float, spec["clipping_range_m"]))
            self.cameras[name] = camera
        self._initialized = True
        self.reset_capture_history()

    def reset_capture_history(self) -> None:
        """Allow a new timeline after an external episode reset; does not render."""
        self._last.clear()

    def capture(self, expected_time: float | None = None, require_new: bool = True) -> dict[str, dict[str, Any]]:
        """Return the latest synchronized frames, or raise CameraFrameError.

        The caller must render immediately after reading/setting the physics
        observation and before calling this method; do not step physics between
        render and capture. World pose is read now, not reconstructed from an
        old render. Passing expected_time checks that this pose and RGB refer
        to the same simulation time. Warmup is owned by the caller.
        """
        if not self._initialized:
            raise RuntimeError("Call initialize() after World.reset() first")
        if expected_time is not None and not np.isfinite(expected_time):
            raise ValueError("expected_time must be finite")
        result = {}
        stamps = {}
        for name, camera in self.cameras.items():
            # Snapshot only the required RGB channels below. clone=True in the
            # Isaac SDK deepcopies the entire RGBA frame (and any annotators)
            # first; that extra allocation is redundant. There is no render or
            # app update between reading these scalars and taking the RGB copy.
            frame = camera.get_current_frame(clone=False)
            width, height = self.config["cameras"][name]["resolution_wh"]
            rgba = _numpy(frame.get("rgba"))
            if rgba.shape not in ((height, width, 3), (height, width, 4)) or rgba.dtype != np.uint8:
                raise CameraFrameError(f"{name}: RGB is not ready; caller must render/warm up all cameras")
            frame_id = int(frame.get("rendering_frame", 0))
            time = float(frame.get("rendering_time", float("nan")))
            if frame_id <= 0 or not np.isfinite(time):
                raise CameraFrameError(f"{name}: valid render timestamp has not arrived")
            if require_new and name in self._last:
                previous_frame, previous_time = self._last[name]
                if frame_id <= previous_frame or time <= previous_time:
                    raise CameraFrameError(f"{name}: duplicate/old render ({frame_id}, {time}); previous={self._last[name]}")
            if expected_time is not None:
                tolerance = self.config["expected_time_tolerance_s"]
                if abs(time - expected_time) > tolerance:
                    raise CameraFrameError(f"{name}: rendered at {time}, expected physics time {expected_time}")
            rgb = np.array(rgba[:, :, :3], dtype=np.uint8, order="C", copy=True)
            position, quaternion = camera.get_world_pose(camera_axes="usd")
            pose = np.r_[_numpy(position), _numpy(quaternion)].astype(np.float64)
            if pose.shape != (7,) or not np.isfinite(pose).all():
                raise CameraFrameError(f"{name}: invalid camera world pose")
            result[name] = {
                "rgb": rgb,
                "rendering_time": time,
                "rendering_frame": frame_id,
                "world_pose_wxyz": pose,
            }
            stamps[name] = (frame_id, time)
        times = [stamp[1] for stamp in stamps.values()]
        if max(times) - min(times) > self.config["synchronization_tolerance_s"]:
            raise CameraFrameError(f"Camera render times disagree: {stamps}")
        if len({stamp[0] for stamp in stamps.values()}) != 1:
            raise CameraFrameError(f"Camera render frame IDs disagree: {stamps}")
        self._last.update(stamps)
        return result

    def calibration(self) -> dict[str, Any]:
        """Return JSON-serializable K/extrinsics and pilot provenance.

        Parent-local extrinsics remain constant. Wrist world poses vary and
        are recorded by capture() per frame, never treated as fixed extrinsics.
        """
        if not self._initialized:
            raise RuntimeError("Initialize cameras before reading their actual intrinsics")
        result = {
            "schema_version": 1,
            "rig_id": self.config["rig_id"],
            "calibration_status": self.config["calibration_status"],
            "config_path": str(self.config_path),
            "config_sha256": self.config_sha256,
            "config": self.config,
            "length_unit": "metre",
            "stage_meters_per_unit": self.stage_meters_per_unit,
            "stage_up_axis": self.stage_up_axis,
            "quaternion_order": "wxyz",
            "capture_pose_convention": "world_from_camera_usd; +X right, +Y up, -Z forward",
            "intrinsics_convention": "optical +X right, +Y down, +Z forward; pixel origin top-left",
            "lens_parameterization": "nominal conventional USD/RTX mm-style numbers; not measured physical lens/sensor sizes",
            "matrix_convention": "column vectors; T_parent_camera maps camera points into parent link frame",
            "recording_fps": self.config["recording_fps"],
            "cameras": {},
        }
        for name, camera in self.cameras.items():
            spec = self.config["cameras"][name]
            position, quaternion = camera.get_local_pose(camera_axes="usd")
            local_transform = _pose_matrix(_numpy(position), _numpy(quaternion))
            optical_transform = local_transform @ np.diag([1.0, -1.0, -1.0, 1.0])
            width, height = spec["resolution_wh"]
            result["cameras"][name] = {
                "prim_path": camera.prim_path,
                "parent_prim": spec["parent_prim"],
                "resolution_wh": [width, height],
                "K": _numpy(camera.get_intrinsics_matrix()).tolist(),
                "projection": "pinhole",
                "distortion_model": "none",
                "distortion_coefficients": [0.0, 0.0, 0.0, 0.0, 0.0],
                "parent_pose_wxyz_usd": np.r_[_numpy(position), _numpy(quaternion)].tolist(),
                "T_parent_camera_usd": local_transform.tolist(),
                "T_parent_optical": optical_transform.tolist(),
                "focal_length_mm": float(camera.get_focal_length()) * 10.0,
                "horizontal_aperture_mm": float(camera.get_horizontal_aperture()) * 10.0,
                "vertical_aperture_mm": float(camera.get_vertical_aperture()) * 10.0,
                "usd_lens_attributes": {
                    attr: float(camera.prim.GetAttribute(attr).Get())
                    for attr in ("focalLength", "horizontalAperture", "verticalAperture")
                },
                "clipping_range_m": list(map(float, camera.get_clipping_range())),
            }
        return result
