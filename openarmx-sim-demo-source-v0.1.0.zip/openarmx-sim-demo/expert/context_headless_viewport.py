"""Disable only an unrecorded default operator viewport in headless mode.

Installed Isaac 4.5 ViewportAPI.updates_enabled delegates to that viewport's own
Hydra texture. Three camera render products are independent and are never
disabled, detached, resized or otherwise reconfigured here. Call after rig
initialization / World.reset, before camera warmup. GUI mode is always a no-op.
No simulation step, render or asynchronous app update occurs in this helper.
"""
from __future__ import annotations

import hashlib
from pathlib import Path


CAMERAS = ('chest', 'left_wrist', 'right_wrist')
SCHEMA = 'context_unrecorded_headless_viewport_v1'


def _product_paths(rig):
    if set(rig.cameras) != set(CAMERAS):
        raise ValueError('Exactly three initialized recording cameras required')
    result = {}
    for name in CAMERAS:
        value = rig.cameras[name].get_render_product_path()
        if not isinstance(value, str) or not value.startswith('/') or value == '/' or '..' in value.split('/'):
            raise ValueError(name + ': absolute recording render-product path required')
        result[name] = value
    if len(set(result.values())) != 3:
        raise ValueError('Recording cameras must have three distinct render products')
    return result


def configure_headless_viewport(rig, *, headless, get_viewport=None):
    """Return live before/after evidence; never guess a sensor is unrecorded.

    get_viewport is injectable solely for CPU tests. Runtime chooses the default
    named viewport, not an arbitrary active window. If no default viewport is
    present, there is no viewport work to disable. An unresolved product path or
    collision with any sensor fails before mutating updates_enabled.
    """
    if type(headless) is not bool:
        raise ValueError('headless must be a bool')
    report = {'schema': SCHEMA, 'headless': headless,
              'sensor_render_products_modified': False, 'physics_advanced': False,
              'render_called': False, 'viewport_before': None, 'viewport_after': None,
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Default operator viewport only; recording camera render products stay enabled',
              'gpu_speedup_measured': False}
    if not headless:
        return {**report, 'status': 'gui_unchanged', 'sensor_render_products': None}
    products = _product_paths(rig)
    report['sensor_render_products'] = products
    if get_viewport is None:
        from omni.kit.viewport.utility import get_viewport_from_window_name
        get_viewport = get_viewport_from_window_name
    viewport = get_viewport()
    if viewport is None:
        return {**report, 'status': 'no_default_viewport'}
    path = viewport.render_product_path
    if not isinstance(path, str) or not path.startswith('/') or path == '/' or '..' in path.split('/'):
        raise ValueError('Default viewport render product is unresolved; refusing to disable it')
    if path in products.values():
        raise ValueError('Default viewport aliases a recording sensor render product; refusing to disable it')
    before = viewport.updates_enabled
    if type(before) is not bool:
        raise ValueError('Default viewport does not expose a boolean updates_enabled')
    report['viewport_before'] = {'render_product_path': path, 'updates_enabled': before}
    if before:
        viewport.updates_enabled = False
    after = viewport.updates_enabled
    if after is not False or viewport.render_product_path != path or _product_paths(rig) != products:
        # A failed optimization must not become silent configuration drift.
        if before and viewport.render_product_path == path:
            viewport.updates_enabled = before
        raise ValueError('Viewport update change did not preserve the declared render-product inventory')
    report['viewport_after'] = {'render_product_path': path, 'updates_enabled': after}
    report['status'] = 'unrecorded_default_viewport_disabled' if before else 'already_disabled'
    return report
