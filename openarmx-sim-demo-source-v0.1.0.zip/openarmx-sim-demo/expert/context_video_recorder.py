"""Independent CPU streaming prototype; NOT integrated with the collector.

One synchronous append is one aligned three-camera observation. Source RGB hashes
identify the *uncompressed inputs*, not decoded lossy H.264 pixels. Finalized here
means storage integrity only; it never grants training acceptance.
"""
from __future__ import annotations

from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from typing import Mapping

import av
import numpy as np
from PIL import Image


SCHEMA = "context_raw_video_v2"
CAMERAS = ("chest", "left_wrist", "right_wrist")
MAX_EVENTS_PER_FRAME = 64
MAX_METADATA_BYTES = 65536


class RecorderError(RuntimeError):
    """A failed recording remains incomplete and must not be used for training."""


@dataclass(frozen=True)
class RecorderConfig:
    camera_names: tuple[str, ...] = CAMERAS
    width: int = 640
    height: int = 480
    fps: int = 30
    crf: int = 16
    preset: str = "medium"
    pixel_format: str = "yuv420p"
    min_free_bytes: int = 1024 ** 3
    blank_spatial_std_max: float = 1.0
    fsync_interval_frames: int = 30
    # One job per independent camera, joined before append returns. 1 retains
    # the serial reference path for equivalence tests and paired CPU benchmarks.
    camera_workers: int = 3
    # Opt-in CPU overlap only. Includes the actively encoded observation;
    # zero retains the synchronous reference. Never drops/reorders frames.
    cross_frame_queue_size: int = 0
    # Independent audit deliberately retains NumPy reference recomputation.
    pixel_statistics_mode: str = "numpy_reference"

    def validate(self):
        if tuple(self.camera_names) != CAMERAS:
            raise ValueError(f"Canonical camera names/order must be {CAMERAS}")
        if (self.width, self.height, self.fps) != (640, 480, 30):
            raise ValueError("This prototype schema requires 640x480 RGB at 30 Hz")
        if isinstance(self.crf, bool) or not isinstance(self.crf, int) or not 0 <= self.crf <= 51:
            raise ValueError("crf must be an integer in [0,51]")
        if self.preset not in ("ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower", "veryslow"):
            raise ValueError("Unsupported libx264 preset")
        if self.pixel_format != "yuv420p":
            raise ValueError("This prototype uses broadly readable 8-bit yuv420p")
        if not isinstance(self.min_free_bytes, int) or self.min_free_bytes < 0:
            raise ValueError("min_free_bytes must be nonnegative")
        if not isinstance(self.fsync_interval_frames, int) or self.fsync_interval_frames < 1:
            raise ValueError("fsync_interval_frames must be positive")
        if not np.isfinite(self.blank_spatial_std_max) or self.blank_spatial_std_max < 0:
            raise ValueError("Invalid blank-frame diagnostic threshold")
        if type(self.camera_workers) is not int or self.camera_workers not in (1, 3):
            raise ValueError("camera_workers must be 1 (serial) or 3 (one per camera)")
        if type(self.cross_frame_queue_size) is not int or self.cross_frame_queue_size not in (0, 1, 2):
            raise ValueError("cross_frame_queue_size must be 0 (synchronous), 1 or 2")
        if self.pixel_statistics_mode not in ("numpy_reference", "exact_histogram"):
            raise ValueError("pixel_statistics_mode must be numpy_reference or exact_histogram")


def _json_bytes(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")


def _write_new_json(path: Path, value):
    with path.open("xb") as handle:
        handle.write(_json_bytes(value) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())


def _fsync_file(path: Path):
    with path.open("rb") as handle:
        os.fsync(handle.fileno())


def _fsync_directory(path: Path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def file_sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rgb_sha256(rgb: np.ndarray):
    return hashlib.sha256(memoryview(np.ascontiguousarray(rgb))).hexdigest()


def source_pixel_statistics(rgb, *, mode="numpy_reference", blank_limit=1.0):
    """Population RGB moments; exact integer moments for this fixed uint8 size.

    At 640x480 the largest sum-square numerator term is < 6.14e15, safely
    within signed int64. Subtract in integers BEFORE dividing, avoiding floating
    cancellation for almost-constant images. Independent audit continues using
    np.mean/std with its unchanged 1e-5 tolerance. Near the blank boundary use
    the historical implementation so its floating-rounding classification is
    preserved exactly, rather than silently changing a quality diagnostic.
    """
    if mode == "numpy_reference":
        flattened = rgb.reshape(-1, 3)
        return flattened.mean(axis=0), flattened.std(axis=0)
    if mode != "exact_histogram":
        raise ValueError("Unknown pixel statistics mode")
    if rgb.dtype != np.uint8 or rgb.shape != (480, 640, 3):
        raise ValueError("Exact moments are bounded for uint8 RGB shape (480,640,3)")
    levels = np.arange(256, dtype=np.int64)
    histogram = np.asarray([np.bincount(rgb[:, :, channel].ravel(), minlength=256)
                            for channel in range(3)], dtype=np.int64)
    count = rgb.shape[0] * rgb.shape[1]
    total, square_total = histogram @ levels, histogram @ (levels * levels)
    mean = total / count
    std = np.sqrt((square_total * count - total * total) / (count * count))
    if abs(float(std.max()) - blank_limit) <= 1e-7:
        return source_pixel_statistics(rgb, mode="numpy_reference", blank_limit=blank_limit)
    return mean, std


def source_timestamp_ns(origin_ns: int, frame_id: int, fps: int = 30):
    """Exact rational 30 Hz lattice, rounded to nearest nanosecond (ties to even)."""
    return origin_ns + round(Fraction(frame_id * 1_000_000_000, fps))


def _integer(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be a Python integer")
    return value


class ContextVideoRecorder:
    """Bounded-memory CPU recorder with explicit failure receipts.

    append(frame_id, timestamp_ns, frames, events=(), render_metadata=None):
      frames maps all three canonical names to uint8 HxWx3 RGB arrays.
      frame_id starts at zero and is contiguous. timestamp_ns is simulation /
      observation time on an exact rounded 30 Hz lattice, NOT wall-clock time.
      Optional render_metadata is separate, per-camera diagnostic information.
      Events describe facts already effective at *this* observation; their
      frame_id must equal this frame, and timestamp_ns cannot be in the future.
      Event text is caller-supplied: this API cannot prove semantic causality.

    By default append joins all three camera encoders before returning. The
    opt-in cross-frame queue instead returns after taking independent, read-only
    RGB snapshots and deep-copying metadata. Its one ordered frame worker joins
    all camera workers before committing each row. At most the configured number
    of observations (including the active one) are owned by the queue; a full
    queue blocks the producer. check_health surfaces completed worker failures;
    drain/finalize must succeed before any artifact is storage-complete. A crash
    or worker failure leaves .incomplete, even if numeric physics has progressed.
    The caller must never mutate arrays concurrently with append's snapshot.
    """

    def __init__(self, episode_dir: str | Path, config: RecorderConfig | None = None):
        self.config = config or RecorderConfig()
        self.config.validate()
        self.root = Path(episode_dir).absolute()
        self.root.mkdir(parents=True, exist_ok=False)
        self._state = "recording"
        self._containers = {}
        self._streams = {}
        self._camera_executors = {}
        self._frame_executor = None
        self._pending_futures = deque()
        self._worker_error = None
        self._submitted_count = 0
        self._async_metrics = {"max_pending_observations": 0, "producer_backpressure_s": 0.0,
                               "snapshot_copy_s": 0.0, "ordered_worker_service_s": 0.0}
        self._metadata = None
        self._count = 0
        self._origin_ns = None
        self._pending_frame_id = None
        self._previous_hash = {name: None for name in CAMERAS}
        self._stats = {name: dict(input_frames=0, nearly_blank_frames=0,
                                 consecutive_duplicate_frames=0, identical_run=0,
                                 longest_identical_run=0, lossless_keyframes=0) for name in CAMERAS}
        _write_new_json(self.root / ".incomplete", {
            "schema": SCHEMA, "status": "recording_or_interrupted", "training_ready": False,
            "rule": "Only FINALIZED.json plus absence of this marker establishes storage completion; neither grants training acceptance.",
        })
        try:
            _fsync_directory(self.root)
            _write_new_json(self.root / "recording_config.json", {
                "schema": SCHEMA, "integration_status": "standalone_prototype_not_collector_integrated",
                "config": asdict(self.config), "training_ready": False,
                "source_hash_semantics": "SHA256 of contiguous source uint8 RGB bytes, before lossy encoding",
                "observation_timing": "caller_must_supply_pre_action_observations_not_yet_integrated",
                "timestamp_policy": "origin_ns + round(Fraction(frame_id*1000000000,30)); video time starts at zero",
                "encoder": {"codec": "libx264", "b_frames": 0, "lookahead": 0, "threads": 1,
                            "tune": "zerolatency", "lossy": True,
                            "camera_workers": self.config.camera_workers,
                            "cross_frame_queue": self.config.cross_frame_queue_size > 0,
                            "cross_frame_queue_size": self.config.cross_frame_queue_size,
                            "join_before_physics": self.config.cross_frame_queue_size == 0,
                            "immutable_rgb_and_metadata_owned_before_return": True,
                            "failure_policy": "Any worker failure rejects the entire episode; drain before finalization"},
                "environment": {"python": sys.version, "av": av.__version__, "numpy": np.__version__},
                "recorder_source_sha256": file_sha256(Path(__file__)),
            })
            (self.root / "videos").mkdir()
            for camera in CAMERAS:
                (self.root / "keyframes" / camera).mkdir(parents=True)
            self._check_disk_space()
            self._metadata = (self.root / "frames.jsonl").open("xb")
            for camera in CAMERAS:
                container = av.open(str(self.root / "videos" / f"{camera}.mp4"), mode="w", format="mp4")
                self._containers[camera] = container
                stream = container.add_stream("libx264", rate=self.config.fps)
                stream.width, stream.height = self.config.width, self.config.height
                stream.pix_fmt = self.config.pixel_format
                stream.time_base = Fraction(1, self.config.fps)
                stream.codec_context.time_base = Fraction(1, self.config.fps)
                stream.codec_context.thread_count = 1
                stream.codec_context.gop_size = self.config.fps
                stream.options = {"crf": str(self.config.crf), "preset": self.config.preset,
                                  "tune": "zerolatency", "bf": "0", "rc-lookahead": "0"}
                self._streams[camera] = stream
            if self.config.camera_workers == 3:
                self._camera_executors = {
                    camera: ThreadPoolExecutor(max_workers=1, thread_name_prefix=f"rgb-{camera}")
                    for camera in CAMERAS
                }
            if self.config.cross_frame_queue_size:
                self._frame_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="rgb-frame-order")
        except BaseException as error:
            self._fail(error)
            raise

    @property
    def state(self):
        return self._state

    def _check_disk_space(self):
        # Reserve two uncompressed three-camera frames, plus bounded metadata.
        # CRF is variable bitrate: this guard is not a promised episode size.
        reserve = (self.config.width * self.config.height * 3 * len(CAMERAS)
                   * max(2, self.config.cross_frame_queue_size + 1) + MAX_METADATA_BYTES)
        free = shutil.disk_usage(self.root).free
        if free < self.config.min_free_bytes + reserve:
            raise RecorderError(f"Disk-space guard: free={free}, required floor+reserve={self.config.min_free_bytes + reserve}")

    def _validate_input(self, frame_id, timestamp_ns, frames, events, render_metadata):
        _integer(frame_id, "frame_id")
        _integer(timestamp_ns, "timestamp_ns")
        if frame_id != self._submitted_count:
            raise ValueError(f"Expected contiguous frame_id {self._submitted_count}, got {frame_id}")
        if timestamp_ns < 0:
            raise ValueError("timestamp_ns cannot be negative")
        origin = timestamp_ns if self._origin_ns is None else self._origin_ns
        if timestamp_ns != source_timestamp_ns(origin, frame_id, self.config.fps):
            raise ValueError("Source timestamp is not on the exact rounded 30 Hz lattice")
        if not isinstance(frames, Mapping) or set(frames) != set(CAMERAS):
            raise ValueError(f"Exactly these three synchronized cameras are required: {CAMERAS}")
        for camera, rgb in frames.items():
            if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.shape != (480, 640, 3):
                raise ValueError(f"{camera}: expected uint8 RGB shape (480,640,3)")
        if not isinstance(events, (list, tuple)) or len(events) > MAX_EVENTS_PER_FRAME:
            raise ValueError("Events must be a bounded list/tuple")
        clean_events = []
        for event in events:
            if not isinstance(event, dict) or event.get("kind") not in ("instruction", "grasp", "release", "annotation"):
                raise ValueError("Each event needs kind instruction/grasp/release/annotation")
            event = dict(event)
            event.setdefault("frame_id", frame_id)
            event.setdefault("timestamp_ns", timestamp_ns)
            if _integer(event["frame_id"], "event.frame_id") != frame_id:
                raise ValueError("Event frame_id must be the current frame; no future or retroactive keyframe claims")
            if not origin <= _integer(event["timestamp_ns"], "event.timestamp_ns") <= timestamp_ns:
                raise ValueError("Event must already have arrived; future/pre-episode timestamps are forbidden")
            clean_events.append(event)
        if render_metadata is not None:
            if not isinstance(render_metadata, dict) or not set(render_metadata).issubset(CAMERAS):
                raise ValueError("render_metadata must be separate per-camera metadata")
            for value in render_metadata.values():
                if not isinstance(value, dict):
                    raise ValueError("Each render metadata entry must be a dict")
                for key in ("frame_id", "timestamp_ns"):
                    if key in value and _integer(value[key], f"render.{key}") < 0:
                        raise ValueError("Render counters/timestamps cannot be negative")
        metadata = {"events": clean_events, "render_metadata": render_metadata}
        if len(_json_bytes(metadata)) > MAX_METADATA_BYTES:
            raise ValueError("Per-frame events/render metadata exceed bounded size")
        # Roundtrip removes mutable caller aliases and validates JSON serialization.
        return origin, json.loads(_json_bytes(metadata))

    def _encode(self, camera, rgb, frame_id):
        frame = av.VideoFrame.from_ndarray(rgb, format="rgb24")
        frame.pts = frame_id
        frame.time_base = Fraction(1, self.config.fps)
        for packet in self._streams[camera].encode(frame):
            self._containers[camera].mux(packet)

    def _append_camera(self, camera, source_rgb, frame_id, reasons):
        """Only this camera's worker touches its codec, statistics and files."""
        rgb = np.ascontiguousarray(source_rgb)
        digest = rgb_sha256(rgb)
        mean, std = source_pixel_statistics(rgb, mode=self.config.pixel_statistics_mode,
                                           blank_limit=self.config.blank_spatial_std_max)
        blank = bool(float(std.max()) <= self.config.blank_spatial_std_max)
        duplicate = digest == self._previous_hash[camera]
        stats = self._stats[camera]
        entry = {"source_rgb_sha256": digest, "mean_rgb": mean.tolist(), "spatial_std_rgb": std.tolist(),
                 "nearly_blank": blank, "identical_to_previous_source_frame": duplicate}
        self._encode(camera, rgb, frame_id)
        stats["input_frames"] += 1
        if reasons:
            relative = f"keyframes/{camera}/frame_{frame_id:09d}.png"
            path = self.root / relative
            with path.open("xb") as png:
                Image.fromarray(rgb).save(png, format="PNG", compress_level=3)
            entry["lossless_keyframe"] = {"path": relative, "file_sha256": file_sha256(path), "reasons": reasons}
            stats["lossless_keyframes"] += 1
        stats["nearly_blank_frames"] += int(blank)
        stats["consecutive_duplicate_frames"] += int(duplicate)
        stats["identical_run"] = stats["identical_run"] + 1 if duplicate else 1
        stats["longest_identical_run"] = max(stats["longest_identical_run"], stats["identical_run"])
        self._previous_hash[camera] = digest
        return entry

    def _append_cameras(self, frames, frame_id, reasons):
        if not self._camera_executors:
            return {camera: self._append_camera(camera, frames[camera], frame_id, reasons)
                    for camera in CAMERAS}
        # At most THREE submitted jobs, exactly one per independent stream.
        # No frame metadata is committed until every job succeeds. In any
        # exception path _close_outputs also joins all executors before closing
        # files, including if submission itself or the main thread is interrupted.
        futures = {camera: self._camera_executors[camera].submit(
            self._append_camera, camera, frames[camera], frame_id, reasons) for camera in CAMERAS}
        entries, first_error = {}, None
        for camera, future in futures.items():
            try:
                entries[camera] = future.result()
            except BaseException as error:
                if first_error is None:
                    first_error = error
        if first_error is not None:
            raise first_error
        return entries

    def _write_frame(self, frame_id, timestamp_ns, frames, extra):
        """Only the ordered frame worker (or synchronous caller) commits rows."""
        if self._worker_error is not None or self._state != "recording":
            raise RecorderError("Earlier worker failure/abort prevents further encoding")
        started = time.perf_counter()
        self._pending_frame_id = frame_id
        try:
            if frame_id != self._count:
                raise RecorderError("Ordered encoder frame sequence changed")
            self._check_disk_space()
            reasons = (["initial"] if frame_id == 0 else []) + [event["kind"] for event in extra["events"]]
            row = {"schema": SCHEMA, "frame_id": frame_id, "timestamp_ns": timestamp_ns,
                   "video_time": {"numerator": frame_id, "denominator": self.config.fps},
                   **extra, "cameras": self._append_cameras(frames, frame_id, reasons)}
            self._metadata.write(_json_bytes(row) + b"\n")
            self._metadata.flush()
            self._count += 1
            if self._count % self.config.fsync_interval_frames == 0:
                os.fsync(self._metadata.fileno())
            self._pending_frame_id = None
        except BaseException as error:
            # Never invoke _fail/shutdown from its own worker thread. The
            # producer observes this future and performs joined failure cleanup.
            self._worker_error = error
            raise
        finally:
            self._async_metrics["ordered_worker_service_s"] += time.perf_counter() - started

    def check_health(self):
        """Nonblocking failure propagation; returned count is encoded, not queued."""
        if self._state != "recording":
            raise RecorderError(f"Recorder is {self._state}")
        try:
            while self._pending_futures and self._pending_futures[0].done():
                self._pending_futures.popleft().result()
            if self._worker_error is not None:
                raise self._worker_error
            return self._count
        except BaseException as error:
            self._fail(error)
            raise

    def drain(self):
        """Join all queued observations and require exact submitted/encoded count."""
        self.check_health()
        try:
            while self._pending_futures:
                self._pending_futures.popleft().result()
            if self._count != self._submitted_count:
                raise RecorderError("Submitted/encoded observation count mismatch")
            return self._count
        except BaseException as error:
            self._fail(error)
            raise

    def append(self, frame_id: int, timestamp_ns: int, frames: Mapping[str, np.ndarray],
               *, events=(), render_metadata=None):
        self.check_health()
        try:
            origin, extra = self._validate_input(frame_id, timestamp_ns, frames, events, render_metadata)
            self._check_disk_space()
            self._origin_ns = origin
            if self._frame_executor is None:
                self._write_frame(frame_id, timestamp_ns, frames, extra)
            else:
                if len(self._pending_futures) >= self.config.cross_frame_queue_size:
                    started = time.perf_counter()
                    try:
                        self._pending_futures.popleft().result()
                    finally:
                        self._async_metrics["producer_backpressure_s"] += time.perf_counter() - started
                    self.check_health()
                started = time.perf_counter()
                owned = {camera: np.array(frames[camera], copy=True, order="C") for camera in CAMERAS}
                for rgb in owned.values():
                    rgb.setflags(write=False)
                self._async_metrics["snapshot_copy_s"] += time.perf_counter() - started
                future = self._frame_executor.submit(self._write_frame, frame_id, timestamp_ns, owned, extra)
                self._pending_futures.append(future)
                self._async_metrics["max_pending_observations"] = max(
                    self._async_metrics["max_pending_observations"], len(self._pending_futures))
            self._submitted_count += 1
        except BaseException as error:
            self._fail(error)
            raise

    def _close_outputs(self, flush):
        errors = []
        # Join the ordered producer FIRST: it may still submit/wait for camera
        # workers. Queued jobs are canceled after abort; active work is joined.
        if self._frame_executor is not None:
            self._frame_executor.shutdown(wait=True, cancel_futures=True)
            self._frame_executor = None
        self._pending_futures.clear()
        # An encoder must never race its container.close(), even on Ctrl+C,
        # ENOSPC, partial submission or a failed sibling camera.
        for executor in self._camera_executors.values():
            executor.shutdown(wait=True)
        self._camera_executors.clear()
        for camera, container in tuple(self._containers.items()):
            try:
                if flush and camera in self._streams:
                    for packet in self._streams[camera].encode(None):
                        container.mux(packet)
            except BaseException as error:
                errors.append(f"{camera} encoder flush: {type(error).__name__}: {error}")
            try:
                container.close()
            except BaseException as error:
                errors.append(f"{camera} close: {type(error).__name__}: {error}")
        self._containers.clear()
        self._streams.clear()
        if self._metadata is not None:
            try:
                self._metadata.flush()
                os.fsync(self._metadata.fileno())
                self._metadata.close()
            except BaseException as error:
                errors.append(f"metadata close: {type(error).__name__}: {error}")
            self._metadata = None
        return errors

    def _fail(self, error):
        if self._state != "recording":
            return
        self._state = "failed"
        close_errors = self._close_outputs(flush=True)
        # A failure in the final directory fsync can happen after unlink. Put
        # the fail-closed marker back before returning any error to the caller.
        if not (self.root / ".incomplete").exists():
            try:
                _write_new_json(self.root / ".incomplete", {"schema": SCHEMA,
                    "status": "finalization_failed", "training_ready": False})
                _fsync_directory(self.root)
            except BaseException:
                pass
        failure = {"schema": SCHEMA, "status": "failed_or_aborted", "storage_finalized": False,
                   "training_ready": False, "complete_metadata_frames": self._count,
                   "last_complete_frame_id": self._count - 1, "pending_frame_id": self._pending_frame_id,
                   "submitted_observations": self._submitted_count,
                   "error_type": type(error).__name__, "error": str(error), "close_errors": close_errors,
                   "camera_partial_statistics": self._stats,
                   "recovery_policy": "Preserve all partial files and .incomplete; do not train or silently resume this directory."}
        try:
            _write_new_json(self.root / "FAILURE.json", failure)
        except BaseException:
            # ENOSPC/hard failures may prevent a new receipt. The preexisting
            # .incomplete marker is the fail-closed authority in that case.
            pass

    def abort(self, reason="caller requested abort"):
        if self._state == "finalized":
            raise RecorderError("Cannot abort an already finalized storage artifact")
        self._fail(RecorderError(reason))

    def _verify_metadata(self):
        count = 0
        with (self.root / "frames.jsonl").open("rb") as handle:
            for count, line in enumerate(handle, 1):
                row = json.loads(line)
                index = count - 1
                if row["frame_id"] != index or row["timestamp_ns"] != source_timestamp_ns(self._origin_ns, index, self.config.fps):
                    raise RecorderError("Metadata frame/time lattice changed")
                if row["video_time"] != {"numerator": index, "denominator": self.config.fps} or set(row["cameras"]) != set(CAMERAS):
                    raise RecorderError("Metadata camera/video synchronization changed")
                for entry in row["cameras"].values():
                    keyframe = entry.get("lossless_keyframe")
                    if keyframe:
                        path = self.root / keyframe["path"]
                        if path.resolve().parent.parent != (self.root / "keyframes").resolve():
                            raise RecorderError("Invalid lossless keyframe path")
                        if file_sha256(path) != keyframe["file_sha256"]:
                            raise RecorderError("Lossless keyframe file hash mismatch")
                        with Image.open(path) as image:
                            source = np.asarray(image)
                            if source.shape != (480, 640, 3) or rgb_sha256(source) != entry["source_rgb_sha256"]:
                                raise RecorderError("Lossless keyframe no longer matches source RGB")
        if count != self._count:
            raise RecorderError(f"Metadata count {count} != committed input count {self._count}")

    def _verify_video(self, camera):
        path = self.root / "videos" / f"{camera}.mp4"
        count, worst_keyframe_psnr, quality_samples = 0, None, 0
        with av.open(str(path), mode="r") as container, (self.root / "frames.jsonl").open("rb") as metadata:
            if len(container.streams.video) != 1:
                raise RecorderError(f"{camera}: expected one video stream")
            stream = container.streams.video[0]
            stream.codec_context.thread_count = 1
            if stream.codec_context.name != "h264" or stream.codec_context.format.name != "yuv420p":
                raise RecorderError(f"{camera}: unexpected codec/pixel format")
            for frame in container.decode(stream):
                index = count
                if index >= self._count or frame.width != 640 or frame.height != 480:
                    raise RecorderError(f"{camera}: extra frame or wrong decoded dimensions")
                if frame.pts is None or frame.time_base is None or Fraction(frame.pts) * frame.time_base != Fraction(index, self.config.fps):
                    raise RecorderError(f"{camera}: decoded PTS is not exact frame_id/fps at index {index}")
                row = json.loads(next(metadata))
                keyframe = row["cameras"][camera].get("lossless_keyframe")
                if keyframe:
                    with Image.open(self.root / keyframe["path"]) as image:
                        source = np.asarray(image).astype(np.float32)
                    decoded = frame.to_ndarray(format="rgb24").astype(np.float32)
                    mse = float(np.mean((source - decoded) ** 2))
                    # Infinity cannot be encoded in strict JSON; null plus the
                    # sample count represents a completely exact keyframe set.
                    psnr = None if mse == 0 else float(10 * np.log10(255 ** 2 / mse))
                    if psnr is not None:
                        worst_keyframe_psnr = psnr if worst_keyframe_psnr is None else min(worst_keyframe_psnr, psnr)
                    quality_samples += 1
                count += 1
            if count != self._count:
                raise RecorderError(f"{camera}: decoded {count} != committed {self._count}")
            time_base = {"numerator": stream.time_base.numerator, "denominator": stream.time_base.denominator}
        return {"path": str(path.relative_to(self.root)), "sha256": file_sha256(path),
                "bytes": path.stat().st_size, "decoded_frames": count, "pts_exactly_verified": True,
                "stream_time_base": time_base, "codec": "h264", "pixel_format": "yuv420p",
                "keyframe_quality_samples": quality_samples, "worst_finite_keyframe_psnr_db": worst_keyframe_psnr,
                "quality_metric_scope": "Diagnostic source-vs-lossy-decode keyframes only; no training or visual-QA acceptance."}

    def _sync_artifacts(self):
        """Persist files and directory entries before publishing completion."""
        for name in ("recording_config.json", "frames.jsonl", ".incomplete"):
            _fsync_file(self.root / name)
        for camera in CAMERAS:
            _fsync_file(self.root / "videos" / f"{camera}.mp4")
            directory = self.root / "keyframes" / camera
            for png in directory.glob("frame_*.png"):
                _fsync_file(png)
            _fsync_directory(directory)
        for directory in (self.root / "keyframes", self.root / "videos", self.root, self.root.parent):
            _fsync_directory(directory)

    def finalize(self):
        if self._state != "recording":
            raise RecorderError(f"Cannot finalize while {self._state}")
        try:
            self.drain()
            if not self._count:
                raise RecorderError("Cannot finalize an empty episode")
            self._check_disk_space()
            errors = self._close_outputs(flush=True)
            if errors:
                raise RecorderError("; ".join(errors))
            self._verify_metadata()
            videos = {camera: self._verify_video(camera) for camera in CAMERAS}
            self._sync_artifacts()
            receipt = {"schema": SCHEMA, "status": "storage_finalized_prototype_not_training_accepted",
                       "storage_finalized": True, "training_ready": False,
                       "integration_status": "standalone_not_collector_or_lerobot_integrated",
                       "frame_count": self._count, "fps": self.config.fps, "source_origin_ns": self._origin_ns,
                       "camera_names": list(CAMERAS), "synchronous_input_and_rational_pts_verified": True,
                       "frames_jsonl_sha256": file_sha256(self.root / "frames.jsonl"),
                       "camera_source_statistics": self._stats, "videos": videos,
                       "encoder_runtime": {"cross_frame_queue_size": self.config.cross_frame_queue_size,
                                           "submitted_observations": self._submitted_count,
                                           **self._async_metrics},
                       "keyframes": "Initial frame plus all currently delivered instruction/grasp/release/annotation event frames",
                       "not_verified": ["physics/task success", "real camera calibration", "real action mapping",
                                        "semantic event causality", "full-stream human visual QA", "official LeRobot reader compatibility"],
                       "future_reuse": "Unmodified verified videos may be reused/hardlinked by a future official LeRobot integration; not implemented here."}
            _write_new_json(self.root / "FINALIZED.json", receipt)
            _fsync_directory(self.root)
            # The only removed file is this recorder's own lifecycle marker.
            # A crash before this point leaves .incomplete and remains rejected.
            (self.root / ".incomplete").unlink()
            _fsync_directory(self.root)
            self._state = "finalized"
            return receipt
        except BaseException as error:
            self._fail(error)
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self._state == "recording":
            self.abort("Context exited without explicit finalize" if exc_value is None else f"Context interrupted: {exc_type.__name__}: {exc_value}")
        return False


def inspect_recording_state(episode_dir):
    """Fast fail-closed lifecycle check, NOT an integrity or training audit."""
    root = Path(episode_dir)
    if (root / ".incomplete").exists() or (root / "FAILURE.json").exists():
        return {"storage_finalized": False, "training_ready": False, "reason": "incomplete_or_failed"}
    path = root / "FINALIZED.json"
    if not path.is_file():
        return {"storage_finalized": False, "training_ready": False, "reason": "missing_finalization"}
    try:
        receipt = json.loads(path.read_bytes())
        complete = receipt.get("schema") == SCHEMA and receipt.get("storage_finalized") is True
    except (OSError, ValueError):
        complete = False
    return {"storage_finalized": complete, "training_ready": False,
            "reason": "prototype_storage_only" if complete else "invalid_finalization"}
