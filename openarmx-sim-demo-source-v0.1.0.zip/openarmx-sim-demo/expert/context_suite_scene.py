"""Provisional original-layout physical scenes for the full context pilot suite.

USD imports are deferred until SimulationApp is running. This module describes
real collision-bearing assets, not a visual-only proxy. Sizes and camera poses
remain uncalibrated to the real apparatus; IK evidence is not physics success.
"""
from pathlib import Path
import hashlib
import itertools
import numpy as np
from context_container_geometry import shallow_rectangle_geometry, container_spacing

RECTANGULAR_BOWL_TASKS = ()  # Historical v0.6 candidate; not part of v0.7 scenes.
RECTANGULAR_BOWL_ASSET = __import__('runtime_paths').asset_root() / 'RoboLab/assets/objects/context_custom/shallow_rectangular_bowl_120x250x25.usda'
OVAL_PLATE_TASKS = ('CTX09', 'CTX11')


def filter_fixed_equivalent_finger_pairs(stage):
    """Exclude only four verified fixed-equivalent adjacent sliding bodies.

    link7 -> hand is fixed; hand -> each finger is prismatic with adjacent
    collisions disabled in the source. Imported link7 hulls overlap the finger
    guides below ~18 mm opening. Keep finger-finger, torso and cross-arm pairs.
    Fail closed if the expected native joint graph changes.
    """
    from pxr import UsdPhysics
    evidence = []
    for side in ('left', 'right'):
        link = f'/world/OpenArmX/openarmx_{side}_link7'
        hand = f'/world/OpenArmX/openarmx_{side}_hand'
        fixed_path = f'/world/OpenArmX/joints/{side}_openarmx_hand_joint'
        fixed = stage.GetPrimAtPath(fixed_path)
        if not fixed or not fixed.IsA(UsdPhysics.FixedJoint):
            raise ValueError('Expected native fixed wrist-hand joint: ' + fixed_path)
        joint = UsdPhysics.Joint(fixed)
        if ([str(p) for p in joint.GetBody0Rel().GetTargets()] != [link]
                or [str(p) for p in joint.GetBody1Rel().GetTargets()] != [hand]):
            raise ValueError('Native wrist-hand body relationship changed')
        fingers = set()
        for number in (1, 2):
            sliding_path = f'/world/OpenArmX/joints/openarmx_{side}_finger_joint{number}'
            sliding = stage.GetPrimAtPath(sliding_path)
            if not sliding or not sliding.IsA(UsdPhysics.PrismaticJoint):
                raise ValueError('Expected native sliding finger joint: ' + sliding_path)
            finger_joint = UsdPhysics.Joint(sliding)
            body0 = [str(p) for p in finger_joint.GetBody0Rel().GetTargets()]
            body1 = [str(p) for p in finger_joint.GetBody1Rel().GetTargets()]
            if (body0 != [hand] or len(body1) != 1
                    or finger_joint.GetCollisionEnabledAttr().Get() is not False):
                raise ValueError('Finger adjacency/collision declaration changed')
            fingers.add(body1[0])
            evidence.append(dict(pair=[link, body1[0]], fixed_joint=fixed_path,
                                 sliding_joint=sliding_path, adjacent_collision_enabled=False,
                                 reason='fixed-equivalent adjacent slider; native guide hull structural overlap'))
        if fingers != {f'/world/OpenArmX/openarmx_{side}_{finger}_finger' for finger in ('left', 'right')}:
            raise ValueError('Unexpected sliding finger body')
    for item in evidence:
        first, second = item['pair']
        if not stage.GetPrimAtPath(first) or not stage.GetPrimAtPath(second):
            raise ValueError('Missing native collision body')
        UsdPhysics.FilteredPairsAPI.Apply(stage.GetPrimAtPath(first)).CreateFilteredPairsRel().AddTarget(second)
    return evidence


def bowl_workspace(task, fruit_task):
    """Task-capacity candidates, still requiring full contact-driven validation.

    Keep single-payload round bowls. CTX09/11 use wider low-rim oval plates;
    CTX05 has one ipsilateral plate, and CTX10 uses empty tabletop regions.
    Object scales are unchanged. No geometry claim replaces physical validation.
    """
    if task in OVAL_PLATE_TASKS:
        return {'scale': [.38, .80, .70], 'near_x': .26, 'far_x': .44,
                'shape': 'ellipse', 'version': 'v07_low_rim_oval_plates_candidate_v1',
                'capacity': 'two objects per plate candidate; supported independent placement and full paths require physics acceptance'}
    if task in ('CTX13', 'CTX14', 'CTX16'):
        return {'scale': .80, 'near_x': .26, 'far_x': .44,
                'place_pitch': {'N': -.65, 'F': -.85},
                'version': 'single_payload_bowls_v1',
                'capacity': 'one banana or block per bowl; not multi-object or regrasp validated'}
    if fruit_task:
        return {'scale': 1.05, 'near_x': .20, 'far_x': .42,
                'place_pitch': None, 'version': 'fruit_large_bowls_unresolved',
                'capacity': 'multi-object/regrasp candidate; not physically validated'}
    return {'scale': .75, 'near_x': .26, 'far_x': .435,
            'place_pitch': {'N': -.65, 'F': -.85},
            'version': 'reachable_block_bowls_v2',
            'capacity': 'single block; contact-driven regrasp still requires validation'}


def create_scene(base, protocol):
    from pxr import Gf, PhysxSchema, Sdf, Usd, UsdGeom, UsdPhysics
    from scipy.spatial.transform import Rotation

    root, args = base.ROOT, base.args
    layer = Sdf.Layer.CreateAnonymous('context_suite.usda')
    layer.subLayerPaths = [str(root / 'RoboLab/assets/scenes/openarmx_banana_loop.usda')]
    stage = Usd.Stage.Open(layer)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    # Arm-arm sensors would otherwise read zero even for interpenetration:
    # the inherited preview scene disables articulation self collisions.
    articulation = PhysxSchema.PhysxArticulationAPI.Apply(stage.GetPrimAtPath('/world/OpenArmX/root_joint'))
    articulation.CreateEnabledSelfCollisionsAttr(True)
    # Imported convex hulls of link5 and link7 intersect through the intervening
    # wrist link6. Offline convex intersection checks confirm this structural
    # overlap on both arms (10–13 mm inscribed radius); the right pair is also
    # explicitly excluded by the source MoveIt SRDF. Keep all inter-arm pairs
    # enabled rather than importing its broad generated collision matrix.
    filtered_wrist_pairs = []
    for side in ('left', 'right'):
        first = f'/world/OpenArmX/openarmx_{side}_link5'
        second = f'/world/OpenArmX/openarmx_{side}_link7'
        UsdPhysics.FilteredPairsAPI.Apply(stage.GetPrimAtPath(first)).CreateFilteredPairsRel().AddTarget(second)
        filtered_wrist_pairs.append([first, second])
    finger_exclusions = filter_fixed_equivalent_finger_pairs(stage)
    keep = {'OpenArmX', 'table', 'franka_table', 'GroundPlane', 'Looks', 'PhysicsScene',
            'EnvironmentLight', 'KeyLight', 'OverviewCamera', 'Render'}
    for child in stage.GetPrimAtPath('/world').GetChildren():
        if child.GetName() not in keep:
            child.SetActive(False)

    tabletop = 0.30
    table = stage.GetPrimAtPath('/world/table')
    table.GetAttribute('xformOp:translate').Set(Gf.Vec3d(0.5471, 0, tabletop - 0.35))
    table.GetAttribute('xformOp:scale').Set(Gf.Vec3f(1.5, 1, 1))
    task = protocol['task_id']
    sample = None
    if getattr(args, 'diverse_episodes', False):
        from context_episode_sampling import sample_episode
        sample = sample_episode(task, scene_seed=args.scene_seed,
                                nuisance_seed=args.nuisance_seed, motion_seed=args.motion_seed)
    fruit_task = any(name in protocol['props'] for name in ('banana', 'apple', 'lemon'))
    workspace = bowl_workspace(task, fruit_task)
    bowl_scale = workspace['scale']
    # Keep the approved near/far relation and original asset sizes. The former
    # block near-bowl center (.23) forced the wrist chain into the torso during
    # regrasp. These provisional centers retain >5 cm outer-contour separation;
    # complete contact-driven execution, not endpoint IK, remains the gate.
    near_x, far_x = workspace['near_x'], workspace['far_x']
    slots = {
        'L1': [0.24, 0.25], 'L2': [0.37, 0.25],
        'R1': [0.24, -0.25], 'R2': [0.37, -0.25],
        'P': [0.30, 0.0], 'N': [near_x, 0.0], 'F': [far_x, 0.0],
        'REPLACEMENT_SHARED': [0.09, 0.0], 'S_L': [0.30, 0.40], 'S_R': [0.30, -0.40],
        'C_L_NEAR': [0.23, 0.24], 'C_L_FAR': [0.34, 0.24],
        'C_R_NEAR': [0.23, -0.24], 'C_R_FAR': [0.34, -0.24],
        'Z_N': [0.27, 0.0], 'Z_F': [0.39, 0.0],
        'BESIDE_P_L': [0.24, 0.40], 'BESIDE_P_R': [0.24, -0.40],
        'BRICK_LEFT': [0.30, 0.25], 'BRICK_RIGHT': [0.30, -0.25],
        'RECEIVE_L': [0.30, 0.10], 'RECEIVE_R': [0.30, -0.10],
        'HOLD_NEUTRAL': [0.29, 0.19, 0.42],
    }
    if getattr(args, 'reference_start_pose', None):
        # The reference mount is 10 cm higher. Keep L2/R2 forward of L1/R1,
        # but inside the low-grasp reach of that explicit mounting profile.
        # Full physical execution remains mandatory; this is not an IK waiver.
        slots['L2'], slots['R2'] = [0.33, 0.25], [0.33, -0.25]
    if task == 'CTX08':
        # Sources are outside the obstacles; destinations face the shared area.
        slots['L1'], slots['R1'] = [0.30, 0.40], [0.30, -0.40]
    elif task == 'CTX07':
        # Move inward toward the two sides of the central plate, but stop on
        # the table before its rim. Both push and carry share these endpoints.
        slots['L1'], slots['R1'] = [0.24, 0.34], [0.24, -0.34]
        slots['BESIDE_P_L'], slots['BESIDE_P_R'] = [0.24, 0.19], [0.24, -0.19]
    elif task == 'CTX05':
        # A/B change object identity at S1/S2, never these physical centers.
        # The whole arrangement stays on +Y: no opposite-side retrieval.
        slots.update(S1=[.12, .39], S2=[.25, .39], P=[.25, .14])
        slots['P_BANANA'] = [slots['P'][0], slots['P'][1] + .035]
        slots['P_BLUE'] = [slots['P'][0], slots['P'][1] - .045]
    elif task == 'CTX10':
        slots.update(L1=[.22, .35], Z_N=[.23, .20], Z_F=[.35, .20])
    rng = np.random.default_rng(args.scene_seed)
    config = {
        'task': task, 'protocol': protocol['protocol_version'], 'variant': args.variant,
        'pair_id': args.pair_id, 'scene_seed': args.scene_seed, 'mirror': False,
        'status': 'pilot_uncalibrated', 'real_calibration_status': 'provisional',
        'instruction_language': base.POLICY_LANGUAGE, 'language_contract': base.LANGUAGE_CONTRACT,
        'sampler_version': 'context_suite_v07_workspace_candidates_v1',
        'protocol_layout_deviation': None,
        'geometry_status': 'provisional_scaled_props_and_table; physical task execution must pass before success',
        'articulation_self_collisions_enabled': True,
        'robot_container_collision_checks': True,
        'robot_torso_collision_checks': True,
        'robot_torso_path': '/world/OpenArmX/openarmx_body_link0',
        'motion_tracking_checks': True,
        'structural_self_collision_exclusions': filtered_wrist_pairs + [item['pair'] for item in finger_exclusions],
        'fixed_equivalent_finger_exclusion_evidence': finger_exclusions,
        'seed_usage': 'scene_seed controls initial object XY jitter within +/-1 mm; variant never enters RNG. The suite expert does not consume the sampled duration/wait/lift fields as motion randomization.',
        'unused_legacy_sampler_fields': ['boundary_wait', 'initial_wait', 'parameters.*.duration_scale',
                                         'parameters.*.lift_height', 'parameters.*.lift_hold'],
        'trajectory_diversity_validated': False,
        'tabletop': tabletop, 'table_scale': [1.5, 1, 1],
        'objects': {}, 'parameters': {}, 'fixtures': {},
        'support_paths': {'table': '/world/table/table_01/top'},
        'obstacle_support_paths': {},
        'goals': {}, 'goal_surfaces': {}, 'container_geometry': {}, 'asset_metadata': {},
        'slots': {}, 'protocol_plan': protocol,
        'home': {'left': [0.30, 0.20, 0.44], 'right': [0.30, -0.20, 0.44]},
        'boundary_wait': float(rng.uniform(0.65, 1.05)),
        'initial_wait': float(rng.uniform(0.5, 0.8)),
        'held_neutral': {'left': [0.29, 0.19, 0.42], 'right': [0.29, -0.19, 0.42]},
        'route_geometry': {'near_x': 0.19, 'far_x': 0.42,
                           'obstacle_crossing_abs_y': 0.25,
                           'source_abs_y': 0.40, 'target_abs_y': 0.10,
                           'clear_abs_y_outer': 0.35, 'clear_abs_y_inner': 0.15},
    }
    if sample is not None:
        config.update(episode_sampling=sample, sampler_version=sample['domain_version'],
            seed_usage='Three explicit object-keyed seed streams; variant never enters sampling. Actual measured diversity requires independent audit.',
            unused_legacy_sampler_fields=['boundary_wait', 'initial_wait'],
            sampling_consumption_scope={
                'scene': 'nonstatic initial object XY and block yaw; fixed reference mount/pose and fixtures',
                'motion': 'generic Cartesian and wrist reorientation durations slowed once; outside initial-table pick lift/hold except obstacle route CTX08',
                'timing': 'ordinary noninitial instruction holds only; initial setup and explicit wait/hold durations unchanged',
                'exceptions': 'specialized stable bowl-return internal trajectory timing stays fixed; central/shared and bowl lift geometry unchanged',
                'runtime_consumption_verified': False, 'trajectory_diversity_validated': False})
    if not fruit_task and task not in OVAL_PLATE_TASKS and any(name in protocol['containers'] for name in ('N', 'F')):
        config['bowl_block_grasp_pitch'] = {'N': -0.65, 'F': -0.85}
        config['container_place_pitch'] = {'N': -0.65, 'F': -0.85}
        config['block_bowl_workspace'] = {
            'version': 'reachable_block_bowls_v2',
            'centers_x_m': {'N': near_x, 'F': far_x},
            'status': 'candidate_pending_contact_driven_execution',
            'semantics': 'Same central near/far task relation, asset scales, table height and initial clearance requirement; not calibrated to real hardware',
        }
    if task in ('CTX13', 'CTX14', 'CTX16'):
        config['container_place_pitch'] = workspace['place_pitch'].copy()
        config['single_payload_bowl_workspace'] = {
            **workspace, 'status': 'geometry_candidate_pending_physics',
            'object_scales_changed': False,
            'geometry_report': 'single_fruit_bowl_capacity_080_20261015.json',
            'limitation': 'Ideal-grasp 30Hz native-geometry screening only; measured grasp, release, settling and complete task remain unverified until episode audit',
        }
    if task in RECTANGULAR_BOWL_TASKS:
        config['sampler_version'] = 'context_suite_original_workspace_v3_shallow_rectangles'
        config['rectangular_bowl_workspace'] = {
            **workspace, 'asset': str(RECTANGULAR_BOWL_ASSET),
            'outer_dimensions_m': [.12, .25, .025],
            'inner_dimensions_xy_m': [.114, .244], 'wall_floor_thickness_m': .003,
            'status': 'candidate_pending_full_task_physics',
            'user_authorized_shape_revision': True, 'real_counterpart_calibrated': False,
            'object_scales_changed': False, 'near_far_semantics_unchanged': True,
            'geometry_report': 'shallow_rectangular_container_candidate_20261015.json',
        }
        config['container_bridge_abs_y'] = .20
        config['container_place_pitch_by_object'] = {
            name: {'N': -.4, 'F': (-.4 if task == 'CTX11' else -.85) if name == 'blue' else -.65}
            for name in protocol['props']}
        config['bowl_block_grasp_pitch'] = {'N': -.4, 'F': -.85}
    if task in OVAL_PLATE_TASKS:
        config['low_rim_plate_workspace'] = {
            **workspace, 'status': 'candidate_pending_full_task_physics',
            'native_plate_asset_reused': True, 'object_scales_changed': False,
            'real_counterpart_calibrated': False, 'far_container_retrieval_permitted': False,
            'nominal_outer_dimensions_xy_m': [.125713, .264659],
            'source': 'vomp/plate_large/plate_large.usd',
        }
        config['container_bridge_abs_y'] = .20
        config['container_place_pitch_by_object'] = {
            name: {'N': -.4, 'F': -.65} for name in protocol['props']}
    if task == 'CTX05':
        config['single_arm_workspace'] = {
            'version': 'v07_ctx05_left_source_slots_and_plate_candidate_v1',
            'active_arm': 'left', 'inactive_arm': 'right', 'cross_side_grasp': False,
            'status': 'candidate_pending_full_task_physics',
            'comfort_verified': False, 'real_counterpart_calibrated': False,
            'scope': 'Candidate layout only; plate regrasp, packing, all-body clearance and paired query matching remain gates',
        }
        config['container_place_pitch'] = {'P': -.4}
        # Reviewed nominal endpoint candidates, not a physics certificate.
        # Do not let the generic orientation search select another S2 pose
        # that only passes a looser endpoint check than the CPU screening.
        config['fixed_grasp_pitch_by_slot'] = {'S1': 0., 'S2': -.4,
                                              'P_BANANA': 0., 'P_BLUE': 0.}
        config['fixed_table_place_pitch_by_slot'] = {'S1': 0., 'S2': -.4}
    if task == 'CTX06':
        config['region_workspace'] = {
            'version': 'table_regions_v2', 'centers_x_m': {'Z_N': .27, 'Z_F': .39},
            'geometry_report': 'CTX06_candidate_regions_full_path_screen_v2.json',
            'status': 'conditional_geometry_candidate_pending_physics',
            'limitation': 'Full 30Hz CPU trajectory screen assumes upright supported regrasp state; actual release and regrasp must pass physical validation',
        }
    if task == 'CTX10':
        config['region_workspace'] = {
            'version': 'v07_left_table_regions_candidate_v1',
            'centers_xy_m': {name: slots[name] for name in ('Z_N', 'Z_F')},
            'status': 'candidate_pending_full_task_physics',
            'active_arm': 'left', 'no_containers': True, 'comfort_verified': False,
        }
    for name, xyz in slots.items():
        p = list(xyz) if len(xyz) == 3 else [*xyz, tabletop]
        config['slots'][name] = p
        config['goals'][name] = p.copy()
        config['goal_surfaces'][name] = 'table'

    # Fixed landing cells are identical in the A/B scene convention and apply
    # from the FIRST placement. Center-first packing leaves no safe room for a
    # second fruit/third block. These are expert goals, never policy inputs;
    # their actual supported placement and non-interference still need checks.
    config['container_landing_offsets'] = {}
    if task == 'CTX03':
        config['container_landing_offsets']['P'] = {'red': [0, 0.045], 'blue': [0, -0.045], 'brown': [0, -0.045]}
    elif task == 'CTX05':
        config['container_landing_offsets']['P'] = {'banana': [0, .035], 'blue': [0, -.045]}
    elif task == 'CTX15':
        config['container_landing_offsets']['P'] = {
            'red': [-0.040, 0.035], 'flesh': [0.040, 0.035],
            'blue': [-0.040, -0.035], 'brown': [0.040, -0.035]}
    elif task == 'CTX09':
        for slot in ('N', 'F'):
            config['container_landing_offsets'][slot] = {'banana': [0, 0.035], 'apple': [0, -0.045], 'blue': [0, 0]}
    elif task == 'CTX11':
        for slot in ('N', 'F'):
            config['container_landing_offsets'][slot] = {'banana': [0, 0.040], 'lemon': [0, 0.040], 'blue': [0, -0.040]}
    if config['container_landing_offsets']:
        config['packing_audit'] = {'version': 'v2', 'min_xy_aabb_clearance_m': 0.005,
                                   'max_landing_xy_error_m': 0.003,
                                   'threshold_semantics': 'planning_advisory_not_task_success',
                                   'status': 'candidate_pending_physical_validation'}

    def asset_info(asset):
        asset = Path(asset)
        source_stage = Usd.Stage.Open(str(asset))
        source_root = source_stage.GetDefaultPrim()
        if not source_root:
            raise RuntimeError(f'Asset has no default root: {asset}')
        transform = np.asarray(UsdGeom.Xformable(source_root).GetLocalTransformation()).T
        native_scale = np.linalg.norm(transform[:3, :3], axis=0)
        if not np.allclose(transform[:3, :3], np.diag(native_scale), atol=1e-6) or not np.allclose(transform[:3, 3], 0):
            raise RuntimeError(f'Unexpected asset root transform requires explicit conversion: {asset}')
        bounds = UsdGeom.BBoxCache(0, ['default', 'render']).ComputeUntransformedBound(source_root).ComputeAlignedRange()
        lo, hi = np.asarray(bounds.GetMin()), np.asarray(bounds.GetMax())
        return str(source_root.GetPath()), native_scale, lo, hi

    def reference(name, asset, slot, relative_scale, *, yaw=0.0, static=False, mass=0.04, compound_fixture=False):
        source, native, lo, hi = asset_info(asset)
        relative = np.broadcast_to(np.asarray(relative_scale, dtype=float), (3,)).copy()
        applied = native * relative
        rotation = Rotation.from_euler('z', yaw)
        corners = np.asarray(list(itertools.product(*zip(lo, hi)))) * applied
        rotated = rotation.apply(corners)
        xy = np.asarray(slots[slot][:2], dtype=float)
        if not static:
            xy += (np.asarray(sample['objects'][name]['xy_offset_m']) if sample is not None
                   else rng.uniform(-0.001, 0.001, 2))
        position = np.r_[xy, tabletop - rotated[:, 2].min() + (0.0003 if static else 0.001)]
        path = f'/world/suite_{name}'
        prim = stage.DefinePrim(path, 'Xform')
        prim.GetReferences().AddReference(str(asset), source)
        xf = UsdGeom.Xformable(prim)
        xf.ClearXformOpOrder()
        xf.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble, 'suite').Set(Gf.Vec3d(*position))
        xf.AddOrientOp(UsdGeom.XformOp.PrecisionDouble, 'suite').Set(Gf.Quatd(np.cos(yaw / 2), Gf.Vec3d(0, 0, np.sin(yaw / 2))))
        xf.AddScaleOp(UsdGeom.XformOp.PrecisionDouble, 'suite').Set(Gf.Vec3d(*applied))
        if compound_fixture and not static:
            raise ValueError('Compound fixture must be a stationary container')
        rigid = UsdPhysics.RigidBodyAPI.Apply(prim)
        rigid.CreateRigidBodyEnabledAttr(not static or compound_fixture)
        if compound_fixture:
            # One stationary actor owns five independent solid collision shapes.
            # Disabling this root body loses compound-actor contact aggregation.
            rigid.CreateKinematicEnabledAttr(True)
        body = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
        body.CreateSolverPositionIterationCountAttr(32)
        body.CreateSolverVelocityIterationCountAttr(8)
        body.CreateLinearDampingAttr(0.5)
        body.CreateAngularDampingAttr(0.5)
        body.CreateMaxDepenetrationVelocityAttr(1.0)
        if not static:
            UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(mass)
        colliders = []
        for subprim in Usd.PrimRange(prim):
            if subprim.HasAPI(UsdPhysics.CollisionAPI):
                colliders.append(str(subprim.GetPath()))
            if subprim.HasAPI(UsdPhysics.MaterialAPI):
                material = UsdPhysics.MaterialAPI(subprim)
                material.CreateStaticFrictionAttr(0.9)
                material.CreateDynamicFrictionAttr(0.7)
                material.CreateRestitutionAttr(0.0)
        if not colliders:
            raise RuntimeError(f'Asset has no collider under referenced root: {asset}')
        metadata = {
            'source': str(asset), 'source_prim': source,
            'source_sha256': hashlib.sha256(Path(asset).read_bytes()).hexdigest(),
            'native_scale': native.tolist(), 'relative_scale': relative.tolist(),
            'applied_scale': applied.tolist(),
            'local_bounds_m': [(lo * applied).tolist(), (hi * applied).tolist()],
            'world_initial_aabb_m': [(rotated.min(axis=0) + position).tolist(), (rotated.max(axis=0) + position).tolist()],
            'colliders': colliders, 'static': static, 'compound_kinematic_fixture': compound_fixture,
        }
        config['asset_metadata'][name] = metadata
        return path, position, lo * applied, hi * applied, metadata

    for name, spec in protocol['props'].items():
        scale = {'banana': 0.55, 'apple': 0.70, 'lemon': 0.85}.get(name, 1.0)
        yaw = np.pi / 2 if name == 'banana' else 0.0
        if sample is not None:
            yaw += sample['objects'][name]['yaw_offset_rad']
        path, position, lo, hi, info = reference(name, spec['asset'], spec['slot'], scale,
                                               yaw=yaw, mass=0.06 if name == 'banana' else 0.02)
        grasp_offset = np.array([0.0, 0.0, 0.006])
        if name == 'banana':
            # Native finger/banana triangle audit leaves >4 mm table clearance
            # at this candidate, unlike the former almost-table-touching point.
            # Physical bilateral contact/lift validation remains mandatory.
            grasp_offset = np.array([-0.025 * scale, 0.0, 0.010])
        elif name in ('apple', 'lemon'):
            grasp_offset = (lo + hi) / 2 + [0, 0, 0.002]
        config['objects'][name] = path
        config['parameters'][name] = {
            'side': spec['side'], 'slot': spec['slot'], 'position': position.tolist(),
            'mass_kg': 0.06 if name == 'banana' else 0.02,
            'object_yaw': float(yaw), 'grasp_yaw': 0.0,
            'grasp_pitch': -0.4 if position[0] > 0.34 or spec['side'] == 'shared' else 0.0,
            'grasp_xy_offset': [0.0, 0.0], 'grasp_local_offset': grasp_offset.tolist(),
            'scale': scale, 'applied_scale': info['applied_scale'],
            'duration_scale': float(rng.uniform(0.95, 1.05)),
            'lift_height': 0.07, 'lift_hold': 0.4,
        }
        if sample is not None:
            draw = sample['objects'][name]
            config['parameters'][name].update(duration_scale=draw['duration_scale'],
                lift_height=draw['lift_height_m'], lift_hold=draw['lift_hold_s'])

    for name, spec in protocol['containers'].items():
        is_plate = spec.get('kind') == 'plate' or name == 'P'
        scale = workspace['scale'] if task in OVAL_PLATE_TASKS else (0.70 if is_plate else bowl_scale)
        rectangle = task in RECTANGULAR_BOWL_TASKS and not is_plate
        asset = RECTANGULAR_BOWL_ASSET if rectangle else spec['asset']
        path, position, lo, hi, info = reference(name, asset, spec['slot'], scale,
                                                static=True, compound_fixture=rectangle)
        if rectangle:
            expected = {path + '/' + part for part in ('floor', 'near_wall', 'far_wall', 'left_wall', 'right_wall')}
            if set(info['colliders']) != expected or len(info['colliders']) != 5:
                raise RuntimeError(f'Compound container needs exactly five separate box colliders: {name}')
            config['fixtures'][name] = path
            config['support_paths'][name] = path  # actor filter aggregates floor and all four walls
            geometry = shallow_rectangle_geometry(position[:2], base_z=float(position[2]))
            geometry['contact_filter_path'] = path
            geometry['collision_shape_paths'] = info['colliders']
        else:
            if len(info['colliders']) != 1:
                raise RuntimeError(f'Container requires a single registered contact collider: {name}')
            config['fixtures'][name] = info['colliders'][0]
            config['support_paths'][name] = info['colliders'][0]
            relative = np.broadcast_to(np.asarray(scale, dtype=float), (3,))
            inner_radius = (0.145 if is_plate else 0.0745) * relative[0]
            geometry = {
                'kind': 'plate' if is_plate else 'bowl', 'center': position.tolist(),
                'rim_z': float(position[2] + hi[2]),
                'floor_z': float(tabletop + (0.006 if is_plate else 0.004) * relative[2]),
                'inner_radius': inner_radius,
                'outer_radius': float(max(abs(lo[0]), abs(hi[0]), abs(lo[1]), abs(hi[1]))),
                'scale': scale,
            }
            if task in OVAL_PLATE_TASKS:
                from context_container_geometry import SCHEMA, validate_geometry
                geometry.pop('inner_radius')
                geometry.pop('outer_radius')
                geometry.update(footprint_schema=SCHEMA, shape='ellipse', yaw=0.,
                    inner_half_extents=(.145 * relative[:2]).tolist(),
                    outer_half_extents=np.maximum(np.abs(lo[:2]), np.abs(hi[:2])).tolist())
                validate_geometry(geometry)
        geometry['capacity_status'] = 'requires per-episode supported non-stacked containment validation'
        config['container_geometry'][name] = geometry
        config['goals'][name] = [*position[:2], geometry['floor_z']]
        config['goal_surfaces'][name] = name
        if task == 'CTX05' and name == 'P':
            for obj, alias in spec['placement_slots'].items():
                point = config['goals']['P'].copy()
                point[:2] = (np.asarray(point[:2]) + config['container_landing_offsets']['P'][obj]).tolist()
                config['slots'][alias] = point.copy()
                config['goals'][alias] = point.copy()
                config['goal_surfaces'][alias] = 'P'

    for name, spec in protocol['obstacles'].items():
        path, position, lo, hi, info = reference('obstacle_' + name, spec['asset'], spec['slot'], [2, 1, 3], static=True)
        config['fixtures']['obstacle_' + name] = info['colliders'][0]
        config['support_paths']['obstacle_' + name] = info['colliders'][0]
        config['obstacle_support_paths']['obstacle_' + name] = info['colliders'][0]
        config['route_geometry'][name] = {'path': path, 'aabb_m': info['world_initial_aabb_m']}

    if task == 'CTX08':
        config['routes'], config['emptyroutes'], config['route_empty_approach'] = {}, {}, {}
        config['route_orientation_pitch'] = {'near': 0.0, 'far': -0.4}
        for side, sign in [('left', 1), ('right', -1)]:
            config['home'][side] = [0.30, sign * 0.10, 0.44]
            config['held_neutral'][side] = [0.30, sign * 0.40, 0.40]
            near = [[0.30, 0.40, 0.40], [0.19, 0.40, 0.40],
                    [0.19, 0.35, 0.37], [0.19, 0.15, 0.37],
                    [0.30, 0.15, 0.37], [0.30, 0.10, 0.37]]
            far = [[0.30, 0.40, 0.40], [0.37, 0.37, 0.40],
                   [0.41, 0.35, 0.40], [0.41, 0.15, 0.40],
                   [0.30, 0.15, 0.40], [0.30, 0.10, 0.40]]
            config['routes'][side] = {
                route: [[x, sign * y, z] for x, y, z in points]
                for route, points in [('near', near), ('far', far)]}
            # The safe waiting pose is INSIDE the obstacle. Empty approach to
            # an outside source must also use a corridor, never cut through it.
            config['route_empty_approach'][side] = {
                route: list(reversed(points)) for route, points in config['routes'][side].items()}
            # After landing inside, withdraw on that same side then home. No
            # reason to cross the obstacle again with an empty hand.
            config['emptyroutes'][side] = {
                route: [[0.30, sign * 0.10, 0.40], config['home'][side]]
                for route in ('near', 'far')}
        config['route_geometry']['far_x'] = 0.41
        config['route_geometry']['waypoint_validation'] = 'offline joint-limit IK candidates; physical corridor/contact proof required'

    # Same paper labels in both branches, outside target footprints. No answer
    # highlight, past-object outline, collision geometry or dynamic state.
    marker_slots = ('Z_N', 'Z_F') if task in ('CTX06', 'CTX10') else (('S1', 'S2') if task == 'CTX05' else ())
    for slot in marker_slots:
        from context_scene_markers import add_paper_marker
        center = np.asarray(config['goals'][slot])
        half = .055 if task == 'CTX05' else .045
        config.setdefault('table_regions', {})[slot] = {'center': center.tolist(), 'half_extents_xy': [half, half]}
        lines = ('N', 'NEAR') if slot == 'Z_N' else (('F', 'FAR') if slot == 'Z_F' else (slot,))
        marker_center = [center[0], center[1] + half + .027, tabletop + .0002]
        config.setdefault('region_markers', {})[slot] = add_paper_marker(stage,
            path='/world/marker_' + slot, center=marker_center, lines=lines)

    if 'N' in config['container_geometry'] and 'F' in config['container_geometry']:
        n, f = (config['container_geometry'][key] for key in ('N', 'F'))
        if task in RECTANGULAR_BOWL_TASKS or task in OVAL_PLATE_TASKS:
            spacing = container_spacing(n, f)
            clearance = spacing['separation_lower_bound_m']
            config['container_spacing_evidence'] = spacing
        else:
            clearance = np.linalg.norm(np.asarray(n['center'])[:2] - np.asarray(f['center'])[:2]) - n['outer_radius'] - f['outer_radius']
        config['container_rim_clearance_m'] = float(clearance)
        if clearance < 0.05:
            raise RuntimeError(f'Containers violate initial 5 cm rim clearance: {clearance}')
    config['original_layout_assertions'] = {
        'L2_forward_of_L1': slots['L2'][0] > slots['L1'][0],
        'R2_forward_of_R1': slots['R2'][0] > slots['R1'][0],
        'near_far_on_robot_centerline': slots['N'][1] == slots['F'][1] == 0,
        'near_is_smaller_x': slots['N'][0] < slots['F'][0],
        'scene_contains_no_task_text_or_branch_label': True,
    }
    PhysxSchema.PhysxSceneAPI.Apply(stage.GetPrimAtPath('/world/PhysicsScene')).CreateTimeStepsPerSecondAttr(240)
    camera = UsdGeom.Camera(stage.GetPrimAtPath('/world/OverviewCamera'))
    UsdGeom.Xformable(camera).GetOrderedXformOps()[0].Set(Gf.Matrix4d().SetLookAt(
        Gf.Vec3d(1.1, -1.0, 1.0), Gf.Vec3d(0.25, 0, 0.38), Gf.Vec3d(0, 0, 1)).GetInverse())
    # Apply after child pruning so the broad fill lights remain active. The
    # existing table collider/geometry/material friction are not replaced.
    if getattr(args, 'appearance_mode', 'white') != 'legacy':
        from context_scene_appearance import apply_scene_appearance
        config['appearance'] = apply_scene_appearance(stage)
    if getattr(args, 'reference_start_pose', None):
        from context_scene_reference import apply_reference_start
        config['reference_start_pose'] = apply_reference_start(stage, args.reference_start_pose)
    layer.Export(str(args.output / 'scene.usda'))
    base.save_json(args.output / 'scene_config.json', config)
    return config
