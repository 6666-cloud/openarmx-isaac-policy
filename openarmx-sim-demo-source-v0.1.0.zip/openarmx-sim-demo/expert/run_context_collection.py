"""Versioned, physically executed CTX12 pilot with causal three-camera recording.

Only joint PD targets are commanded after initialization. No object attachment,
pose teleport, or learned-policy claim. Real camera/actuator calibration pending.
Policy instructions and language events are English; Chinese is display-only.
"""
import argparse
from collections import deque
from functools import wraps
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback


COLLECTOR_WALL_START = time.perf_counter()
PERFORMANCE_SECTIONS = {}


def _record_performance(name, started, *, failed=False):
    """Diagnostic wall-time only; never reads or advances simulation state."""
    elapsed = time.perf_counter() - started
    row = PERFORMANCE_SECTIONS.setdefault(name, {
        'calls': 0, 'failed_calls': 0, 'total_s': 0.0, 'max_s': 0.0,
    })
    row['calls'] += 1
    row['failed_calls'] += int(failed)
    row['total_s'] += elapsed
    row['max_s'] = max(row['max_s'], elapsed)


def _timed_call(name, callback, *call_args, **call_kwargs):
    started = time.perf_counter()
    failed = True
    try:
        value = callback(*call_args, **call_kwargs)
        failed = False
        return value
    finally:
        _record_performance(name, started, failed=failed)


def _profile_section(name):
    def decorate(callback):
        @wraps(callback)
        def measured(*call_args, **call_kwargs):
            return _timed_call(name, callback, *call_args, **call_kwargs)
        return measured
    return decorate

from context_instructions import (
    CTX12_INSTRUCTIONS, LANGUAGE_CONTRACT, POLICY_LANGUAGE, require_policy_english,
)


def arguments():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--task', choices=[f'CTX{i:02d}' for i in range(1, 17)] + ['CTX18', 'CTX20'], default='CTX12')
    p.add_argument('--suite', action='store_true', help='Use the non-mirrored full-task suite expert')
    p.add_argument('--variant', choices=['A', 'B'], required=True)
    p.add_argument('--scene-seed', type=int, required=True)
    p.add_argument('--nuisance-seed', type=int)
    p.add_argument('--motion-seed', type=int)
    p.add_argument('--diverse-episodes', action='store_true',
                   help='Consume all three explicit seeds using the bounded candidate episode sampler')
    p.add_argument('--pair-id', required=True)
    p.add_argument('--mirror', action='store_true')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--camera-config', type=Path)
    p.add_argument('--shader-cache-dir', type=Path,
                   help='Explicit per-lane renderer driver cache; does not change render/physics settings')
    p.add_argument('--gui', action='store_true')
    p.add_argument('--no-images', action='store_true', help='Physics-only diagnostic, not training data')
    p.add_argument('--stream-video', action='store_true',
                   help='Explicit raw-video-v2: numeric HDF and three synchronized H264 streams')
    p.add_argument('--encoder-queue-size', type=int, choices=(0, 1, 2), default=0,
                   help='Bounded immutable RGB encoding queue; 0 is the synchronous reference')
    p.add_argument('--pixel-statistics-mode', choices=('numpy_reference', 'exact_histogram'),
                   default='numpy_reference', help='Equivalent source RGB statistics implementation')
    p.add_argument('--probe', action='store_true', help='Load/settle/camera inspection only')
    p.add_argument('--reference-start-pose', type=Path,
                   help='Explicit simulation-only real-reference pose profile; not motor calibration')
    p.add_argument('--setup-probe', action='store_true',
                   help='Reference pose to operational waiting only; never a successful task episode')
    return p.parse_args()


args = arguments()
if args.suite and args.mirror:
    raise ValueError('The requested suite uses original layout only, not mirrored scenes')
if args.task != 'CTX12' and not args.suite:
    raise ValueError('Tasks other than the legacy CTX12 pilot require --suite')
if args.reference_start_pose and not args.suite:
    raise ValueError('Reference start requires the guarded full-task suite controller')
if args.setup_probe and (not args.suite or not args.reference_start_pose or args.probe):
    raise ValueError('--setup-probe requires --suite --reference-start-pose and excludes --probe')
if args.stream_video and args.no_images:
    raise ValueError('--stream-video requires all three camera streams')
if args.diverse_episodes:
    if not args.suite or args.nuisance_seed is None or args.motion_seed is None:
        raise ValueError('--diverse-episodes requires --suite and all three explicit seed streams')
elif args.nuisance_seed is not None or args.motion_seed is not None:
    raise ValueError('Reserved seeds must not be passed without --diverse-episodes')
from runtime_paths import asset_root, experience_path
ROOT = asset_root()
shader_cache = (args.shader_cache_dir or Path(os.environ['OPENARMX_DEMO_CACHE'])).resolve()
shader_cache.mkdir(parents=True, exist_ok=True)
args.output.mkdir(parents=True, exist_ok=False)
from isaacsim import SimulationApp
from context_render_sync import simulation_app_overrides
app = _timed_call('simulation_app_initialization', SimulationApp, {
    'headless': not args.gui, 'renderer': 'RayTracedLighting',
    'multi_gpu': False, 'width': 640, 'height': 480,
    'window_width': 1440, 'window_height': 900,
    'fast_shutdown': True,
    **simulation_app_overrides(['--/isaac/startup/ros_bridge_extension=',
                   f'--/rtx/shaderDb/driverShaderCachePath={shader_cache}']),
}, experience=str(experience_path()))

import h5py
from context_physics_clock import PhysicsClockGuard, validate_callback_step_samples
from context_camera_warmup import CameraWarmupGuard, REQUIRED_CAPTURES
import imageio.v2 as imageio
import numpy as np
import omni.usd
from pxr import Gf, PhysxSchema, Sdf, Usd, UsdGeom, UsdPhysics
from scipy.spatial.transform import Rotation
from isaacsim.core.api import World
from isaacsim.core.prims import RigidPrim, SingleArticulation, SingleRigidPrim, SingleXFormPrim
from isaacsim.core.simulation_manager import SimulationManager
from isaacsim.core.utils.types import ArticulationAction
from kinematics import ArmKinematics
from context_asset_scale import SCHEMA as SCALE_SCHEMA, expected_scales, new_evidence, capture_checkpoint

DT, SUBSTEPS, FPS = 1 / 240, 8, 30
COLORS = ('red', 'blue', 'brown')
SIDES = ('left', 'right')
live_view = None


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def create_scene():
    layer = Sdf.Layer.CreateAnonymous('context_pilot.usda')
    layer.subLayerPaths = [str(ROOT / 'RoboLab/assets/scenes/openarmx_banana_loop.usda')]
    stage = Usd.Stage.Open(layer)
    UsdGeom.SetStageMetersPerUnit(stage, 1.0)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    keep = {'OpenArmX', 'table', 'franka_table', 'GroundPlane', 'Looks', 'PhysicsScene',
            'EnvironmentLight', 'KeyLight', 'OverviewCamera', 'Render'}
    for child in stage.GetPrimAtPath('/world').GetChildren():
        if child.GetName() not in keep:
            child.SetActive(False)
    cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), ['default', 'render'])
    tabletop = float(cache.ComputeWorldBound(stage.GetPrimAtPath('/world/table/table_01/top')).ComputeAlignedRange().GetMax()[2])
    rng = np.random.default_rng(args.scene_seed)
    flip = -1 if args.mirror else 1
    positions = {'red': [0.29, 0.17 * flip], 'brown': [0.28, 0.29 * flip], 'blue': [0.29, -0.19 * flip]}
    config = {'task': args.task, 'protocol': 'v0.6', 'variant': args.variant,
              'pair_id': args.pair_id, 'scene_seed': args.scene_seed, 'mirror': args.mirror,
              'status': 'pilot_uncalibrated', 'real_calibration_status': 'provisional',
              'instruction_language': POLICY_LANGUAGE, 'language_contract': LANGUAGE_CONTRACT,
              'sampler_version': 'ctx12_pilot_workspace_v4',
              'protocol_layout_deviation': 'Pilot: brown is outward laterally from red, not the v0.6 forward L2 slot. Forward L2 low grasp failed IK. This pilot does not count toward frozen-protocol quotas.',
              'seed_usage': 'scene_seed drives all physical/nuisance/motion draws; variant never enters RNG',
              'tabletop': tabletop, 'objects': {}, 'parameters': {},
              'home': {'left': [0.30, 0.20, 0.44], 'right': [0.30, -0.20, 0.44]}}
    for color in COLORS:
        xy = np.array(positions[color]) + rng.uniform(-0.006, 0.006, 2)
        yaw = float(rng.uniform(-0.12, 0.12))
        path = f'/world/{color}_block'
        prim = stage.DefinePrim(path, 'Xform')
        prim.GetReferences().AddReference(str(ROOT / f'RoboLab/assets/objects/basic/{color}_block.usd'), f'/{color}_block')
        xf = UsdGeom.Xformable(prim)
        xf.ClearXformOpOrder()
        xf.AddTranslateOp(UsdGeom.XformOp.PrecisionDouble, 'collection').Set(Gf.Vec3d(float(xy[0]), float(xy[1]), tabletop + 0.0236))
        xf.AddOrientOp(UsdGeom.XformOp.PrecisionDouble, 'collection').Set(Gf.Quatd(np.cos(yaw / 2), Gf.Vec3d(0, 0, np.sin(yaw / 2))))
        body = PhysxSchema.PhysxRigidBodyAPI.Apply(prim)
        body.CreateSolverPositionIterationCountAttr(32)
        body.CreateSolverVelocityIterationCountAttr(8)
        body.CreateLinearDampingAttr(0.5)
        body.CreateAngularDampingAttr(0.5)
        body.CreateMaxDepenetrationVelocityAttr(1.0)
        for subprim in Usd.PrimRange(prim):
            if subprim.HasAPI(UsdPhysics.MaterialAPI):
                material = UsdPhysics.MaterialAPI(subprim)
                material.CreateStaticFrictionAttr(0.9)
                material.CreateDynamicFrictionAttr(0.7)
                material.CreateRestitutionAttr(0.0)
        config['objects'][color] = path
        config['parameters'][color] = {
            'side': 'left' if xy[1] > 0 else 'right',
            'position': [float(xy[0]), float(xy[1]), tabletop + 0.0236],
            'object_yaw': yaw, 'grasp_yaw': yaw + float(rng.uniform(-0.025, 0.025)),
            'grasp_xy_offset': rng.uniform(-0.0015, 0.0015, 2).tolist(),
            'duration_scale': float(rng.uniform(0.9, 1.15)),
            'lift_height': float(rng.uniform(0.065, 0.085)),
            'lift_hold': float(rng.uniform(0.4, 0.7)),
        }
    config['boundary_wait'] = float(rng.uniform(0.65, 1.05))
    config['initial_wait'] = float(rng.uniform(0.5, 0.8))
    PhysxSchema.PhysxSceneAPI.Apply(stage.GetPrimAtPath('/world/PhysicsScene')).CreateTimeStepsPerSecondAttr(240)
    camera = UsdGeom.Camera(stage.GetPrimAtPath('/world/OverviewCamera'))
    UsdGeom.Xformable(camera).GetOrderedXformOps()[0].Set(Gf.Matrix4d().SetLookAt(
        Gf.Vec3d(1.1, -1.0, 1.0), Gf.Vec3d(0.24, 0, 0.35), Gf.Vec3d(0, 0, 1)).GetInverse())
    from context_scene_appearance import apply_scene_appearance
    config['appearance'] = apply_scene_appearance(stage)
    layer.Export(str(args.output / 'scene.usda'))
    save_json(args.output / 'scene_config.json', config)
    return config


class Recorder:
    def __init__(self, names, config, calibration):
        self.streaming = None
        if args.stream_video:
            from context_recording_adapter import RecordingAdapter
            from context_video_recorder import RecorderConfig
            self.streaming = RecordingAdapter(args.output, video_config=RecorderConfig(
                cross_frame_queue_size=args.encoder_queue_size,
                pixel_statistics_mode=args.pixel_statistics_mode))
        self.file = h5py.File(args.output / 'trajectory.hdf5', 'w')
        # Dense attributes support full-task event/protocol JSON >64 KiB.
        self.demo = self.file.create_group('data/demo_0', track_order=True)
        attrs = {'schema_version': 'context_raw_v1', 'joint_names': json.dumps(names),
                 'task_id': args.task, 'pair_id': args.pair_id, 'history_variant': args.variant,
                 'scene_seed': args.scene_seed, 'fps': FPS, 'physics_dt': DT, 'decimation': SUBSTEPS,
                 'action_semantics': 'absolute_joint_position_targets; revolute=rad; prismatic=m',
                 'observation_timing': 'pre_action', 'real_calibration_status': 'provisional',
                 'instruction_language': POLICY_LANGUAGE, 'language_contract': LANGUAGE_CONTRACT,
                 'dataset_status': 'pilot_uncalibrated', 'scene_config': json.dumps(config),
                 'camera_calibration': json.dumps(calibration),
                 'grasp_attachment': False, 'mid_episode_pose_reset': False,
                 'controller': 'parameterized_bimanual_scripted_expert_ik_PD', 'success': False}
        for name, value in attrs.items():
            self.demo.attrs[name] = value
        self.count = 0
        source_names = ['run_context_collection.py', 'kinematics.py', 'context_camera_rig.py',
                        'context_instructions.py', 'context_asset_scale.py', 'context_physics_clock.py',
                        'context_camera_warmup.py', 'context_scene_appearance.py',
                        'context_scene_reference.py', 'inspect_context_start_pose.py',
                        'context_reference_start.py']
        source_names += ['context_render_sync.py', 'context_render_barrier.py', 'context_headless_viewport.py']
        source_names += ['context_live_view.py']
        if args.suite:
            source_names += ['context_scene_markers.py']
            source_names += ['context_table_block_yaw.py']
        if args.stream_video:
            source_names += ['context_recording_adapter.py', 'context_video_recorder.py',
                             'context_video_source.py']
        if args.suite:
            source_names += ['context_suite_runtime.py', 'context_suite_scene.py', 'context_task_protocols.py', 'context_motion_planning.py', 'context_joint_motion.py', 'context_grasp_geometry.py', 'context_push_geometry.py', 'context_bowl_exit.py', 'context_stable_block_return.py', 'context_container_geometry.py', 'context_contact_contract.py', 'context_episode_sampling.py']
        for source_name in source_names:
            source = Path(__file__).with_name(source_name)
            if source.exists():
                shutil.copy2(source, args.output / source_name)
                self.demo.attrs[source_name + '_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
        if config.get('reference_start_pose'):
            reference = config['reference_start_pose']
            for key in ('source_file', 'profile_file'):
                source = Path(reference[key])
                expected = reference[key + '_sha256']
                if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
                    raise RuntimeError('Reference input changed before recording: ' + str(source))
                shutil.copy2(source, args.output / ('reference_' + key + '.json'))

    def append(self, key, value):
        if self.streaming:
            return self.streaming.append(key, value)
        return self.append_numeric(key, value)

    def append_numeric(self, key, value):
        if key == 'instruction':
            require_policy_english(value)
        if isinstance(value, str):
            if key not in self.demo:
                self.demo.create_dataset(key, (0,), maxshape=(None,), dtype=h5py.string_dtype('utf-8'), chunks=True)
            ds = self.demo[key]
        else:
            value = np.asarray(value)
            if np.issubdtype(value.dtype, np.number) and not np.isfinite(value).all():
                raise RuntimeError(f'Non-finite recorded value: {key}')
            if key not in self.demo:
                options = {'compression': 'lzf'} if value.ndim >= 2 else {}
                self.demo.create_dataset(key, (0, *value.shape), maxshape=(None, *value.shape),
                                         chunks=(1, *value.shape), dtype=value.dtype, **options)
            ds = self.demo[key]
        ds.resize(len(ds) + 1, axis=0)
        ds[-1] = value

    def finish(self, result, events):
        self.demo.attrs['success'] = bool(result.get('success', False))
        self.demo.attrs['num_samples'] = self.count
        self.demo.attrs['result'] = json.dumps(result, ensure_ascii=False)
        self.demo.attrs['events'] = json.dumps(events, ensure_ascii=False)
        self.file.flush()
        self.file.close()


class Episode:
    def __init__(self, stage, config):
        self.config, self.stage = config, stage
        self.models = {s: ArmKinematics(stage, s) for s in SIDES}
        self.down = Rotation.from_euler('xyz', [np.pi, 0, 0]).as_matrix()
        physics = stage.GetPrimAtPath('/world/PhysicsScene')
        SimulationManager._physics_scene_apis[str(physics.GetPath())] = PhysxSchema.PhysxSceneAPI(physics)
        self.world = World(physics_dt=DT, rendering_dt=DT, stage_units_in_meters=1,
                           physics_prim_path='/world/PhysicsScene', backend='numpy', device='cpu')
        self.robot = self.world.scene.add(SingleArticulation('/world/OpenArmX', name='openarmx'))
        # Isaac normalizes xformOpOrder and otherwise resurrects an inherited
        # canonical scale instead of our authored scale:suite. Pass the TOTAL
        # applied scale explicitly, before physics initializes the rigid body.
        self.scale_evidence = new_evidence(expected_scales(stage, config))
        self.check_asset_scales('before_wrapping')
        self.objects = {c: self.world.scene.add(SingleRigidPrim(path, name=c,
                        scale=np.asarray(self.scale_evidence['expected'][c]['expected_applied_scale'])))
                        for c, path in config['objects'].items()}
        self.check_asset_scales('after_wrapping')
        self.tips = {s: SingleXFormPrim(f'/world/OpenArmX/openarmx_{s}_hand_tcp') for s in SIDES}
        self.fingers = {s: self.world.scene.add(RigidPrim(f'/world/OpenArmX/openarmx_{s}_.*_finger',
                        name=f'{s}_contacts', contact_filter_prim_paths_expr=list(config['objects'].values()),
                        track_contact_forces=True, max_contact_count=4096)) for s in SIDES}
        self.supports = {c: self.world.scene.add(RigidPrim(path, name=c + '_support',
                         contact_filter_prim_paths_expr=list(config.get('support_paths', {'table': '/world/table/table_01/top'}).values()),
                         track_contact_forces=True, reset_xform_properties=False, max_contact_count=2048))
                         for c, path in config['objects'].items()}
        self.suite_collision_views = {}
        if args.suite:
            arm_paths = {}
            for side in SIDES:
                candidates = [f'/world/OpenArmX/openarmx_{side}_link{i}' for i in range(1, 8)]
                candidates += [f'/world/OpenArmX/openarmx_{side}_hand',
                               f'/world/OpenArmX/openarmx_{side}_left_finger',
                               f'/world/OpenArmX/openarmx_{side}_right_finger']
                arm_paths[side] = [p for p in candidates if stage.GetPrimAtPath(p).IsValid()]
            if not all(arm_paths.values()):
                raise RuntimeError('No bodies found for arm-arm contact recording')
            self.suite_collision_views['arm_arm'] = self.world.scene.add(RigidPrim(
                arm_paths['left'], name='suite_arm_arm_contacts',
                contact_filter_prim_paths_expr=[arm_paths['right'] for _ in arm_paths['left']],
                track_contact_forces=True, reset_xform_properties=False, max_contact_count=8192))
            torso = config['robot_torso_path']
            if not stage.GetPrimAtPath(torso).IsValid():
                raise RuntimeError('Missing robot torso body for contact recording: ' + torso)
            bodies = arm_paths['left'] + arm_paths['right']
            self.suite_collision_views['robot_torso'] = self.world.scene.add(RigidPrim(
                bodies, name='suite_robot_torso_contacts',
                contact_filter_prim_paths_expr=[[torso] for _ in bodies], track_contact_forces=True,
                reset_xform_properties=False, max_contact_count=8192))
            if config.get('reference_start_pose'):
                self.suite_collision_views['robot_table'] = self.world.scene.add(RigidPrim(
                    bodies, name='suite_robot_table_contacts',
                    contact_filter_prim_paths_expr=[[config['support_paths']['table']] for _ in bodies],
                    track_contact_forces=True, reset_xform_properties=False, max_contact_count=8192))
            containers = [path for name, path in config['support_paths'].items() if name != 'table']
            if containers:
                bodies = arm_paths['left'] + arm_paths['right']
                self.suite_collision_views['robot_container'] = self.world.scene.add(RigidPrim(
                    bodies, name='suite_robot_container_contacts',
                    contact_filter_prim_paths_expr=[containers for _ in bodies], track_contact_forces=True,
                    reset_xform_properties=False, max_contact_count=8192))
            obstacles = list(config.get('obstacle_support_paths', {}).values())
            if obstacles:
                self.suite_collision_views['robot_obstacle'] = self.world.scene.add(RigidPrim(
                    arm_paths['left'] + arm_paths['right'], name='suite_robot_obstacle_contacts',
                    contact_filter_prim_paths_expr=[obstacles for _ in arm_paths['left'] + arm_paths['right']], track_contact_forces=True,
                    reset_xform_properties=False, max_contact_count=8192))
                self.suite_collision_views['object_obstacle'] = self.world.scene.add(RigidPrim(
                    list(config['objects'].values()), name='suite_object_obstacle_contacts',
                    contact_filter_prim_paths_expr=[obstacles for _ in config['objects']], track_contact_forces=True,
                    reset_xform_properties=False, max_contact_count=8192))
        self.world.reset()
        self.render_sync_settings = None
        self.image_sync_report = None
        if not args.no_images:
            from context_render_sync import configure_render_sync_after_reset
            self.render_sync_settings = configure_render_sync_after_reset()
            save_json(args.output / 'render_sync_settings.json', self.render_sync_settings)
        self.check_asset_scales('after_reset')
        self.names = list(self.robot.dof_names)
        self.arm_ids = {s: np.array([self.names.index(n) for n in self.models[s].names]) for s in SIDES}
        self.finger_ids = {s: np.array([i for i, n in enumerate(self.names) if f'{s}_finger_joint' in n]) for s in SIDES}
        self.target = self.robot.get_joint_positions().copy()
        if config.get('reference_start_pose'):
            named = config['reference_start_pose']['joint_positions_by_name']
            if set(named) != set(self.names):
                raise RuntimeError('Reference/actual articulation joint-name mismatch')
            self.target[:] = [named[name] for name in self.names]
        else:
            for s in SIDES:
                self.target[self.arm_ids[s]] = self.models[s].solve(config['home'][s], self.down)
                # Both empty hands share the same waiting state at a query.
                self.target[self.finger_ids[s]] = 0.044
        self.robot.set_joint_positions(self.target)
        self.robot.set_joint_velocities(np.zeros_like(self.target))
        self.robot.apply_action(ArticulationAction(joint_positions=self.target))
        self.rig = None
        if not args.no_images:
            from context_camera_rig import ContextCameraRig
            self.rig = ContextCameraRig(stage, args.camera_config)
            self.rig.initialize()
            # The full Kit experience also creates an unrecorded default
            # viewport. Disable only that viewport's updates in headless mode;
            # the helper rejects aliases to any recorded sensor render product.
            from context_headless_viewport import configure_headless_viewport
            self.headless_viewport_report = configure_headless_viewport(self.rig, headless=not args.gui)
            save_json(args.output / 'headless_viewport.json', self.headless_viewport_report)
        clock_step_samples = []
        self.world.add_physics_callback('context_clock_step_probe',
                                        lambda step_size: clock_step_samples.append(float(step_size)))
        try:
            for _ in range(480):
                self.world.step(render=False)
        finally:
            self.world.remove_physics_callback('context_clock_step_probe')
        clock_probe = validate_callback_step_samples(clock_step_samples, nominal_dt=DT)
        self.images = None
        for _ in range(60):
            self.world.render()
            if self.rig:
                try:
                    self.images = self.rig.capture(expected_time=float(self.world.current_time), require_new=False)
                    break
                except (RuntimeError, ValueError):
                    continue
            else:
                break
        if self.rig and self.images is None:
            raise RuntimeError('Three-camera warmup failed')
        if self.rig and args.suite:
            # A valid first buffer is not yet visually converged: the RTX
            # denoiser showed startup stipple in the first two wrist frames.
            # Render the static scene before defining t=0 or receiving language;
            # never discard/relabel frames from an already recorded episode.
            for _ in range(30):
                self.world.render()
            self.images = self.rig.capture(expected_time=float(self.world.current_time), require_new=False)
        self.camera_warmup = None
        if self.rig and args.suite:
            # Rendering 30 times alone does not establish fresh buffers or
            # converged images. Verify actual new synchronized captures before
            # defining t=0; no recorded frames are trimmed or retimestamped.
            warmup = CameraWarmupGuard()
            warmup_start_step = int(self.world.current_time_step_index)
            warmup_steps = []
            warmup_state_before = {key: value.tolist() for key, value in self.state().items()}
            warmup_target_before = self.target.tolist()
            warmup_error = None
            self.preview('render_prewarm_start')
            try:
                for index in range(REQUIRED_CAPTURES):
                    for _ in range(SUBSTEPS):
                        self.world.step(render=False)
                    step_index = int(self.world.current_time_step_index)
                    if step_index != warmup_start_step + (index + 1) * SUBSTEPS:
                        raise RuntimeError('Camera warmup physics-step schedule changed')
                    self.images = self.capture_synchronized_images()
                    warmup.observe(self.images, expected_engine_time=float(self.world.current_time))
                    warmup_steps.append(step_index)
                self.camera_warmup = warmup.finalize()
                self.preview('render_prewarm_final')
            except BaseException as error:
                warmup_error = f'{type(error).__name__}: {error}'
                raise
            finally:
                evidence = self.camera_warmup if self.camera_warmup is not None else warmup.report()
                evidence.update(physics_start_step=warmup_start_step,
                                physics_capture_steps=warmup_steps, substeps_per_capture=SUBSTEPS,
                                physical_state_before=warmup_state_before,
                                physical_state_after={key: value.tolist() for key, value in self.state().items()},
                                commanded_joint_target_before=warmup_target_before,
                                commanded_joint_target_after=self.target.tolist())
                if warmup_error is not None:
                    evidence.update(passed=False, status='caller_rejected', caller_error=warmup_error)
                save_json(args.output / 'camera_warmup.json', evidence)
        if self.rig and not args.suite:
            self.images = self.capture_synchronized_images()
        self.start_time = float(self.world.current_time)
        self.physics_clock = PhysicsClockGuard(nominal_dt=DT, substeps=SUBSTEPS, fps=FPS,
            start_step=self.world.current_time_step_index, start_time=self.start_time,
            callback_probe=clock_probe)
        self.check_asset_scales('after_warmup')
        self.reference_table_contact_contract = None
        if config.get('reference_start_pose'):
            from context_contact_contract import check_contact_matrix
            self.reference_table_contact_contract = check_contact_matrix(
                self.suite_collision_views['robot_table'].get_contact_force_matrix(dt=DT),
                actors=sum(len(paths) for paths in arm_paths.values()), filters=1,
                label='robot_table')
            save_json(args.output / 'reference_table_contact_contract.json', self.reference_table_contact_contract)
        self.compound_contact_contract = None
        if config.get('rectangular_bowl_workspace'):
            from context_contact_contract import check_contact_matrix
            expected_filters = len(config['support_paths'])
            proofs = {name: check_contact_matrix(view.get_contact_force_matrix(dt=DT),
                        actors=1, filters=expected_filters, label=name + '_support')
                      for name, view in self.supports.items()}
            view = self.suite_collision_views['robot_container']
            proofs['robot_container'] = check_contact_matrix(view.get_contact_force_matrix(dt=DT),
                actors=len(bodies), filters=expected_filters-1, label='robot_container')
            self.compound_contact_contract = {
                'schema': 'compound_container_contact_shape_v1',
                'surface_order': list(config['support_paths']),
                'filter_paths': list(config['support_paths'].values()),
                'matrices': proofs, 'scope': 'actor/filter dimensions, not standalone nonzero-contact proof'}
            save_json(args.output / 'compound_contact_contract.json', self.compound_contact_contract)
        initialized_scene = args.output / 'physics_initialized_scene.usdc'
        if not stage.Flatten().Export(str(initialized_scene)):
            raise RuntimeError('Could not save initialized composed USD scene')
        digest = hashlib.sha256()
        with initialized_scene.open('rb') as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                digest.update(block)
        self.scale_evidence['initialized_scene'] = {'path': initialized_scene.name, 'sha256': digest.hexdigest()}
        save_json(args.output / 'asset_scale_validation.json', self.scale_evidence)
        self.frame_index, self.turn, self.instruction = 0, 0, ''
        self.events, self.completed = [], []
        self.phase = 'ready'
        self.recent = {c: deque(maxlen=16) for c in COLORS}
        self.recent_forces = {s: deque(maxlen=16) for s in SIDES}
        self.active_color = None
        self.action_loss = True
        self.max_non_target_drift = {c: 0.0 for c in COLORS}
        self.initial = {c: obj.get_world_pose()[0].copy() for c, obj in self.objects.items()}
        self.stationary_reference = {c: p.copy() for c, p in self.initial.items()}
        self.camera_time_origin = {n: self.start_time for n in (self.images or {})}
        calibration = self.rig.calibration() if self.rig else {'status': 'no_images'}
        save_json(args.output / 'camera_calibration.json', calibration)
        self.recorder = Recorder(self.names, config, calibration)
        if self.recorder.streaming:
            contacts = ['contacts/left_finger_object', 'contacts/right_finger_object']
            contacts += ['contacts/' + key for key in self.suite_collision_views]
            contacts += [f'contacts/{name}_{"surfaces" if args.suite else "table"}' for name in COLORS]
            self.recorder.streaming.bind(self.recorder.demo, self.recorder.append_numeric,
                                        contact_keys=contacts)
        if self.render_sync_settings is not None:
            self.recorder.demo.attrs['render_sync_settings'] = json.dumps(self.render_sync_settings)
        self.recorder.demo.attrs['asset_scale_validation_schema'] = SCALE_SCHEMA
        self.recorder.demo.attrs['asset_scale_validation'] = json.dumps(self.scale_evidence)
        self.recorder.demo.attrs['initialized_scene_sha256'] = digest.hexdigest()
        if self.reference_table_contact_contract is not None:
            self.recorder.demo.attrs['reference_table_contact_contract'] = json.dumps(self.reference_table_contact_contract)
        if self.compound_contact_contract is not None:
            self.recorder.demo.attrs['compound_contact_contract'] = json.dumps(self.compound_contact_contract)
        self.recorder.demo.attrs['static_render_prewarm_count'] = 30 if self.rig and args.suite else 0
        self.recorder.demo.attrs['physics_start_time'] = self.start_time
        self.recorder.demo.attrs['physics_clock_contract'] = json.dumps(self.physics_clock.metadata())
        self.recorder.demo.attrs['physics_clock_callback_step_samples'] = json.dumps(clock_step_samples)
        self.recorder.demo.attrs['physics_clock_guard_applied'] = True
        if self.camera_warmup is not None:
            self.recorder.demo.attrs['camera_warmup'] = json.dumps(self.camera_warmup)
        g = self.recorder.demo.create_group('initial_state')
        for key, value in self.state().items():
            g.create_dataset(key, data=value)
        g.create_dataset('joint_target', data=self.target)
        self.preview('initial')
        print('[READY]', json.dumps({'tabletop': config['tabletop'], 'initial': {k: v.tolist() for k,v in self.initial.items()}}), flush=True)

    def check_asset_scales(self, label):
        try:
            capture_checkpoint(self.stage, self.scale_evidence, label)
        finally:
            save_json(args.output / 'asset_scale_validation.json', self.scale_evidence)

    def state(self):
        result = {'joint_position': self.robot.get_joint_positions().copy(),
                  'joint_velocity': self.robot.get_joint_velocities().copy()}
        for side in SIDES:
            p, q = self.tips[side].get_world_pose()
            result[side + '_tcp_pose'] = np.r_[p, q]
        for c, obj in self.objects.items():
            p, q = obj.get_world_pose()
            result[c + '_pose'] = np.r_[p, q]
            result[c + '_linear_velocity'] = obj.get_linear_velocity().copy()
        for key, value in result.items():
            if not np.isfinite(value).all():
                raise RuntimeError(f'Non-finite physical state: {key}')
        return result

    def event(self, kind, **kwargs):
        value = {'kind': kind, 'time': self.frame_index / FPS, 'first_effective_frame': self.frame_index,
                 'turn_id': self.turn, **kwargs}
        self.events.append(value)
        print('[EVENT]', json.dumps(value, ensure_ascii=False), flush=True)

    @_profile_section('capture.total')
    def capture_synchronized_images(self):
        from context_render_sync import capture_synced_frames, read_rig_camera_frames
        images, report = capture_synced_frames(
            render=lambda: _timed_call('capture.render_callback', self.world.render),
            read_camera_frames=lambda: _timed_call('capture.camera_sdk_callback', read_rig_camera_frames,
                                                  self.rig, copy_rgb=False),
            read_physics_state=lambda: _timed_call('capture.physics_state_callback', lambda: {
                'step_index': int(self.world.current_time_step_index),
                'engine_time': float(self.world.current_time),
                'state': self.state(), 'target': self.target.copy()}))
        self.image_sync_report = report
        return images

    def command(self, text):
        require_policy_english(text)
        self.turn += 1
        self.instruction = text
        self.event('instruction', text=text)

    def preview(self, label):
        if self.images:
            images = [self.images[n]['rgb'] for n in ['chest', 'left_wrist', 'right_wrist']]
            imageio.imwrite(args.output / f'{label}_three_views.png', np.concatenate(images, axis=1))

    @_profile_section('step.total')
    def step(self, target):
        if not app.is_running():
            raise RuntimeError('Simulation application closed')
        before = _timed_call('step.pre_state', self.state)
        if not np.isfinite(target).all():
            raise RuntimeError('Non-finite joint command')
        preaction_started = time.perf_counter()
        timestamp = self.frame_index / FPS
        engine_time = float(self.world.current_time)
        clock = self.physics_clock.check(self.frame_index, self.world.current_time_step_index, engine_time)
        r = self.recorder
        if r.streaming:
            r.streaming.begin_frame(self.frame_index, events=[event for event in self.events
                if event['first_effective_frame'] == self.frame_index])
        r.append('physics/step_index', np.int64(clock['engine_step_index']))
        r.append('physics/engine_time', np.float64(engine_time))
        r.append('physics/clock_residual_s', np.float64(clock['elapsed_clock_residual_s']))
        r.append('physics/nominal_quantization_drift_s', np.float64(clock['nominal_quantization_drift_s']))
        r.append('time', np.float64(timestamp))
        r.append('actions', np.asarray(target, dtype=np.float32))
        r.append('turn_id', np.int32(self.turn))
        r.append('instruction', self.instruction)
        r.append('phase', self.phase)
        r.append('action_loss_mask', np.float32(self.action_loss))
        for key, value in before.items():
            r.append('obs/' + key, np.asarray(value, dtype=np.float32))
        for name, frame in (self.images or {}).items():
            relative = float(frame['rendering_time']) - self.camera_time_origin[name]
            if abs(relative - timestamp) > 1e-4:
                raise RuntimeError(f'{name} image is stale/misaligned: {relative} vs {timestamp}')
            r.append(f'obs/{name}_rgb', frame['rgb'])
            r.append(f'obs/{name}_time', np.float64(relative))
            for field in ['rendering_time', 'rendering_frame', 'world_pose_wxyz']:
                r.append(f'camera/{name}/{field}', frame[field])
        if self.images:
            r.append('render_sync/evidence', json.dumps(self.image_sync_report))
        if r.streaming:
            _timed_call('step.preaction_seal', r.streaming.seal_preaction)
        _record_performance('step.preaction_numeric_and_seal', preaction_started)
        physics_started = time.perf_counter()
        self.target = np.asarray(target).copy()
        self.robot.apply_action(ArticulationAction(joint_positions=self.target))
        for _ in range(SUBSTEPS):
            self.world.step(render=False)
        _record_performance('step.apply_action_and_eight_physics_steps', physics_started)
        after = _timed_call('step.post_state', self.state)
        if self.rig:
            self.images = _timed_call('step.capture', self.capture_synchronized_images)
        else:
            _timed_call('step.diagnostic_render', self.world.render)
        postaction_started = time.perf_counter()
        for key, value in after.items():
            r.append('next_obs/' + key, np.asarray(value, dtype=np.float32))
        for side in SIDES:
            forces = self.fingers[side].get_contact_force_matrix(dt=DT).astype(np.float32)
            r.append(f'contacts/{side}_finger_object', forces)
            self.recent_forces[side].append(forces.copy())
        for label, view in self.suite_collision_views.items():
            forces = view.get_contact_force_matrix(dt=DT).astype(np.float32)
            if label == 'robot_table' and self.reference_table_contact_contract is not None:
                from context_contact_contract import check_contact_matrix
                proof = self.reference_table_contact_contract
                check_contact_matrix(forces, actors=proof['actor_count'], filters=1, label=label)
            if self.compound_contact_contract is not None and label == 'robot_container':
                from context_contact_contract import check_contact_matrix
                proof = self.compound_contact_contract['matrices'][label]
                check_contact_matrix(forces, actors=proof['actor_count'], filters=proof['filter_count'], label=label)
            r.append('contacts/' + label, forces)
            if not np.isfinite(forces).all() or float(np.linalg.norm(forces, axis=-1).max(initial=0)) > 0.1:
                raise RuntimeError(f'Forbidden physical collision: {label}')
        for c in COLORS:
            force = self.supports[c].get_contact_force_matrix(dt=DT)
            if self.compound_contact_contract is not None:
                from context_contact_contract import check_contact_matrix
                check_contact_matrix(force, actors=1, filters=len(self.config['support_paths']), label=c + '_support')
            support_label = 'surfaces' if args.suite else 'table'
            r.append(f'contacts/{c}_{support_label}', force.astype(np.float32))
            self.recent[c].append(after[c + '_pose'][:3].copy())
            if c != self.active_color:
                drift = float(np.linalg.norm(after[c + '_pose'][:3] - self.stationary_reference[c]))
                self.max_non_target_drift[c] = max(drift, self.max_non_target_drift[c])
                if drift > 0.02:
                    raise RuntimeError(f'Non-target object displaced during {self.phase}: {c}, {drift:.4f}m')
        if r.streaming:
            _timed_call('step.numeric_commit', r.streaming.commit_frame)
        _record_performance('step.postaction_numeric_contacts_and_commit', postaction_started)
        self.frame_index += 1
        r.count += 1
        if live_view is not None and self.frame_index % 10 == 0:
            live_view.update(self.frame_index, self.phase, self.instruction)

    def hold(self, seconds, phase):
        self.phase = phase
        for _ in range(max(1, round(seconds * FPS))):
            self.step(self.target)

    def move(self, side, goal, duration, orientation=None, phase='move'):
        self.phase = phase
        orientation = self.down if orientation is None else orientation
        ids, model = self.arm_ids[side], self.models[side]
        q0 = self.robot.get_joint_positions()[ids].copy()
        start_transform = model.forward(q0)
        start, start_R = start_transform[:3, 3], start_transform[:3, :3]
        rotation_delta = Rotation.from_matrix(orientation @ start_R.T).as_rotvec()
        seed = self.target[ids].copy()
        n = max(1, round(duration * FPS))
        for i in range(1, n + 1):
            u = i / n
            blend = u**3 * (10 - 15*u + 6*u*u)
            point = start + blend * (np.asarray(goal) - start)
            rotation = Rotation.from_rotvec(blend * rotation_delta).as_matrix() @ start_R
            seed = model.solve(point, rotation, seed)
            target = self.target.copy()
            target[ids] = seed
            self.step(target)
        self.hold(0.15, phase + '_settle')

    def gripper(self, side, opening, phase):
        self.phase = phase
        ids = self.finger_ids[side]
        start = self.target[ids].copy()
        for i in range(1, 19):
            target = self.target.copy()
            target[ids] = start + i / 18 * (opening - start)
            self.step(target)

    def cycle(self, color):
        cfg = self.config['parameters'][color]
        side, scale = cfg['side'], cfg['duration_scale']
        before_objects = {c: obj.get_world_pose()[0].copy() for c, obj in self.objects.items()}
        orientation = Rotation.from_euler('z', cfg['grasp_yaw']).as_matrix() @ self.down
        pick = before_objects[color] + np.r_[cfg['grasp_xy_offset'], 0.006]
        self.event('cycle_start', object=color, side=side)
        self.active_color = color
        self.gripper(side, 0.031, color + '_open')
        self.move(side, [0.30, self.config['home'][side][1], 0.37], 0.7*scale, orientation, color + '_transit')
        self.move(side, pick + [0, 0, 0.085], 1.0*scale, orientation, color + '_approach')
        self.move(side, pick, 1.1*scale, orientation, color + '_descend')
        self.gripper(side, 0, color + '_close')
        self.hold(0.35, color + '_grasp_settle')
        self.move(side, pick + [0, 0, cfg['lift_height']], 0.9*scale, orientation, color + '_lift')
        self.hold(cfg['lift_hold'], color + '_lift_hold')
        raised = np.asarray(self.recent[color])[:, 2] - before_objects[color][2]
        forces = np.linalg.norm(np.asarray(self.recent_forces[side])[-10:, :, COLORS.index(color), :], axis=-1)
        if len(raised) < 10 or len(forces) < 10 or float(raised[-10:].min()) < 0.03 or np.any(forces < 0.03):
            raise RuntimeError(f'Failed physical lift {color}: heights={raised.tolist()}, forces={forces.tolist()}')
        self.event('grasp_success', object=color, side=side, lift_m=float(raised[-1]),
                   verified_hold_s=9/FPS, minimum_finger_force_N=float(forces.min()))
        self.preview(color + '_lifted')
        obj_p, obj_q = self.objects[color].get_world_pose()
        tcp, _ = self.tips[side].get_world_pose()
        offset = tcp - obj_p
        half_height = 0.02350221 * np.abs(Rotation.from_quat(np.r_[obj_q[1:], obj_q[0]]).as_matrix()[2]).sum()
        target = np.r_[self.initial[color][:2] + offset[:2], self.config['tabletop'] + half_height + 0.001 + offset[2]]
        self.move(side, target, 1.0*scale, orientation, color + '_return')
        self.gripper(side, 0.031, color + '_release')
        self.hold(0.5, color + '_release_settle')
        self.move(side, target + [0, 0, 0.09], 0.9*scale, orientation, color + '_withdraw')
        self.move(side, self.config['home'][side], 0.9*scale, self.down, color + '_home')
        self.hold(0.6, color + '_stable')
        final = self.objects[color].get_world_pose()[0]
        drift = float(np.linalg.norm(final[:2] - self.initial[color][:2]))
        stable = float(np.ptp(np.asarray(self.recent[color]), axis=0).max())
        support = float(np.linalg.norm(self.supports[color].get_contact_force_matrix(dt=DT)))
        if drift > 0.02 or stable > 0.003 or support < 0.03 or abs(final[2]-self.initial[color][2]) > 0.012:
            raise RuntimeError(f'Failed release/return {color}: drift={drift}, stable={stable}, support={support}')
        for other in COLORS:
            if other != color and np.linalg.norm(self.objects[other].get_world_pose()[0] - before_objects[other]) > 0.02:
                raise RuntimeError(f'Non-target object moved: {other}')
        self.completed.append(color)
        self.active_color = None
        self.verify_waiting_pose()
        self.event('cycle_complete', object=color, side=side, return_error_m=drift, stable_range_m=stable, support_N=support)

    def verify_waiting_pose(self):
        state = self.state()
        for side in SIDES:
            error = float(np.linalg.norm(state[side + '_tcp_pose'][:3] - self.config['home'][side]))
            speed = float(np.max(np.abs(state['joint_velocity'][self.arm_ids[side]])))
            opening = state['joint_position'][self.finger_ids[side]]
            force = float(np.linalg.norm(self.fingers[side].get_contact_force_matrix(dt=DT)))
            if not np.isfinite(force) or error > 0.02 or speed > 0.15 or np.any(opening < 0.025) or force > 0.05:
                raise RuntimeError(f'{side} not waiting/released: tcp_error={error}, speed={speed}, opening={opening}, force={force}')

    def run(self):
        self.command(CTX12_INSTRUCTIONS['initial']['en'])
        self.hold(self.config['initial_wait'], 'initial_instruction')
        if args.probe:
            self.hold(0.5, 'probe')
            return {'success': False, 'probe_success': True, 'completed_order': []}
        self.cycle('red')
        self.event('modification_boundary')
        if args.variant == 'A':
            self.command(CTX12_INSTRUCTIONS['update']['en'])
        self.hold(self.config['boundary_wait'], 'modification_wait')
        self.command(CTX12_INSTRUCTIONS['query']['en'])
        self.hold(0.5, 'continue_instruction')
        for c in (['brown', 'blue'] if args.variant == 'A' else ['blue', 'brown']):
            self.cycle(c)
        self.hold(1.0, 'completed_hold')
        self.verify_waiting_pose()
        expected = ['red', 'brown', 'blue'] if args.variant == 'A' else ['red', 'blue', 'brown']
        result = {'success': self.completed == expected, 'task': args.task, 'variant': args.variant,
                  'completed_order': self.completed, 'expected_order': expected,
                  'frames': self.frame_index, 'duration_s': self.frame_index/FPS,
                  'camera_count': len(self.images or {}), 'status': 'pilot_uncalibrated',
                  'learned_policy': False, 'physical_grasp': True,
                  'max_non_target_drift_m': self.max_non_target_drift,
                  'validation_scope': 'object contact/lift/return, non-target displacement, waiting pose, synchronized cameras; not formal hardware calibration or exhaustive inter-arm collision certification',
                  'thresholds_are_pilot_candidates': True}
        self.event('task_success', completed_order=self.completed)
        self.preview('final')
        return result


episode = None
result = {'success': False, 'status': 'initialization_failed'}
try:
    if args.suite:
        from context_task_protocols import get_protocol
        from context_suite_scene import create_scene as create_suite_scene
        from context_suite_runtime import episode_class
        protocol = get_protocol(args.task, args.variant)
        config = create_suite_scene(sys.modules[__name__], protocol)
        COLORS = tuple(config['objects'])
        episode_type = episode_class(sys.modules[__name__])
    else:
        config = create_scene()
        episode_type = Episode
    omni.usd.get_context().open_stage(str(args.output / 'scene.usda'))
    for _ in range(3):
        app.update()
    if args.gui:
        from context_live_view import LiveCollectionView
        live_view = LiveCollectionView(args.task, args.variant, args.pair_id)
    episode = _timed_call('episode_initialization', episode_type,
                          omni.usd.get_context().get_stage(), config)
    result = _timed_call('task_execution', episode.run)
except Exception as exc:
    traceback.print_exc()
    result = {'success': False, 'status': 'failed', 'error': str(exc),
              'error_type': type(exc).__name__,
              'task': args.task, 'variant': args.variant}
    from context_motion_planning import MotionPlanningTimeout
    if isinstance(exc, MotionPlanningTimeout):
        result['failure_kind'] = 'planning_resource_timeout'
finally:
    finalization_started = time.perf_counter()
    finalization_failed = True
    try:
        if episode is not None:
            try:
                episode.check_asset_scales('episode_end')
            except Exception as exc:
                traceback.print_exc()
                result = {**result, 'success': False, 'status': 'asset_scale_failed', 'error': str(exc)}
            episode.recorder.demo.attrs['asset_scale_validation'] = json.dumps(episode.scale_evidence)
            _timed_call('finalization.numeric_recorder', episode.recorder.finish, result, episode.events)
            save_json(args.output / 'events.json', episode.events)
        save_json(args.output / 'result.json', result)
        if episode is not None and episode.recorder.streaming:
            try:
                _timed_call('finalization.video_storage', episode.recorder.streaming.finalize)
            except Exception as exc:
                traceback.print_exc()
                # Do not overwrite already hash-bound result artifacts. An explicit
                # incomplete/failure marker wins over physical success on readback.
                episode.recorder.streaming.abort(str(exc))
                result = {**result, 'success': False, 'status': 'recording_failed', 'error': str(exc)}
        print('[RESULT]', json.dumps(result, ensure_ascii=False), flush=True)
        finalization_failed = False
    finally:
        _record_performance('finalization.total', finalization_started, failed=finalization_failed)
        # This sidecar is not an acceptance artifact and changes no result,
        # numeric, video, clock, or source-evidence hashes. Write once, after
        # finalization; diagnostic I/O failure must not mask the original error.
        try:
            save_json(args.output / 'performance.json', {
                'schema': 'context_collector_wall_time_profile_v1',
                'task': args.task, 'variant': args.variant, 'pair_id': args.pair_id,
                'gui': args.gui, 'frames': getattr(episode, 'frame_index', 0),
                'wall_time_before_app_shutdown_s': time.perf_counter() - COLLECTOR_WALL_START,
                'thread_environment': {key: os.environ.get(key) for key in
                    ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')},
                'sections': PERFORMANCE_SECTIONS,
                'scope': 'Diagnostic wall time, not a quality certificate. Inclusive nested sections must not be summed together. capture.* includes initialization/warmup as well as recorded steps. Callback timings preserve every original callback and physics check. Manual completed-block samples omit partial failed blocks; wrapped calls include failures. App shutdown and external acceptance/export are excluded.',
            })
        except Exception as profile_error:
            print('[PERFORMANCE_WARNING]', str(profile_error), file=sys.stderr, flush=True)
        # Kit fast_shutdown can terminate inside close(), before Python reaches
        # SystemExit. Set Kit's own return code first, including finalization
        # exceptions. The parent ALSO checks result.json; exit0 is not success.
        exit_code = int(finalization_failed
                        or result.get('status') in ('failed','initialization_failed',
                                                   'asset_scale_failed','recording_failed')
                        or not (result.get('success') is True or result.get('probe_success') is True))
        omni.kit.app.get_app().post_quit(exit_code)
        app.close()
raise SystemExit(exit_code)
