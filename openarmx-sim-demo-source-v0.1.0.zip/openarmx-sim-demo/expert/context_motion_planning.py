"""Preflight and time-scale scripted joint targets without importing Isaac Sim.

The default caps are deliberately chosen *expert trajectory quality settings*,
not measured OpenArmX hardware limits. This checks commanded joint positions,
their discrete derivatives and IK validity. It does not certify collisions,
contact stability, actual tracking, or deployment on the real robot.
"""
import json
import math
import time
import numpy as np
from scipy.spatial.transform import Rotation


PLANNER_VERSION = 'context_cartesian_preflight_v4_typed_residual'


class MotionPlanningError(RuntimeError):
    """No complete admissible command sequence was found; execute nothing."""


class MotionPlanningTimeout(MotionPlanningError):
    """Resource budget exhausted, not evidence of a physical/IK tolerance failure."""


IK_POSITION_LIMIT_M = 0.006
IK_ROTATION_LIMIT_RAD = 0.08
UNREACHABLE_PREFLIGHT_PREFIX = 'IK residual preflight failed; no commands executed for this segment; evidence='


def _residual_evidence(target, position_error, rotation_error):
    target = np.asarray(target, dtype=float)
    if target.shape != (3,) or not np.isfinite(target).all():
        raise ValueError('Invalid IK residual target')
    for value in (position_error, rotation_error):
        if (isinstance(value, (bool, np.bool_)) or not np.isscalar(value)
                or not np.isfinite(value) or value < 0):
            raise ValueError('Invalid IK residual measurement')
    if position_error <= IK_POSITION_LIMIT_M and rotation_error <= IK_ROTATION_LIMIT_RAD:
        raise ValueError('IK residual failure must exceed unchanged solver limits')
    return {'target_m': target.tolist(), 'position_error_m': float(position_error),
            'rotation_error_rad': float(rotation_error),
            'position_limit_m': IK_POSITION_LIMIT_M, 'rotation_limit_rad': IK_ROTATION_LIMIT_RAD}


class IKResidualError(RuntimeError):
    """Only the finite residual guard in the IK solver may raise this type.

    A solver/configuration bug, invalid vector or nonfinite result is not a
    certified task-local unreachable target and must retain its original type.
    """
    def __init__(self, target, position_error, rotation_error):
        self.evidence = _residual_evidence(target, position_error, rotation_error)
        super().__init__(f'Unreachable TCP target {target}: position error={position_error:.4f} m, '
                         f'rotation={rotation_error:.3f} rad')


def _validated_unreachable_evidence(evidence):
    keys = {'schema', 'target_m', 'position_error_m', 'rotation_error_rad', 'position_limit_m',
            'rotation_limit_rad', 'failed_step', 'total_steps', 'failed_segment_commands_executed'}
    if not isinstance(evidence, dict) or set(evidence) != keys:
        raise ValueError('Invalid unreachable preflight evidence inventory')
    if (evidence['schema'] != 'context_ik_residual_preflight_v1'
            or evidence['failed_segment_commands_executed'] is not False
            or type(evidence['failed_step']) is not int or type(evidence['total_steps']) is not int
            or not 1 <= evidence['failed_step'] <= evidence['total_steps']):
        raise ValueError('Invalid unreachable preflight boundary evidence')
    if (type(evidence['position_limit_m']) is not float
            or type(evidence['rotation_limit_rad']) is not float
            or evidence['position_limit_m'] != IK_POSITION_LIMIT_M
            or evidence['rotation_limit_rad'] != IK_ROTATION_LIMIT_RAD):
        raise ValueError('Unreachable preflight solver limits changed')
    target = evidence['target_m']
    if (not isinstance(target, list) or len(target) != 3
            or any(type(x) not in (int, float) for x in target)
            or any(type(evidence[k]) not in (int, float)
                   for k in ('position_error_m', 'rotation_error_rad'))):
        raise ValueError('Invalid unreachable preflight numeric types')
    _residual_evidence(target, evidence['position_error_m'], evidence['rotation_error_rad'])
    return evidence


def unreachable_preflight_evidence(message):
    """Parse a canonical, typed failure sidecar without accepting old free text.

    The unchanged collector serializes exception type and message. This embeds
    full-precision evidence in that message, avoiding a collector/capture change.
    The runner must still audit immutable recording/source/scene bindings.
    """
    if not isinstance(message, str) or not message.startswith(UNREACHABLE_PREFLIGHT_PREFIX):
        raise ValueError('Missing typed unreachable preflight evidence')
    payload = message[len(UNREACHABLE_PREFLIGHT_PREFIX):]
    evidence = _validated_unreachable_evidence(json.loads(payload))
    if json.dumps(evidence, sort_keys=True, separators=(',', ':'), allow_nan=False) != payload:
        raise ValueError('Unreachable preflight evidence is not canonical')
    return evidence


class MotionPlanningUnreachable(MotionPlanningError):
    """Finite solver residual failure before committing this entire segment."""
    def __init__(self, residual, step, steps):
        if not isinstance(residual, IKResidualError):
            raise TypeError('Only a typed IK residual can become task-local preflight failure')
        evidence = _validated_unreachable_evidence({**residual.evidence,
            'schema': 'context_ik_residual_preflight_v1', 'failed_step': step, 'total_steps': steps,
            'failed_segment_commands_executed': False})
        super().__init__(UNREACHABLE_PREFLIGHT_PREFIX + json.dumps(
            evidence, sort_keys=True, separators=(',', ':'), allow_nan=False))


def _check_deadline(deadline, context, cpu_deadline=None):
    if time.monotonic() >= deadline:
        raise MotionPlanningTimeout(f'Planning wall-time budget exceeded {context}; no commands executed')
    if cpu_deadline is not None and time.thread_time() >= cpu_deadline:
        raise MotionPlanningTimeout(f'Planning thread-CPU budget exceeded {context}; no commands executed')


def _positive_scalar(value, name):
    if isinstance(value, (bool, np.bool_)) or not np.isscalar(value):
        raise ValueError(f'{name} must be a finite positive scalar')
    value = float(value)
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be a finite positive scalar')
    return value


def _caps(value, size, name):
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f'{name} must be positive numeric caps')
    caps = np.asarray(value, dtype=float)
    if caps.ndim == 0:
        caps = np.full(size, float(caps))
    if caps.shape != (size,) or not np.isfinite(caps).all() or np.any(caps <= 0):
        raise ValueError(f'{name} must be positive finite scalar or shape ({size},)')
    return caps


def _rotation(value, name):
    value = np.asarray(value, dtype=float)
    if value.shape != (3, 3) or not np.isfinite(value).all():
        raise ValueError(f'{name} must be a finite 3 x 3 rotation matrix')
    if not np.allclose(value.T @ value, np.eye(3), atol=1e-5) or not np.isclose(np.linalg.det(value), 1, atol=1e-5):
        raise ValueError(f'{name} must be a proper orthonormal rotation matrix')
    return value.copy()


def command_metrics(start_q, trajectory, fps):
    """Discrete command derivatives, assuming rest immediately before/after.

    Returned velocities include the first step from the *previous command*.
    Acceleration includes the first zero-to-step and last step-to-zero changes.
    The caller must hold the final target before starting an unrelated segment.
    """
    start_q = np.asarray(start_q, dtype=float)
    trajectory = np.asarray(trajectory, dtype=float)
    fps = _positive_scalar(fps, 'fps')
    if start_q.ndim != 1 or not len(start_q) or not np.isfinite(start_q).all():
        raise ValueError('start_q must be a nonempty finite vector')
    if trajectory.ndim != 2 or trajectory.shape[1] != len(start_q) or not len(trajectory) or not np.isfinite(trajectory).all():
        raise ValueError('trajectory must be a nonempty finite n x dof array')
    velocity = np.diff(np.vstack((start_q, trajectory)), axis=0) * fps
    padded = np.vstack((np.zeros_like(start_q), velocity, np.zeros_like(start_q)))
    acceleration = np.diff(padded, axis=0) * fps
    return {
        'peak_velocity_by_joint': np.max(np.abs(velocity), axis=0),
        'peak_acceleration_by_joint': np.max(np.abs(acceleration), axis=0),
        'peak_step_by_joint': np.max(np.abs(velocity), axis=0) / fps,
        'first_step': trajectory[0] - start_q,
        'last_step': trajectory[-1] - (trajectory[-2] if len(trajectory) > 1 else start_q),
    }


def plan_cartesian(model, start_q, goal, R, duration, fps=30,
                   velocity_cap=1.5, acceleration_cap=5.0, *,
                   max_retimes=6, max_duration=120.0,
                   position_tolerance=0.006, rotation_tolerance=0.08,
                   max_planning_seconds=180.0, max_planning_cpu_seconds=45.0):
    """Return ``(joint_targets, metadata)`` only after complete CPU preflight.

    ``start_q`` MUST be the previous commanded joint target, not a lagging
    measured position. ``model`` supplies ``forward(q) -> 4x4`` and
    ``solve(position, rotation, seed) -> q``. Optional ``lower``/``upper`` joint
    limits are enforced. The Cartesian position and orientation use the same
    quintic blend as the collector. IK is sequentially seeded from the prior
    solution, then the entire segment is regenerated at a longer duration when
    required. A branch jump that cannot be time-scaled within the bounded budget
    fails closed. No partially planned trajectory is returned.

    ``max_planning_seconds`` bounds wall-clock planning time across all retimes.
    ``max_planning_cpu_seconds`` additionally bounds the calling thread's CPU
    time. With single-thread BLAS in the frozen collector environment, this
    separates IK compute from time waiting for other collectors. Isaac's other
    renderer threads are deliberately not counted as planner CPU. Neither clock
    relaxes any pose, joint, derivative or collision quality threshold. Explicit
    tighter composite wall budgets supplied by callers are still respected.
    A synchronous ``model.solve`` call cannot be interrupted, so the deadline
    is checked both before and immediately after each call. A single slow solve
    may exceed the deadline, but its partial result will never be returned.

    Each returned row is one command at 1/fps seconds, with no duplicate starting
    row. On success, the final commanded target must be held for at least one
    frame (the collector normally holds longer). A following segment should
    receive this trajectory's final row as its ``start_q``.
    """
    planning_started = time.monotonic()
    planning_cpu_started = time.thread_time()
    max_planning_seconds = _positive_scalar(max_planning_seconds, 'max_planning_seconds')
    max_planning_cpu_seconds = _positive_scalar(max_planning_cpu_seconds, 'max_planning_cpu_seconds')
    deadline = planning_started + max_planning_seconds
    cpu_deadline = planning_cpu_started + max_planning_cpu_seconds
    start_q = np.asarray(start_q, dtype=float)
    goal = np.asarray(goal, dtype=float)
    if start_q.ndim != 1 or not len(start_q) or not np.isfinite(start_q).all():
        raise ValueError('start_q must be a nonempty finite vector')
    if goal.shape != (3,) or not np.isfinite(goal).all():
        raise ValueError('goal must be a finite xyz vector')
    start_q, goal = start_q.copy(), goal.copy()
    R = _rotation(R, 'R')
    duration = _positive_scalar(duration, 'duration')
    fps = _positive_scalar(fps, 'fps')
    max_duration = _positive_scalar(max_duration, 'max_duration')
    position_tolerance = _positive_scalar(position_tolerance, 'position_tolerance')
    rotation_tolerance = _positive_scalar(rotation_tolerance, 'rotation_tolerance')
    if not isinstance(max_retimes, (int, np.integer)) or isinstance(max_retimes, (bool, np.bool_)) or max_retimes < 0:
        raise ValueError('max_retimes must be a nonnegative integer')
    velocity_cap = _caps(velocity_cap, len(start_q), 'velocity_cap')
    acceleration_cap = _caps(acceleration_cap, len(start_q), 'acceleration_cap')
    if duration > max_duration:
        raise MotionPlanningError('Requested duration exceeds maximum planning duration')
    lower, upper = getattr(model, 'lower', None), getattr(model, 'upper', None)
    if (lower is None) != (upper is None):
        raise ValueError('Model must expose both lower and upper limits, or neither')
    if lower is not None:
        lower, upper = np.asarray(lower, dtype=float), np.asarray(upper, dtype=float)
        if lower.shape != start_q.shape or upper.shape != start_q.shape or np.isnan(lower).any() or np.isnan(upper).any() or np.any(lower >= upper):
            raise ValueError('Model joint limits are invalid')
        if np.any(start_q < lower - 1e-7) or np.any(start_q > upper + 1e-7):
            raise ValueError('Previous commanded target is outside model joint limits')
    transform = np.asarray(model.forward(start_q), dtype=float)
    if transform.shape != (4, 4) or not np.isfinite(transform).all():
        raise ValueError('model.forward must return a finite 4 x 4 transform')
    start, start_R = transform[:3, 3].copy(), _rotation(transform[:3, :3], 'start rotation')
    rotation_delta = Rotation.from_matrix(R @ start_R.T).as_rotvec()
    frames = max(2, math.ceil(duration * fps))
    attempts = []
    for attempt in range(int(max_retimes) + 1):
        _check_deadline(deadline, f'before retime attempt {attempt}', cpu_deadline)
        actual_duration = frames / fps
        if actual_duration > max_duration + 1e-12:
            raise MotionPlanningError(f'Time scaling exceeds {max_duration}s; last attempts={attempts[-2:]}')
        trajectory = np.empty((frames, len(start_q)), dtype=float)
        seed = start_q.copy()
        maximum_position_error, maximum_rotation_error = 0.0, 0.0
        for index in range(frames):
            context = f'at attempt {attempt}, step {index + 1}/{frames}'
            _check_deadline(deadline, context, cpu_deadline)
            u = (index + 1) / frames
            blend = u**3 * (10 - 15*u + 6*u*u)
            point = start + blend * (goal - start)
            rotation = Rotation.from_rotvec(blend * rotation_delta).as_matrix() @ start_R
            try:
                solved = np.asarray(model.solve(point, rotation, seed.copy()), dtype=float)
            except IKResidualError as exc:
                _check_deadline(deadline, context + ' after IK failure', cpu_deadline)
                raise MotionPlanningUnreachable(exc, index + 1, frames) from exc
            except Exception as exc:
                raise MotionPlanningError(f'IK preflight failed at step {index + 1}/{frames}; no commands executed: {exc}') from exc
            _check_deadline(deadline, context + ' after IK', cpu_deadline)
            if solved.shape != start_q.shape or not np.isfinite(solved).all():
                raise MotionPlanningError(f'IK returned invalid joint vector at step {index + 1}/{frames}')
            if lower is not None and (np.any(solved < lower - 1e-7) or np.any(solved > upper + 1e-7)):
                raise MotionPlanningError(f'IK violated model joint limits at step {index + 1}/{frames}')
            actual = np.asarray(model.forward(solved), dtype=float)
            if actual.shape != (4, 4) or not np.isfinite(actual).all():
                raise MotionPlanningError(f'FK returned invalid solved pose at step {index + 1}/{frames}')
            actual_R = _rotation(actual[:3, :3], 'solved rotation')
            position_error = float(np.linalg.norm(actual[:3, 3] - point))
            rotation_error = float(np.linalg.norm(Rotation.from_matrix(rotation @ actual_R.T).as_rotvec()))
            if position_error > position_tolerance + 1e-8 or rotation_error > rotation_tolerance + 1e-8:
                raise MotionPlanningError(f'IK pose residual exceeds tolerance at step {index + 1}/{frames}: position={position_error}, rotation={rotation_error}')
            maximum_position_error = max(maximum_position_error, position_error)
            maximum_rotation_error = max(maximum_rotation_error, rotation_error)
            trajectory[index], seed = solved, solved.copy()
        metrics = command_metrics(start_q, trajectory, fps)
        _check_deadline(deadline, f'after retime attempt {attempt}', cpu_deadline)
        velocity_ratio = float(np.max(metrics['peak_velocity_by_joint'] / velocity_cap))
        acceleration_ratio = float(np.max(metrics['peak_acceleration_by_joint'] / acceleration_cap))
        attempts.append({'frames': frames, 'duration_s': actual_duration,
                         'velocity_ratio': velocity_ratio, 'acceleration_ratio': acceleration_ratio})
        if velocity_ratio <= 1 + 1e-8 and acceleration_ratio <= 1 + 1e-8:
            metadata = {
                'planner_version': PLANNER_VERSION, 'status': 'kinematic_preflight_passed',
                'planning_wall_seconds': time.monotonic() - planning_started,
                'planning_thread_cpu_seconds': time.thread_time() - planning_cpu_started,
                'max_planning_seconds': max_planning_seconds,
                'max_planning_thread_cpu_seconds': max_planning_cpu_seconds,
                'planning_deadline_semantics': 'finite wall and caller-thread CPU budgets checked around each non-preemptible IK call and retime',
                'requested_duration_s': duration, 'duration_s': actual_duration,
                'fps': fps, 'frames': frames, 'retime_count': attempt,
                'maximum_ik_position_error_m': maximum_position_error,
                'maximum_ik_rotation_error_rad': maximum_rotation_error,
                'ik_position_tolerance_m': position_tolerance,
                'ik_rotation_tolerance_rad': rotation_tolerance,
                'velocity_cap_by_joint': velocity_cap.tolist(),
                'acceleration_cap_by_joint': acceleration_cap.tolist(),
                **{key: value.tolist() for key, value in metrics.items()},
                'retime_attempts': attempts,
                'caps_semantics': 'chosen scripted-expert quality caps; not hardware-calibrated limits',
                'start_semantics': 'previous commanded joint target',
                'acceleration_boundary_semantics': 'zero commanded velocity immediately before and after segment',
                'required_final_hold_frames_min': 1,
                'collision_and_contact_validated': False,
                'actual_tracking_validated': False,
            }
            return trajectory, metadata
        # Cartesian sampling and IK are recomputed after time scaling. Merely
        # slowing down playback without adding samples would alter dataset fps.
        stretch = max(velocity_ratio, math.sqrt(acceleration_ratio), 1.01) * 1.05
        frames = max(frames + 1, math.ceil(frames * stretch))
    raise MotionPlanningError(f'Command derivative caps not met after {max_retimes} retimes; attempts={attempts}')


def plan_sequence(model, start_q, segments, *, max_planning_seconds=180.0,
                  max_planning_cpu_seconds=45.0, **planner_options):
    """Preflight all segments before execution, preserving command continuity.

    ``segments`` is a nonempty sequence of dictionaries containing ``goal``,
    ``R`` and ``duration``; optional ``label`` is audit-only. Return a list of
    trajectories and a matching list of metadata. Hold each segment's last
    command before executing the next, per ``plan_cartesian``'s contract.
    The wall-clock budget is shared by the entire sequence, not reset per
    segment. Individual synchronous IK calls remain non-preemptible.
    """
    planning_started = time.monotonic()
    planning_cpu_started = time.thread_time()
    max_planning_seconds = _positive_scalar(max_planning_seconds, 'max_planning_seconds')
    max_planning_cpu_seconds = _positive_scalar(max_planning_cpu_seconds, 'max_planning_cpu_seconds')
    deadline = planning_started + max_planning_seconds
    cpu_deadline = planning_cpu_started + max_planning_cpu_seconds
    segments = list(segments)
    if not segments:
        raise ValueError('segments must not be empty')
    trajectories, metadata = [], []
    previous = np.asarray(start_q, dtype=float).copy()
    for index, segment in enumerate(segments):
        if not isinstance(segment, dict) or not {'goal', 'R', 'duration'} <= segment.keys():
            raise ValueError(f'Segment {index} must contain goal, R and duration')
        try:
            _check_deadline(deadline, f'before sequence segment {index}', cpu_deadline)
            remaining_seconds = deadline - time.monotonic()
            remaining_cpu_seconds = cpu_deadline - time.thread_time()
            if remaining_seconds <= 0:
                raise MotionPlanningTimeout('Planning wall-time budget exceeded before sequence segment; no commands executed')
            if remaining_cpu_seconds <= 0:
                raise MotionPlanningTimeout('Planning thread-CPU budget exceeded before sequence segment; no commands executed')
            trajectory, info = plan_cartesian(model, previous, segment['goal'], segment['R'],
                                               segment['duration'], max_planning_seconds=remaining_seconds,
                                               max_planning_cpu_seconds=remaining_cpu_seconds,
                                               **planner_options)
            _check_deadline(deadline, f'after sequence segment {index}', cpu_deadline)
        except MotionPlanningTimeout as exc:
            # Keep the typed retryable resource failure distinct from invalid
            # IK/physics. The error text remains a strict allowlisted shape.
            raise MotionPlanningTimeout(str(exc).replace(' exceeded ',
                f' exceeded in sequence segment {index} ({segment.get("label", "unnamed")}), ',1)) from exc
        except MotionPlanningUnreachable:
            # The entire sequence is still preflight-only. Preserve the typed
            # residual evidence for the failed segment instead of broadening it
            # to an unknown planner exception or changing its canonical text.
            raise
        except MotionPlanningError as exc:
            raise MotionPlanningError(f'Sequence segment {index} ({segment.get("label", "unnamed")}) failed: {exc}') from exc
        info['segment_index'], info['label'] = index, str(segment.get('label', index))
        trajectories.append(trajectory)
        metadata.append(info)
        previous = trajectory[-1].copy()
    planning_elapsed = time.monotonic() - planning_started
    for info in metadata:
        info['sequence_planning_wall_seconds'] = planning_elapsed
        info['sequence_max_planning_seconds'] = max_planning_seconds
        info['sequence_planning_thread_cpu_seconds'] = time.thread_time() - planning_cpu_started
        info['sequence_max_planning_thread_cpu_seconds'] = max_planning_cpu_seconds
    return trajectories, metadata
