"""Candidate reference-pose verification and recorded empty-hand preparation.

This adapter never initializes or teleports a robot/object. The caller owns the
pre-warmup initialization and keeps the real-reference start separate from the
existing operational waiting pose. Preparation belongs AFTER the first existing
common setup instruction, inside recording; it creates no language instruction
and no protocol operation. Call only with SuiteEpisode's dedicated bounded
joint-space move_reference_to_waiting/step implementation; there is no Cartesian
fallback to the old preparation path that exceeded its planning budget.

Thresholds below are provisional simulation engineering checks, NOT calibrated
hardware limits. Passing this adapter is not task, pixel, or training acceptance.
"""
from __future__ import annotations

import hashlib
import json
import numbers

import numpy as np

from context_instructions import require_policy_english


SCHEMA = 'context_reference_start_candidate_v1'
SIDES = ('left', 'right')
PHYSICS_DT = 1.0 / 240.0
LIMITS = {
    'arm_max_position_error_rad': 0.03,
    'finger_max_position_error_m': 0.003,
    'arm_max_speed_rad_s_exclusive': 0.15,
    'finger_max_speed_m_s_exclusive': 0.15,
    'finger_object_force_norm_N_exclusive': 0.05,
}


class ReferenceStartError(RuntimeError):
    pass


def _require(condition, message):
    if not condition:
        raise ReferenceStartError(message)


def _vector(value, size, label):
    result = np.asarray(value)
    _require(result.shape == (size,) and result.dtype.kind == 'f'
             and np.isfinite(result).all(), label + ' must be a finite floating-point vector of length ' + str(size))
    return result.copy()


def _frame(episode):
    value = episode.frame_index
    _require(isinstance(value, numbers.Integral) and not isinstance(value, (bool, np.bool_))
             and value >= 0, 'Invalid recorded frame_index')
    return int(value)


def _inventory(episode):
    names = list(episode.names)
    expected_names = [f'openarmx_{side}_joint{i}' for side in SIDES for i in range(1, 8)]
    expected_names += [f'openarmx_{side}_finger_joint{i}' for side in SIDES for i in (1, 2)]
    _require(len(names) == 18 and all(isinstance(name, str) for name in names)
             and len(set(names)) == 18 and set(names) == set(expected_names),
             'Episode must expose exactly the 14 arm and 4 finger joint names')
    reference = episode.config.get('reference_start_pose')
    _require(isinstance(reference, dict), 'Missing reference_start_pose configuration')
    values = reference.get('joint_positions_by_name')
    _require(isinstance(values, dict) and set(values) == set(names),
             'Reference joint_positions_by_name must contain all and only the 18 episode joints')
    _require(all(isinstance(v, numbers.Real) and not isinstance(v, (bool, np.bool_))
                 and np.isfinite(v) for v in values.values()), 'Reference joint positions must be finite real numbers')
    expected = np.asarray([values[name] for name in names], dtype=np.float64)
    indices = {}
    for side in SIDES:
        arm = [names.index(f'openarmx_{side}_joint{i}') for i in range(1, 8)]
        fingers = [names.index(f'openarmx_{side}_finger_joint{i}') for i in (1, 2)]
        _require(np.array_equal(np.asarray(episode.arm_ids[side]), arm), side + ' arm index mapping differs from named order')
        _require(set(np.asarray(episode.finger_ids[side]).tolist()) == set(fingers), side + ' finger index mapping differs from named joints')
        indices[side] = (arm, fingers)
    return names, expected, indices


def verify_reference_initial(episode):
    """Read actual state/contacts and verify the complete named reference start.

    Closed fingers and arbitrary valid wrist orientation are allowed; the old
    operational home/open-gripper test is deliberately not used here. This
    check does not replace native self-collision checks or Episode.step gates.
    """
    names, expected, indices = _inventory(episode)
    _require(getattr(episode, 'held', None) is None, 'Reference preparation requires empty hands')
    state = episode.state()
    q = _vector(state['joint_position'], 18, 'Actual joint positions')
    velocity = _vector(state['joint_velocity'], 18, 'Actual joint velocities')
    target = _vector(episode.target, 18, 'Current joint target')
    _require(np.array_equal(target, expected.astype(target.dtype)),
             'Current command is not the configured reference target; refusing to mislabel a moved start')
    side_metrics = {}
    for side, (arm, fingers) in indices.items():
        arm_error = float(np.max(np.abs(q[arm] - expected[arm])))
        finger_error = float(np.max(np.abs(q[fingers] - expected[fingers])))
        arm_speed = float(np.max(np.abs(velocity[arm])))
        finger_speed = float(np.max(np.abs(velocity[fingers])))
        force = np.asarray(episode.fingers[side].get_contact_force_matrix(dt=PHYSICS_DT))
        _require(force.ndim == 3 and force.shape[0] == 2 and force.shape[1] >= 1
                 and force.shape[2] == 3 and force.dtype.kind in 'fiu' and np.isfinite(force).all(),
                 side + ' finger/object contact matrix is missing or invalid')
        force_norm = float(np.linalg.norm(force))
        _require(arm_error <= LIMITS['arm_max_position_error_rad'], side + ' arm reference position error exceeds candidate limit')
        _require(finger_error <= LIMITS['finger_max_position_error_m'], side + ' finger reference position error exceeds candidate limit')
        _require(arm_speed < LIMITS['arm_max_speed_rad_s_exclusive'], side + ' arm reference velocity is not settled')
        _require(finger_speed < LIMITS['finger_max_speed_m_s_exclusive'], side + ' finger reference velocity is not settled')
        _require(force_norm < LIMITS['finger_object_force_norm_N_exclusive'], side + ' reference fingers contact an object')
        side_metrics[side] = {'arm_max_position_error_rad': arm_error,
            'finger_max_position_error_m': finger_error, 'arm_max_speed_rad_s': arm_speed,
            'finger_max_speed_m_s': finger_speed, 'finger_object_force_norm_N': force_norm}
    canonical = {name: float(expected[names.index(name)]) for name in sorted(names)}
    digest = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    try:
        # Preserve the loader's source JSON/model hashes, ordering/units
        # assumptions and explicit uncalibrated status without upgrading them.
        provenance = json.loads(json.dumps(episode.config['reference_start_pose'], allow_nan=False))
    except (TypeError, ValueError) as error:
        raise ReferenceStartError('Reference provenance must be finite JSON-serializable metadata') from error
    return {'schema': SCHEMA, 'reference_initial_verified': True, 'frame_index': _frame(episode),
        'reference_configuration': provenance,
        'joint_names': names, 'reference_joint_positions': expected.tolist(),
        'preaction_joint_position': q.tolist(), 'preaction_joint_velocity': velocity.tolist(),
        'preaction_joint_target': target.tolist(), 'reference_target_sha256': digest,
        'joint_units': ['m' if '_finger_joint' in name else 'rad' for name in names],
        'side_metrics': side_metrics, 'limits': dict(LIMITS), 'contact_sampling_dt_s': PHYSICS_DT,
        'limits_are_simulation_candidates_not_hardware': True,
        'pair_invariance_intended': True, 'pair_invariance_independently_verified': False,
        'pair_invariance_rule': 'Use the identical named reference target/config for A and B; compare reference_target_sha256 across episodes.',
        'native_collision_certified': False, 'task_success_certified': False,
        'hardware_deployment_allowed': False, 'training_ready': False}


def prepare_operational_waiting(episode):
    """Record left-then-right guarded motion after an EXISTING English setup.

    No new command, turn, operation result, joint-state setter, object setter,
    teleport, or masking of collision/tracking exceptions is introduced.
    action_loss is restored even if the existing motion implementation fails.
    """
    try:
        require_policy_english(episode.instruction)
    except ValueError as error:
        raise ReferenceStartError('An existing English setup instruction is required before preparation') from error
    _require(not getattr(episode, '_reference_start_preparation_complete', False),
             'Reference preparation has already completed')
    _require(isinstance(episode.action_loss, (bool, np.bool_)), 'action_loss must be Boolean')
    prepare_move = getattr(episode, 'move_reference_to_waiting', None)
    _require(callable(prepare_move),
             'Guarded move_reference_to_waiting is required; Cartesian fallback is not allowed')
    verification = verify_reference_initial(episode)
    homes = {side: _vector(np.asarray(episode.config['home'][side], dtype=float), 3, side + ' operational home') for side in SIDES}
    rotation = np.asarray(episode.down)
    _require(rotation.shape == (3, 3) and rotation.dtype.kind == 'f' and np.isfinite(rotation).all()
             and np.allclose(rotation.T @ rotation, np.eye(3), rtol=0, atol=1e-8)
             and abs(np.linalg.det(rotation)-1) < 1e-8, 'Invalid operational waiting orientation')
    begin = _frame(episode)
    old_action_loss = episode.action_loss
    instruction_before = episode.instruction
    turn_before = episode.turn
    operations_before = len(getattr(episode, 'operation_results', []))
    report = {'schema': SCHEMA, 'status': 'started', 'begin_frame': begin,
        'reference_initial': verification, 'side_order': list(SIDES),
        'operational_waiting_positions': {side: goal.tolist() for side, goal in homes.items()},
        'operational_waiting_rotation': rotation.tolist(), 'nominal_move_duration_s_per_arm': 3.0,
        'motion_method': 'SuiteEpisode.move_reference_to_waiting',
        'motion_space': 'bounded quintic joint-space preparation',
        'motion_details_evidence': 'Per-arm motion_preflight and motion_tracking events from the existing guarded executor',
        'empty_finger_target_m': .044, 'action_loss_during_preparation': False,
        'new_language_commands': 0, 'new_protocol_operations': 0,
        'scope': 'Recorded empty-hand setup transition, not task history or a task-success certificate',
        'uses_existing_guarded_motion': True, 'pose_setters_used': False,
        'limits_are_simulation_candidates_not_hardware': True, 'training_ready': False}
    try:
        episode.action_loss = False
        episode.phase = 'reference_start_preparation'
        episode.event('reference_start_preparation', **report)
        for side in SIDES:
            prepare_move(side, homes[side].copy(), rotation.copy())
            episode.gripper(side, .044, side + '_prepare_open')
        episode.verify_waiting_pose()
        _require(episode.instruction == instruction_before and episode.turn == turn_before,
                 'Preparation unexpectedly changed the language instruction/turn')
        _require(len(getattr(episode, 'operation_results', [])) == operations_before,
                 'Preparation unexpectedly created protocol operations')
        _require(_frame(episode) > begin, 'Preparation did not record any control frames')
        report.update(status='completed', end_frame=_frame(episode),
            recorded_frames=_frame(episode)-begin,
            final_joint_position=_vector(episode.state()['joint_position'],18,'Final joint positions').tolist(),
            final_joint_target=_vector(episode.target,18,'Final joint target').tolist())
        episode.phase = 'reference_start_operational_waiting'
        episode.event('reference_start_preparation', **report)
        episode._reference_start_preparation_complete = True
        return report
    except Exception as error:
        report.update(status='failed', end_frame=_frame(episode), error_type=type(error).__name__, error=str(error))
        episode.event('reference_start_preparation', **report)
        raise
    finally:
        episode.action_loss = old_action_loss
