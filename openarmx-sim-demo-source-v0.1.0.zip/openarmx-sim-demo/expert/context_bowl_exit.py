"""CPU-only carried-block bowl exits shared by preflight and execution.

The default segments reproduce the bounded N/F, left/right candidates in
release_and_loaded_bowl_exit_audit_20261015.json. They are NOT physical-success,
force-closure, robot collision, or continuous swept-volume certificates. The
caller must preflight the returned segments, execute those SAME segments, and
keep actual contact, tracking and measured-clearance guards enabled. Never
replace the level outward segment with a descending diagonal.
"""
import numpy as np
from scipy.spatial.transform import Rotation
from context_container_geometry import validate_geometry, whole_object_outside_footprint

EXIT_VERSION = 'context_block_bowl_exit_v1'


class BowlExitError(RuntimeError):
    """Geometry guard failed: do not execute an unverified bowl exit."""


def _number(value, name, *, positive=False):
    if isinstance(value, (bool, np.bool_, str, bytes)) or not np.isscalar(value):
        raise ValueError(f'{name} must be a finite numeric scalar')
    result = float(value)
    if not np.isfinite(result) or (positive and result <= 0):
        raise ValueError(f'{name} must be finite' + (' and positive' if positive else ''))
    return result


def _point(value, name):
    result = np.asarray(value, dtype=float)
    if result.shape != (3,) or not np.isfinite(result).all():
        raise ValueError(f'{name} must be a finite xyz vector')
    return result.copy()


def _rotation(value, name):
    result = np.asarray(value, dtype=float)
    if (result.shape != (3, 3) or not np.isfinite(result).all()
            or not np.allclose(result.T @ result, np.eye(3), atol=1e-6, rtol=0)
            or not np.isclose(np.linalg.det(result), 1, atol=1e-6, rtol=0)):
        raise ValueError(f'{name} must be a finite proper rotation matrix')
    return result.copy()


def _vertices(value, name):
    result = np.asarray(value, dtype=float)
    if (result.ndim != 2 or result.shape[1] != 3 or len(result) < 4
            or not np.isfinite(result).all()
            or np.linalg.matrix_rank(result - result.mean(axis=0)) != 3):
        raise ValueError(f'{name} must contain finite vertices spanning a volume')
    return result.copy()


def _bowl(value):
    if isinstance(value, dict) and 'footprint_schema' in value:
        spec = validate_geometry(value)
        return spec['center'], spec['rim'], None
    if isinstance(value, dict) and any(key in value for key in ('shape', 'inner_half_extents', 'outer_half_extents')):
        raise ValueError('Nonlegacy container geometry requires an explicit footprint schema')
    if not isinstance(value, dict) or not {'center', 'rim_z', 'outer_radius'} <= value.keys():
        raise ValueError('bowl_geometry needs center, rim_z and outer_radius')
    center = np.asarray(value['center'], dtype=float)
    if center.shape not in ((2,), (3,)) or not np.isfinite(center).all():
        raise ValueError('bowl center must be finite xy or xyz')
    return (center[:2].copy(), _number(value['rim_z'], 'rim_z'),
            _number(value['outer_radius'], 'outer_radius', positive=True))


def _clearance(value):
    value = _number(value, 'minimum_clearance', positive=True)
    if value < .005:
        raise ValueError('minimum_clearance cannot relax the 5 mm rim guard')
    return value


def _outside_xy(vertices, center, radius, margin):
    # Minimum distance from bowl center to the complete object's XY AABB.
    # AABB-circle separation is conservative; vertex-only radius tests are not.
    closest = np.clip(center, vertices[:, :2].min(0), vertices[:, :2].max(0))
    return float(np.linalg.norm(closest - center)) > radius + margin


def _outside_bowl(vertices, bowl_geometry, margin):
    if 'footprint_schema' in bowl_geometry:
        return whole_object_outside_footprint(vertices, bowl_geometry, margin=margin)['outside']
    center, _, radius = _bowl(bowl_geometry)
    return _outside_xy(vertices, center, radius, margin)


def build_bowl_exit_segments(side, lift_point, rotation, *, extra_raise=.010,
                             bridge=None, neutral=None):
    """Return a JSON-serializable plan; neither solve IK nor move anything.

    ``lift_point`` is the previously COMMANDED lift endpoint, not a measured
    lagging TCP substituted for it. Default extra_raise is 10 mm. Use ``kind``
    to dispatch cartesian segments to plan_cartesian/move and reorientation to
    plan_joint_reorientation/reorient. Retain the N no-op realignment to match
    the four reported regression paths exactly. Share the returned plan between
    preflight and execution, and re-preflight if any parameter changes.
    """
    if side not in ('left', 'right'):
        raise ValueError('side must be left or right')
    sign = 1 if side == 'left' else -1
    lift = _point(lift_point, 'lift_point')
    rotation = _rotation(rotation, 'rotation')
    extra = _number(extra_raise, 'extra_raise', positive=True)
    if extra > .030:
        raise ValueError('extra_raise exceeds the bounded 30 mm candidate limit')
    bridge = _point([.30, sign * .15, .38] if bridge is None else bridge, 'bridge')
    neutral = _point([.29, sign * .19, .42] if neutral is None else neutral, 'neutral')
    if bridge[1] * sign < .12 or neutral[1] * sign < .12:
        raise ValueError('bridge and neutral must be in the ipsilateral exterior corridor')
    high = lift + [0, 0, extra]
    if high[2] <= bridge[2]:
        raise BowlExitError('High exit must be above the exterior low bridge')
    out = np.r_[bridge[:2], high[2]]
    clear_rotation = Rotation.from_euler('xyz', [np.pi, -.65, 0]).as_matrix()
    specifications = [
        ('extra_clearance', 'cartesian', high, rotation, .7, None),
        ('horizontal_exit', 'cartesian', out, rotation, 1.2, 'measured_rim_clearance'),
        ('lower_outside_bowl', 'cartesian', bridge, rotation, .8, 'measured_xy_outside'),
        ('held_realign', 'joint_reorientation', bridge, clear_rotation, 1.5, 'measured_xy_outside'),
        ('held_neutral', 'cartesian', neutral, clear_rotation, 1.1, None),
    ]
    segments = []
    for label, kind, goal, rot, duration, guard in specifications:
        segment = dict(label=label, kind=kind, goal=goal.tolist(), R=rot.tolist(),
                       duration=duration, required_guard_before=guard)
        if kind == 'joint_reorientation':
            segment['corridor_min'] = [.24, .12 if sign > 0 else -.23, .34]
            segment['corridor_max'] = [.36, .23 if sign > 0 else -.12, .43]
        segments.append(segment)
    return {
        'version': EXIT_VERSION, 'side': side, 'lift_point': lift.tolist(),
        'rotation': rotation.tolist(), 'extra_raise_m': extra, 'segments': segments,
        'metadata': {'physical_success_validated': False, 'full_fk_collision_validated': False,
                     'measured_grasp_required': True, 'minimum_rim_clearance_m': .005,
                     'source': 'release_and_loaded_bowl_exit_audit_20261015.json'},
    }


def held_vertices_in_tcp(native_world_vertices, actual_tcp_position, actual_tcp_rotation):
    """Measured native vertices -> measured TCP frame; no USD pose assumption.

    Obtain native boundingCube world vertices using the existing read-only
    context_push_geometry.load_bounding_cube_world_vertices, with actual object
    pose and recorded applied scale, not a stale physics-time USD transform.
    """
    vertices = _vertices(native_world_vertices, 'native_world_vertices')
    point = _point(actual_tcp_position, 'actual_tcp_position')
    rotation = _rotation(actual_tcp_rotation, 'actual_tcp_rotation')
    return (vertices - point) @ rotation


def required_extra_raise(native_world_vertices, actual_tcp_position, actual_tcp_rotation,
                         commanded_lift_point, commanded_rotation, bowl_geometry, *,
                         minimum_clearance=.005, tracking_margin=.002):
    """Conservative raise suggestion, not an automatic plan modification.

    Consider both measured and predicted-at-command object bottoms, preserving
    actual held geometry. Rebuild and fully preflight if this exceeds the old
    plan's extra_raise. Tracking margin is 1--2 mm, not a tolerance relaxation.
    """
    minimum = _clearance(minimum_clearance)
    margin = _number(tracking_margin, 'tracking_margin', positive=True)
    if not .001 <= margin <= .002:
        raise ValueError('tracking_margin must lie in [0.001, 0.002] m')
    _, rim, _ = _bowl(bowl_geometry)
    vertices = _vertices(native_world_vertices, 'native_world_vertices')
    local = held_vertices_in_tcp(vertices, actual_tcp_position, actual_tcp_rotation)
    predicted = local @ _rotation(commanded_rotation, 'commanded_rotation').T + _point(commanded_lift_point, 'commanded_lift_point')
    measured_bottom, predicted_bottom = float(vertices[:, 2].min()), float(predicted[:, 2].min())
    delta = max(0., rim + minimum - min(measured_bottom, predicted_bottom)) + margin
    return {'required_extra_raise_m': delta, 'measured_bottom_m': measured_bottom,
            'predicted_command_bottom_m': predicted_bottom, 'rim_z_m': rim,
            'minimum_clearance_m': minimum, 'tracking_margin_m': margin,
            'does_not_modify_plan': True}


def check_rim_crossing(vertices_tcp, tcp_transforms, bowl_geometry, *,
                       minimum_clearance=.005, xy_margin=.002):
    """Fail closed on sampled FK/measured poses while horizontally over a bowl.

    Use only for the high outward crossing, not the legitimate initial vertical
    extraction. Input must include the crossing start and all command FK samples
    (and/or measured samples). No interpolation or continuous-motion guarantee
    is supplied. The fixed-held transform must be remeasured if slipping occurs.
    """
    vertices = _vertices(vertices_tcp, 'vertices_tcp')
    transforms = np.asarray(tcp_transforms, dtype=float)
    if transforms.ndim != 3 or transforms.shape[1:] != (4, 4) or not len(transforms) or not np.isfinite(transforms).all():
        raise ValueError('tcp_transforms must be a nonempty finite N x 4 x 4 array')
    _, rim, _ = _bowl(bowl_geometry)
    minimum = _clearance(minimum_clearance)
    margin = _number(xy_margin, 'xy_margin')
    if margin < 0:
        raise ValueError('xy_margin must be nonnegative')
    gaps, crossing_gaps = [], []
    for index, transform in enumerate(transforms):
        if not np.allclose(transform[3], [0, 0, 0, 1], atol=1e-8, rtol=0):
            raise ValueError('tcp_transforms must be rigid homogeneous transforms')
        rotation = _rotation(transform[:3, :3], 'tcp rotation')
        world = vertices @ rotation.T + transform[:3, 3]
        gap = float(world[:, 2].min() - rim)
        gaps.append(gap)
        if not _outside_bowl(world, bowl_geometry, margin):
            crossing_gaps.append(gap)
            if gap < minimum - 1e-9:
                raise BowlExitError(f'Native held object lacks rim clearance at sample {index}: {gap:.6f} < {minimum:.6f} m')
    return {'sample_count': len(transforms), 'over_bowl_sample_count': len(crossing_gaps),
            'minimum_sample_bottom_minus_rim_m': min(gaps),
            'minimum_over_bowl_bottom_minus_rim_m': min(crossing_gaps) if crossing_gaps else None,
            'required_clearance_m': minimum, 'continuous_sweep_validated': False,
            'actual_grasp_retention_validated': False}


def check_measured_bowl_exit(plan, native_world_vertices, actual_tcp_position,
                             actual_tcp_rotation, bowl_geometry, *,
                             minimum_clearance=.005, tracking_margin=.002,
                             xy_margin=.002):
    """Validate the unchanged plan against measured held native geometry.

    Checks ideal high-crossing endpoints and exterior-lowering/realignment
    endpoints. Call check_rim_crossing again with planned FK crossing samples;
    actual pre-horizontal and pre-lowering guards are mandatory. This function
    deliberately rejects tampered/mismatched segments rather than silently
    rebuilding execution waypoints after preflight.
    """
    if not isinstance(plan, dict) or plan.get('version') != EXIT_VERSION:
        raise ValueError('Expected a plan from build_bowl_exit_segments')
    try:
        segments = plan['segments']
        expected = build_bowl_exit_segments(plan['side'], plan['lift_point'], plan['rotation'],
            extra_raise=plan['extra_raise_m'], bridge=segments[2]['goal'], neutral=segments[4]['goal'])
        if segments != expected['segments']:
            raise ValueError('Plan segments were changed after construction/preflight')
    except (KeyError, IndexError, TypeError) as error:
        raise ValueError('Malformed bowl exit plan') from error
    minimum = _clearance(minimum_clearance)
    margin = _number(xy_margin, 'xy_margin')
    if margin < 0:
        raise ValueError('xy_margin must be nonnegative')
    required = required_extra_raise(native_world_vertices, actual_tcp_position, actual_tcp_rotation,
        plan['lift_point'], plan['rotation'], bowl_geometry,
        minimum_clearance=minimum, tracking_margin=tracking_margin)
    if plan['extra_raise_m'] + 1e-9 < required['required_extra_raise_m']:
        raise BowlExitError('Planned extra raise insufficient; rebuild and fully re-preflight before moving')
    local = held_vertices_in_tcp(native_world_vertices, actual_tcp_position, actual_tcp_rotation)
    transforms = []
    for segment in segments[:2]:
        transform = np.eye(4)
        transform[:3, :3] = segment['R']
        transform[:3, 3] = segment['goal']
        transforms.append(transform)
    clearance = check_rim_crossing(local, transforms, bowl_geometry,
                                   minimum_clearance=minimum, xy_margin=margin)
    _bowl(bowl_geometry)
    # A clear TCP alone is insufficient: require the whole native object's
    # conservative XY AABB outside before the lower/reorient endpoints.
    for segment in segments[1:]:
        world = local @ np.asarray(segment['R']).T + segment['goal']
        if not _outside_bowl(world, bowl_geometry, margin):
            raise BowlExitError(f'Whole held object not exterior at {segment["label"]}; cannot lower/reorient')
    return {'vertices_tcp': local.tolist(), 'raise_check': required,
            'ideal_crossing_check': clearance, 'exterior_waypoints_pass': True,
            'full_fk_path_still_required': True, 'physical_success_validated': False,
            'required_actual_guards': ['valid grasp/contact', 'rim clearance before horizontal exit',
                                       'whole native object XY exterior before lowering']}
