"""Pure CPU stable-face return planning for a block regrasped from a bowl.

No simulation imports, object attachments, pose writes, or force changes.
Candidates preserve initial yaw while choosing 0/-90/+90 degree local-Y faces.
Returned paths are predictions based on one measured grasp; actual hold,
collision, release, final position and stability still require physical checks.
"""
import time

import numpy as np
from scipy.spatial.transform import Rotation

from context_joint_motion import plan_joint_reorientation
from context_motion_planning import MotionPlanningError, plan_cartesian

DOWN = Rotation.from_euler('xyz', [np.pi, 0, 0]).as_matrix()


class StableReturnError(RuntimeError):
    pass


def _vector(value, size, name):
    value = np.asarray(value, dtype=float)
    if value.shape != (size,) or not np.isfinite(value).all():
        raise ValueError(name+' must be a finite vector of length '+str(size))
    return value.copy()


def _rotation(value, name):
    value = np.asarray(value, dtype=float)
    if (value.shape != (3, 3) or not np.isfinite(value).all()
            or not np.allclose(value.T@value, np.eye(3), atol=1e-6)
            or not np.isclose(np.linalg.det(value), 1., atol=1e-6)):
        raise ValueError(name+' must be a proper rotation')
    return value.copy()


def _pose(value, name):
    value = _vector(value, 7, name)
    if abs(np.linalg.norm(value[3:])-1.) > .001:
        raise ValueError(name+' quaternion must be normalized wxyz')
    return value[:3], Rotation.from_quat(np.r_[value[4:],value[3]]).as_matrix()


def measured_grasp(actual_tcp_pose, actual_object_pose, native_vertices_local):
    tcp, tcp_rotation = _pose(actual_tcp_pose, 'actual_tcp_pose')
    obj, obj_rotation = _pose(actual_object_pose, 'actual_object_pose')
    vertices = np.asarray(native_vertices_local, dtype=float)
    if (vertices.ndim != 2 or vertices.shape[1] != 3 or len(vertices) < 4
            or not np.isfinite(vertices).all()):
        raise ValueError('Expected finite native local Nx3 block vertices')
    return dict(object_rotation_in_tcp=tcp_rotation.T@obj_rotation,
        object_origin_in_tcp=tcp_rotation.T@(obj-tcp),
        vertices_in_tcp=(vertices@obj_rotation.T+obj-tcp)@tcp_rotation,
        actual_object_rotation=obj_rotation,
        native_vertices_local=vertices.copy())


def stable_face_candidates(grasp, initial_yaw):
    if not np.isfinite(initial_yaw):
        raise ValueError('Initial yaw must be finite')
    initial = Rotation.from_euler('z', float(initial_yaw)).as_matrix()
    relative = _rotation(grasp['object_rotation_in_tcp'], 'object_rotation_in_tcp')
    actual = _rotation(grasp['actual_object_rotation'], 'actual_object_rotation')
    candidates = []
    for degrees in (0, -90, 90):
        desired_obj = initial@Rotation.from_euler('y', degrees, degrees=True).as_matrix()
        desired_ee = desired_obj@relative.T
        candidates.append(dict(face_y_degrees=degrees, object_rotation=desired_obj,
            ee_rotation=desired_ee,
            angular_change_rad=float(Rotation.from_matrix(desired_obj@actual.T).magnitude())))
    return sorted(candidates, key=lambda item:item['angular_change_rad'])


def landing_geometry(grasp, target_xy, rotation, *, tabletop=.30,
                     release_clearance=.002, withdraw_clearance=.025):
    """Recompute from freshly measured grasp after transfer when integrating.

    This returns goals, not commands or object transforms. The integration must
    preflight any changed lower/withdraw goals before execution; do not reuse a
    stale predicted lower target after observed grasp slip.
    """
    target_xy = _vector(target_xy, 2, 'target_xy')
    rotation = _rotation(rotation, 'rotation')
    values = np.asarray([tabletop, release_clearance, withdraw_clearance], dtype=float)
    if (not np.isfinite(values).all() or release_clearance < 0
            or withdraw_clearance <= 0):
        raise ValueError('Invalid table/clearance values')
    offset = rotation@_vector(grasp['object_origin_in_tcp'], 3, 'object_origin_in_tcp')
    vertices = np.asarray(grasp['vertices_in_tcp'], dtype=float)@rotation.T
    low = np.r_[target_xy-offset[:2], tabletop+release_clearance-vertices[:, 2].min()]
    return dict(lower=low, withdraw=low+[0, 0, withdraw_clearance],
                predicted_native_bottom_m=float((vertices+low)[:, 2].min()),
                target_xy=target_xy)


def build_segments(side, current_rotation, candidate_rotation, grasp, target_xy,
                   *, tabletop=.30, withdraw_clearance=.025):
    if side not in ('left', 'right'):
        raise ValueError('side must be left or right')
    sign = 1 if side == 'left' else -1
    current_rotation = _rotation(current_rotation, 'current_rotation')
    candidate_rotation = _rotation(candidate_rotation, 'candidate_rotation')
    bridge = np.array([.30, sign*.20, tabletop+.08])
    # Empty reorientation at the old .38m bridge dipped below the unchanged
    # .34m corridor after a far-bowl regrasp. Only the empty bridge is raised;
    # loaded transit, landing, face choice and corridor bounds stay unchanged.
    empty_bridge = np.array([.30, sign*.20, tabletop+.10])
    home = np.array([.30, sign*.20, tabletop+.14])
    transit = np.r_[_vector(target_xy, 2, 'target_xy'), tabletop+.08]
    geometry = landing_geometry(grasp, target_xy, candidate_rotation,
                                tabletop=tabletop, withdraw_clearance=withdraw_clearance)
    def segment(label, goal, rotation, duration, kind='cartesian', loaded=True):
        return dict(label=label, goal=np.asarray(goal), R=np.asarray(rotation),
                    duration=duration, kind=kind, loaded=loaded)
    return [
        segment('loaded_bridge', bridge, current_rotation, .8),
        segment('loaded_realign', bridge, candidate_rotation, 1.5, 'joint_reorientation'),
        segment('table_transfer', transit, candidate_rotation, 1.3),
        segment('table_lower', geometry['lower'], candidate_rotation, 1.),
        segment('empty_withdraw', geometry['withdraw'], candidate_rotation, .8, loaded=False),
        segment('empty_home_bridge', empty_bridge, candidate_rotation, .8, loaded=False),
        segment('empty_home_realign', empty_bridge, DOWN, 1.5, 'joint_reorientation', loaded=False),
        segment('home', home, DOWN, .9, loaded=False),
    ]


def plan_stable_block_return(model, start_q, actual_tcp_pose, actual_object_pose,
                            native_vertices_local, target_xy, initial_yaw, side,
                            *, object_kind='block', source_kind='bowl',
                            tabletop=.30, fps=30, velocity_cap=1.5,
                            acceleration_cap=5., max_planning_seconds=45.):
    """Return one fully preflighted plan; failed candidates execute nothing.

    Preconditions deliberately restrict use to a bowl-regrasped block returning
    to its ipsilateral tabletop. Only rotation symmetry is used; target XY is
    unchanged. Native robot/bowl contact is NOT checked by this pure helper.
    """
    started = time.monotonic()
    if object_kind != 'block' or source_kind != 'bowl':
        raise ValueError('Stable-face return supports only a block from a bowl')
    if side not in ('left','right'):
        raise ValueError('Invalid side')
    target_xy = _vector(target_xy,2,'target_xy')
    sign = 1 if side == 'left' else -1
    if sign*target_xy[1] < .12:
        raise ValueError('Stable-face return requires an ipsilateral side-table target')
    if not np.isfinite(max_planning_seconds) or max_planning_seconds <= 0:
        raise ValueError('Positive planning budget required')
    start_q = np.asarray(start_q, dtype=float)
    if start_q.ndim != 1 or not np.isfinite(start_q).all():
        raise ValueError('Finite continuous commanded start joints required')
    grasp = measured_grasp(actual_tcp_pose, actual_object_pose, native_vertices_local)
    current_rotation = model.forward(start_q)[:3, :3]
    candidates = stable_face_candidates(grasp, initial_yaw)
    failures = []
    for candidate in candidates:
        segments = build_segments(side, current_rotation, candidate['ee_rotation'],
                                  grasp, target_xy, tabletop=tabletop)
        previous = start_q.copy()
        planned = []
        minimum_loaded_z = float('inf')
        try:
            for segment in segments:
                budget = max_planning_seconds-(time.monotonic()-started)
                if budget <= 0:
                    raise StableReturnError('Complete stable-return planning wall budget exceeded')
                options = dict(fps=fps, velocity_cap=velocity_cap,
                    acceleration_cap=acceleration_cap, max_planning_seconds=budget)
                if segment['kind'] == 'joint_reorientation':
                    trajectory, meta = plan_joint_reorientation(model, previous,
                        segment['goal'], segment['R'], segment['duration'],
                        corridor_min=[.24,.12 if sign>0 else -.23,tabletop+.04],
                        corridor_max=[.36,.23 if sign>0 else -.12,tabletop+.13],
                        **options)
                else:
                    trajectory, meta = plan_cartesian(model, previous,
                        segment['goal'], segment['R'], segment['duration'], **options)
                if segment['loaded']:
                    for joints in trajectory:
                        transform = model.forward(joints)
                        world = grasp['vertices_in_tcp']@transform[:3,:3].T+transform[:3,3]
                        bottom = float(world[:,2].min())
                        minimum_loaded_z = min(minimum_loaded_z,bottom)
                        limit = tabletop if segment['label']=='table_lower' else tabletop+.005
                        if bottom < limit-1e-8:
                            raise StableReturnError('Predicted held native block violates table clearance')
                previous = trajectory[-1]
                planned.append({**segment,'trajectory':trajectory,'metadata':meta})
            return dict(segments=planned, metadata=dict(
                kind='stable_bowl_block_side_table_return_v1',
                face_y_degrees=candidate['face_y_degrees'],
                candidate_angular_change_rad=candidate['angular_change_rad'],
                desired_object_rotation=candidate['object_rotation'].tolist(),
                desired_ee_rotation=candidate['ee_rotation'].tolist(),
                object_rotation_in_tcp=grasp['object_rotation_in_tcp'].tolist(),
                object_origin_in_tcp=grasp['object_origin_in_tcp'].tolist(),
                target_xy=target_xy.tolist(), native_vertices=len(native_vertices_local),
                source_kind=source_kind, object_kind=object_kind,
                actual_tcp_pose=np.asarray(actual_tcp_pose).tolist(),
                actual_object_pose=np.asarray(actual_object_pose).tolist(),
                release_after_label='table_lower', minimum_loaded_native_z_m=minimum_loaded_z,
                failed_candidates=failures, planning_wall_s=time.monotonic()-started,
                frames=sum(len(s['trajectory']) for s in planned), fps=fps,
                collision_scope='No robot-scene collision proof in this helper; physical guards remain mandatory.',
                limitation='Measured-grasp rigid prediction only. Refresh landing_geometry from actual grasp after transfer; preflight changed tail before release/withdraw. No physical success inferred.'))
        except (RuntimeError, ValueError) as exc:
            failures.append(dict(face_y_degrees=candidate['face_y_degrees'],
                                 phase=segment['label'], reason=str(exc)))
    raise StableReturnError('No full stable return candidate: '+str(failures))
