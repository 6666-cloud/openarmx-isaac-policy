"""CPU-only engineering barrier for fresh metadata at a frozen physics state.

No RGB access, PNG I/O, sleeps, simulator imports, or rig._last changes. Caller-
supplied callbacks must themselves be read-only except render(). Successful
metadata is NOT proof that rendered pixels depict current geometry. The caller
still performs its final rig.capture(require_new=True), checks the returned
metadata, and independently validates image quality. Callbacks are synchronous:
the deadline is checked between calls, not by interrupting a hung renderer.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import numbers
import time

import numpy as np


SCHEMA = "context_fixed_physics_render_barrier_candidate_v1"
CAMERAS = ("chest", "left_wrist", "right_wrist")


def _integer(value, label, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Integral) or value < minimum:
        raise ValueError(label + " must be an integer >= " + str(minimum))
    return int(value)


def _real(value, label):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Real) or not math.isfinite(float(value)):
        raise ValueError(label + " must be a finite real scalar")
    return float(value)


@dataclass(frozen=True)
class RenderBarrierLimits:
    required_new_captures: int = 3
    max_render_calls: int = 24
    max_wall_time_s: float = 5.0
    expected_time_tolerance_s: float = 1e-5
    synchronization_tolerance_s: float = 1e-6

    def __post_init__(self):
        for name in ("required_new_captures", "max_render_calls"):
            object.__setattr__(self, name, _integer(getattr(self, name), name, minimum=1))
        for name in ("max_wall_time_s", "expected_time_tolerance_s", "synchronization_tolerance_s"):
            object.__setattr__(self, name, _real(getattr(self, name), name))
        if not 3 <= self.required_new_captures <= self.max_render_calls <= 24:
            raise ValueError("Require >=3 completed captures within <=24 render calls; no adaptive lowering")
        if not 0 < self.max_wall_time_s <= 5:
            raise ValueError("Wall-time limit must be positive and <=5 seconds")
        if not 0 < self.expected_time_tolerance_s <= 1e-5:
            raise ValueError("Expected camera time tolerance must be positive and <=1e-5 seconds")
        if not 0 < self.synchronization_tolerance_s <= 1e-6:
            raise ValueError("Cross-camera tolerance must be positive and <=1e-6 seconds")


class RenderBarrierError(RuntimeError):
    def __init__(self, message, report):
        super().__init__(message)
        self.report = report


def _numeric_array(value, label, shape=None):
    array = np.asarray(value)
    if array.dtype.kind not in "fiu" or not np.isfinite(array).all():
        raise ValueError(label + " must contain finite numeric state")
    if shape is not None and array.shape != shape:
        raise ValueError(label + " must have shape " + str(shape))
    return array.copy()


def _physics(value):
    if not isinstance(value, dict) or set(value) != {"step_index", "engine_time", "state", "target"}:
        raise ValueError("Physics snapshot requires exactly step_index, engine_time, state, target")
    step = _integer(value["step_index"], "physics step_index")
    seconds = _real(value["engine_time"], "physics engine_time")
    if seconds < 0:
        raise ValueError("Physics engine_time must be nonnegative")
    state = value["state"]
    if not isinstance(state, dict) or not all(isinstance(key, str) for key in state):
        raise ValueError("Physics state must be a string-keyed array dictionary")
    shapes = {"joint_position": (18,), "joint_velocity": (18,),
              "left_tcp_pose": (7,), "right_tcp_pose": (7,)}
    if not set(shapes).issubset(state):
        raise ValueError("Physics state is missing joints/velocities or either TCP pose")
    objects = [key[:-5] for key in state if key.endswith("_pose") and key not in ("left_tcp_pose", "right_tcp_pose")]
    if not objects:
        raise ValueError("Physics state must include at least one object pose and its velocity")
    for name in objects:
        shapes[name + "_pose"] = (7,)
        shapes[name + "_linear_velocity"] = (3,)
    if not set(shapes).issubset(state):
        raise ValueError("Object pose is missing its corresponding linear velocity")
    return {"step_index": step, "engine_time": seconds,
            "state": {key: _numeric_array(array, "state/" + key, shapes.get(key)) for key, array in state.items()},
            "target": _numeric_array(value["target"], "target", (18,))}


def _physics_equal(baseline, observed):
    if observed["step_index"] != baseline["step_index"]:
        raise ValueError("Physics step_index changed during render barrier")
    if observed["engine_time"] != baseline["engine_time"]:
        raise ValueError("Physics engine_time changed during render barrier")
    if set(observed["state"]) != set(baseline["state"]):
        raise ValueError("Physics state inventory changed during render barrier")
    pairs = [("target", baseline["target"], observed["target"])]
    pairs += [("state/"+key, array, observed["state"][key]) for key, array in baseline["state"].items()]
    for label, before, after in pairs:
        if before.dtype != after.dtype or before.shape != after.shape or not np.array_equal(before, after):
            raise ValueError(label + " changed during render barrier (no physical tolerance applied)")


def _cameras(value):
    if not isinstance(value, dict) or set(value) != set(CAMERAS):
        raise ValueError("Camera metadata must contain exactly chest, left_wrist, right_wrist")
    result = {}
    for name in CAMERAS:
        row = value[name]
        if not isinstance(row, dict) or set(row) != {"rendering_frame", "rendering_time"}:
            raise ValueError(name + " requires only rendering_frame/rendering_time metadata, not RGB")
        frame = _integer(row["rendering_frame"], name + " rendering_frame")
        seconds = _real(row["rendering_time"], name + " rendering_time")
        if seconds < 0:
            raise ValueError(name + " rendering_time must be nonnegative")
        result[name] = {"rendering_frame": frame, "rendering_time": seconds}
    return result


def _plain_snapshot(snapshot):
    return {"step_index": snapshot["step_index"], "engine_time": snapshot["engine_time"],
            "state": {key: array.tolist() for key, array in snapshot["state"].items()},
            "state_dtypes": {key: str(array.dtype) for key, array in snapshot["state"].items()},
            "target": snapshot["target"].tolist(), "target_dtype": str(snapshot["target"].dtype)}


def wait_for_render_barrier(*, render, read_cameras_metadata, read_physics_state,
                            monotonic=time.monotonic, limits=None):
    """Wait for >=3 synchronized NEW metadata groups without advancing physics.

    Physics reader schema: {step_index, engine_time, state: episode.state(),
    target: episode.target}. Camera reader returns just the two scalar rendering
    fields for each canonical camera, without calling rig.capture or changing
    its freshness history. Strict physics invariance is checked after every
    render, metadata-read and clock callback. Pending stale/duplicate/asynchronous
    groups never count, and no limit or camera tolerance is relaxed on failure.
    """
    limits = limits if limits is not None else RenderBarrierLimits()
    if not isinstance(limits, RenderBarrierLimits):
        raise ValueError("limits must be RenderBarrierLimits")
    if not all(callable(fn) for fn in (render, read_cameras_metadata, read_physics_state, monotonic)):
        raise ValueError("All barrier callbacks must be callable")
    report = {"schema": SCHEMA, "status": "running", "new_capture_count": 0,
              "render_calls": 0, "limits": asdict(limits),
              "limits_source": "explicit caller limits bounded by fixed candidate hard maxima; no adaptive relaxation",
              "scope": "metadata engineering barrier at a strictly frozen physics snapshot",
              "pixel_geometry_certified": False, "image_quality_certified": False,
              "training_ready": False, "updates_rig_capture_history": False,
              "reads_or_writes_rgb": False, "callbacks_are_preempted": False,
              "physical_state_unchanged": False, "physics_invariance_checks": 0,
              "calls": [], "final_camera_metadata": None}
    current_record = None
    try:
        baseline = _physics(read_physics_state())
        report["baseline_physics"] = _plain_snapshot(baseline)
        def verify_physics():
            state = _physics(read_physics_state())
            _physics_equal(baseline, state)
            report["physics_invariance_checks"] += 1
            return state
        # Detect readers that mutate their own exposed arrays or state, too.
        verify_physics()
        first_clock = _real(monotonic(), "monotonic clock")
        verify_physics()
        last_clock = first_clock
        report["elapsed_wall_time_s"] = 0.0
        def clock_check():
            nonlocal last_clock
            stamp = _real(monotonic(), "monotonic clock")
            verify_physics()
            if stamp < last_clock:
                raise ValueError("Monotonic wall clock moved backwards")
            last_clock = stamp
            elapsed = stamp-first_clock
            report["elapsed_wall_time_s"] = elapsed
            if elapsed >= limits.max_wall_time_s:
                raise ValueError("Render barrier wall-time deadline reached")
            return elapsed
        initial = _cameras(read_cameras_metadata())
        verify_physics()
        report["initial_metadata"] = initial
        report["initial_metadata_read_index"] = 0
        metadata_read_index = 0
        physics_time = baseline["engine_time"]
        for name, row in initial.items():
            if row["rendering_time"]-physics_time > limits.expected_time_tolerance_s:
                raise ValueError(name + " baseline camera time is in the future")
        previous_observed = initial
        previous_counted = initial
        while report["new_capture_count"] < limits.required_new_captures:
            elapsed = clock_check()
            if report["render_calls"] >= limits.max_render_calls:
                raise ValueError("Render barrier maximum render-call count reached")
            report["render_calls"] += 1
            current_record = {"render_call_index": report["render_calls"], "elapsed_before_s": elapsed,
                              "physics_step_index": baseline["step_index"], "physics_engine_time": physics_time,
                              "counted_new_capture": False, "status": "render_started"}
            report["calls"].append(current_record)
            render()
            verify_physics()
            current_record["status"] = "render_returned_physics_unchanged"
            # Reject deadline overruns even when a late buffer looks usable.
            clock_check()
            metadata_read_index += 1
            current_record["metadata_read_index"] = metadata_read_index
            camera = _cameras(read_cameras_metadata())
            verify_physics()
            current_record["camera_metadata"] = camera
            current_record["elapsed_after_s"] = clock_check()
            for name, row in camera.items():
                if row["rendering_time"]-physics_time > limits.expected_time_tolerance_s:
                    raise ValueError(name + " camera time is in the future")
                if row["rendering_time"] < previous_observed[name]["rendering_time"]:
                    raise ValueError(name + " camera time moved backwards")
                if row["rendering_frame"] < previous_observed[name]["rendering_frame"]:
                    raise ValueError(name + " camera frame ID moved backwards")
            previous_observed = camera
            frames = [camera[name]["rendering_frame"] for name in CAMERAS]
            times = [camera[name]["rendering_time"] for name in CAMERAS]
            reasons = []
            if len(set(frames)) != 1:
                reasons.append("camera_frame_ids_not_synchronized")
            if max(times)-min(times) > limits.synchronization_tolerance_s:
                reasons.append("camera_times_not_synchronized")
            if any(abs(stamp-physics_time) > limits.expected_time_tolerance_s for stamp in times):
                reasons.append("camera_time_stale")
            if any(camera[name]["rendering_frame"] <= previous_counted[name]["rendering_frame"] for name in CAMERAS):
                reasons.append("not_new_since_previous_counted_capture")
            if reasons:
                current_record.update(status="pending", pending_reasons=reasons,
                                      new_capture_count=report["new_capture_count"])
                continue
            report["new_capture_count"] += 1
            previous_counted = camera
            current_record.update(status="counted", pending_reasons=[], counted_new_capture=True,
                                  new_capture_count=report["new_capture_count"])
            report["final_camera_metadata"] = camera
        verify_physics()
        report.update(status="completed", physical_state_unchanged=True)
        return report
    except Exception as error:
        if current_record is not None and current_record["status"] not in ("counted", "pending"):
            current_record["status"] = "failed"
        report.update(status="failed", error_type=type(error).__name__, error=str(error))
        raise RenderBarrierError("Fixed-physics render barrier failed: " + str(error), report) from error
