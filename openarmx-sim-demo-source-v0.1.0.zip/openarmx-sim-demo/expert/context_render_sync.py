"""CPU-import-safe zero-delay/FXAA adapter and actual RGB-buffer barrier.

Integration: merge ``simulation_app_overrides(existing_extra_args)`` into the
SimulationApp config BEFORE launch; call ``configure_render_sync_after_reset``
AFTER World.reset (and again after any subsequent reset). After each action's
physics substeps, call ``capture_synced_frames`` with world.render, a frozen
physics snapshot reader and ``lambda: read_rig_camera_frames(rig)``. Record only
the returned final frames. Intermediate reads do NOT call rig.capture or change
rig._last. Do not render again between this return and recording the observation.

This reuses the bounded metadata barrier, but obtains and validates actual copied
RGB/poses on every read. Three counted captures means three distinct synchronized
render-frame groups at one unchanged physics state, not three render calls. It
is NOT a general pixel/geometry correspondence or training-quality certificate.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
import time

import numpy as np

import context_render_barrier as _barrier_module
from context_render_barrier import CAMERAS, RenderBarrierError, RenderBarrierLimits, wait_for_render_barrier


SCHEMA = 'context_render_sync_v1'
ZERO_DELAY_ARGS = (
    '--/app/hydraEngine/waitIdle=true',
    '--/app/updateOrder/checkForHydraRenderComplete=1000',
)
EXPECTED_SETTINGS = {
    '/rtx/post/aa/op': 2,
    '/rtx-defaults/post/aa/op': 2,
    '/rtx-transient/post/aa/limitedOps': False,
    '/app/hydraEngine/waitIdle': True,
    '/app/updateOrder/checkForHydraRenderComplete': 1000,
}


def simulation_app_overrides(extra_args=()):
    """Return AA2/zero-delay overrides without mutating the caller's arguments.

    Conflicting render-related CLI overrides are rejected rather than relying
    on undocumented last-argument precedence. Existing nonrender flags survive.
    """
    if not isinstance(extra_args, (list, tuple)) or not all(isinstance(x, str) and x for x in extra_args):
        raise ValueError('extra_args must be a list/tuple of nonempty strings')
    result = list(extra_args)
    protected = {flag.split('=', 1)[0]: flag for flag in ZERO_DELAY_ARGS}
    protected.update({
        '--/rtx/post/aa/op': '--/rtx/post/aa/op=2',
        '--/rtx-defaults/post/aa/op': '--/rtx-defaults/post/aa/op=2',
        '--/rtx-transient/post/aa/limitedOps': '--/rtx-transient/post/aa/limitedOps=false',
    })
    for arg in result:
        key = arg.split('=', 1)[0]
        if key in protected and arg != protected[key]:
            raise ValueError('Conflicting or split render startup argument: ' + key)
    for flag in ZERO_DELAY_ARGS:
        if flag not in result:
            result.append(flag)
    return {'anti_aliasing': 2, 'extra_args': result}


def _settings_reader():
    # Import ONLY when an initialized Isaac caller asks for actual SDK settings.
    import carb.settings
    return carb.settings.get_settings().get


def verify_render_sync_settings(settings_reader=None):
    """Fail if live settings drift; do not retune/recover during an observation."""
    reader = _settings_reader() if settings_reader is None else settings_reader
    if not callable(reader):
        raise ValueError('settings_reader must be a callable(path)')
    values = {key: reader(key) for key in EXPECTED_SETTINGS}
    for key, expected in EXPECTED_SETTINGS.items():
        value = values[key]
        if type(value) is not type(expected) or value != expected:
            raise ValueError(f'Render setting mismatch at {key}: expected {expected!r}, got {value!r}')
    return values


def configure_render_sync_after_reset(*, settings_reader=None, set_render_rtx_realtime=None):
    """Use the official Replicator API AFTER World.reset, then read back settings.

    Callback injection is solely for CPU tests. This never launches an app,
    resets/steps a world or changes physics. Zero-delay scheduling must already
    have been requested at SimulationApp construction.
    """
    if set_render_rtx_realtime is None:
        import omni.replicator.core as rep
        set_render_rtx_realtime = rep.settings.set_render_rtx_realtime
    if not callable(set_render_rtx_realtime):
        raise ValueError('set_render_rtx_realtime must be callable')
    set_render_rtx_realtime(antialiasing='FXAA')
    values = verify_render_sync_settings(settings_reader)
    return {'schema': SCHEMA, 'status': 'settings_verified', 'settings': values,
            'api': 'rep.settings.set_render_rtx_realtime(antialiasing="FXAA")',
            'required_call_site': 'after World.reset, before camera warmup/recording',
            'physics_advanced': False, 'general_pixel_sync_certified': False,
            'source_sha256': source_snapshot()}


def source_snapshot():
    """The two adapter sources that the caller must include in its frozen manifest."""
    paths = (Path(__file__).resolve(), Path(_barrier_module.__file__).resolve())
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def _array(value, label, shape):
    array = np.asarray(value)
    if array.shape != shape or array.dtype.kind not in 'fiu' or not np.isfinite(array).all():
        raise ValueError(label + ' must be finite numeric data with shape ' + str(shape))
    return array.copy()


def _resolution(value):
    if (not isinstance(value, (tuple, list)) or len(value) != 2
            or any(type(x) is not int or x <= 0 for x in value)):
        raise ValueError('resolution_wh must be positive integer width,height')
    return tuple(value)


def _copy_frames(frames, resolution_wh):
    if not isinstance(frames, dict) or set(frames) != set(CAMERAS):
        raise ValueError('Actual RGB frames must contain exactly the three canonical cameras')
    width, height = resolution_wh
    copied, evidence = {}, {}
    for name in CAMERAS:
        row = frames[name]
        if not isinstance(row, dict):
            raise ValueError(name + ': expected an RGB frame dictionary')
        rgb = np.asarray(row.get('rgb'))
        if rgb.dtype != np.uint8 or rgb.shape != (height, width, 3):
            raise ValueError(name + ': complete uint8 HWC RGB buffer required')
        rgb = np.array(rgb, copy=True, order='C')
        pose = _array(row.get('world_pose_wxyz'), name + ' camera pose', (7,))
        if not math.isclose(float(np.linalg.norm(pose[3:])), 1.0, rel_tol=0, abs_tol=1e-5):
            raise ValueError(name + ': camera pose quaternion must be unit length')
        copied[name] = {'rgb': rgb, 'world_pose_wxyz': pose,
                        'rendering_frame': row.get('rendering_frame'), 'rendering_time': row.get('rendering_time')}
        if 'intrinsics_K' in row:
            K = _array(row['intrinsics_K'], name + ' camera K', (3, 3))
            if K[0, 0] <= 0 or K[1, 1] <= 0 or not np.array_equal(K[2], [0, 0, 1]):
                raise ValueError(name + ': invalid pinhole intrinsics')
            copied[name]['intrinsics_K'] = K
        evidence[name] = {
            # rgb is owned and C-contiguous above. Hash its buffer directly;
            # tobytes() would allocate another full image with identical bytes.
            'rgb_sha256': hashlib.sha256(rgb).hexdigest(),
            'rgb_shape': list(rgb.shape), 'world_pose_wxyz': pose.tolist(),
        }
        if 'intrinsics_K' in copied[name]:
            evidence[name]['intrinsics_K'] = copied[name]['intrinsics_K'].tolist()
    return copied, evidence


def read_rig_camera_frames(rig, *, copy_rgb=True):
    """Read copied SDK RGB/pose/K without mutating rig.capture freshness history.

    Sensor SDK methods are called only here at runtime. No imports or direct
    access to rig._last are needed. Incomplete startup buffers fail closed; the
    caller owns its finite warmup/readiness stage before using this barrier.

    ``copy_rgb=False`` is only for the immediate capture_synced_frames callback:
    its _copy_frames boundary always creates the owned RGB snapshot before any
    render/clock/physics callback. The borrowed RGB view must never be retained
    or used across an app update. Default callers still receive independent
    arrays. SDK clone=True deepcopies the entire RGBA dictionary and is redundant
    with either owned-copy boundary; no event-loop update happens in this reader.
    """
    if type(copy_rgb) is not bool:
        raise ValueError('copy_rgb must be a bool')
    if set(rig.cameras) != set(CAMERAS):
        raise ValueError('Exactly three canonical rig cameras required')
    result = {}
    for name in CAMERAS:
        camera = rig.cameras[name]
        frame = camera.get_current_frame(clone=False)
        rgba = np.asarray(frame.get('rgba'))
        if rgba.dtype != np.uint8 or rgba.ndim != 3 or rgba.shape[-1] not in (3, 4):
            raise ValueError(name + ': complete SDK RGB(A) buffer not ready')
        frame_id, frame_time = frame.get('rendering_frame'), frame.get('rendering_time')
        rgb = np.array(rgba[..., :3], copy=True, order='C') if copy_rgb else rgba[..., :3]
        position, quaternion = camera.get_world_pose(camera_axes='usd')
        result[name] = {'rgb': rgb,
                        'rendering_frame': frame_id,
                        'rendering_time': frame_time,
                        'world_pose_wxyz': np.r_[position, quaternion],
                        'intrinsics_K': np.asarray(camera.get_intrinsics_matrix()).copy()}
    return result


def capture_synced_frames(*, render, read_camera_frames, read_physics_state,
                          settings_reader=None, limits=None, resolution_wh=(640, 480),
                          monotonic=time.monotonic):
    """Return ``(final_frames, report)`` after >=3 actual new synced RGB groups.

    Physics callback schema is exactly the existing barrier contract:
    {step_index, engine_time, state: episode.state(), target: episode.target}.
    Camera reader returns {view: {rgb, rendering_frame, rendering_time,
    world_pose_wxyz, [intrinsics_K]}}. It must not call rig.capture; same-engine-
    time intermediate reads must not advance its action-frame freshness history.

    The existing RenderBarrierLimits bounds are retained: >=3 new groups,
    <=24 calls, <=5 sec, expected-time <=1e-5 sec, cross-view <=1e-6 sec.
    The deadline includes camera copying/hashing and settings checks, but cannot
    preempt a hung synchronous SDK call. No PNG/disk I/O occurs per capture.
    """
    if not callable(read_camera_frames):
        raise ValueError('read_camera_frames must be callable')
    resolution_wh = _resolution(resolution_wh)
    reader = _settings_reader() if settings_reader is None else settings_reader
    records = []
    latest = None
    original_geometry = None

    def read_actual_metadata():
        nonlocal latest, original_geometry
        settings = verify_render_sync_settings(reader)
        frames, evidence = _copy_frames(read_camera_frames(), resolution_wh)
        geometry = {name: {key: row[key] for key in ('world_pose_wxyz', 'intrinsics_K') if key in row}
                    for name, row in frames.items()}
        if original_geometry is None:
            original_geometry = geometry
        else:
            for name in CAMERAS:
                if set(original_geometry[name]) != set(geometry[name]):
                    raise ValueError(name + ': camera geometry inventory changed at frozen physics state')
                for key, before in original_geometry[name].items():
                    after = geometry[name][key]
                    if before.dtype != after.dtype or not np.array_equal(before, after):
                        raise ValueError(name + ': ' + key + ' changed at frozen physics state')
        latest = frames
        records.append({'camera_buffers': evidence, 'settings': settings})
        return {name: {key: row[key] for key in ('rendering_frame', 'rendering_time')}
                for name, row in frames.items()}

    def attach_rgb_evidence(report):
        for call in report['calls']:
            index = call.get('metadata_read_index')
            if index is not None and index < len(records):
                call.update(records[index])
        report.update(schema=SCHEMA, metadata_barrier_schema=_barrier_module.SCHEMA,
                      actual_rgb_copies_read=bool(records), reads_or_writes_rgb=True, writes_rgb_to_disk=False,
                      final_camera_buffers=records[-1]['camera_buffers'] if records else None,
                      expected_settings=dict(EXPECTED_SETTINGS), resolution_wh=list(resolution_wh),
                      general_pixel_sync_certified=False, rig_capture_history_updated=False,
                      buffer_count_semantics='new synchronized rendering IDs with copied RGB, not render-call count',
                      prior_probe_scope='567 final-pass/raw RGB hashes matched in the bounded CTX13 probe; not a general pixel certificate')
    try:
        report = wait_for_render_barrier(render=render, read_cameras_metadata=read_actual_metadata,
                                        read_physics_state=read_physics_state,
                                        limits=limits, monotonic=monotonic)
    except RenderBarrierError as error:
        attach_rgb_evidence(error.report)
        raise
    attach_rgb_evidence(report)
    return latest, report
