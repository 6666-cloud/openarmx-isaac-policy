"""Forward/inverse kinematics from the imported USD joint frames (radians/metres)."""
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from pxr import UsdGeom, UsdPhysics
from context_motion_planning import IKResidualError


def frame(position, quaternion):
    result = np.eye(4)
    result[:3, 3] = position
    result[:3, :3] = Rotation.from_quat(
        [*quaternion.GetImaginary(), quaternion.GetReal()]
    ).as_matrix()
    return result


class ArmKinematics:
    def __init__(self, stage, side="right"):
        self.names = [f"openarmx_{side}_joint{i}" for i in range(1, 8)]
        by_child = {}
        self.limits = {}
        for prim in stage.Traverse():
            if not prim.IsA(UsdPhysics.Joint):
                continue
            joint = UsdPhysics.Joint(prim)
            parents, children = joint.GetBody0Rel().GetTargets(), joint.GetBody1Rel().GetTargets()
            if not parents or not children:
                continue
            local0 = frame(joint.GetLocalPos0Attr().Get(), joint.GetLocalRot0Attr().Get())
            local1 = frame(joint.GetLocalPos1Attr().Get(), joint.GetLocalRot1Attr().Get())
            axis = None
            if prim.IsA(UsdPhysics.RevoluteJoint):
                revolute = UsdPhysics.RevoluteJoint(prim)
                axis = np.eye(3)["XYZ".index(revolute.GetAxisAttr().Get())]
                self.limits[prim.GetName()] = np.deg2rad(
                    [revolute.GetLowerLimitAttr().Get(), revolute.GetUpperLimitAttr().Get()]
                )
            by_child[str(children[0])] = (str(parents[0]), prim.GetName(), local0, np.linalg.inv(local1), axis)
        tip = f"/world/OpenArmX/openarmx_{side}_hand_tcp"
        chain = []
        while tip in by_child:
            parent, name, local0, local1_inverse, axis = by_child[tip]
            chain.append((name, local0, local1_inverse, axis))
            tip = parent
        self.chain = list(reversed(chain))
        self.base = np.array(UsdGeom.Xformable(stage.GetPrimAtPath(tip)).ComputeLocalToWorldTransform(0)).T
        self.lower, self.upper = np.array([self.limits[n] for n in self.names]).T

    def forward(self, q):
        transform = self.base.copy()
        angles = dict(zip(self.names, q))
        for name, local0, local1_inverse, axis in self.chain:
            motion = np.eye(4)
            if axis is not None:
                motion[:3, :3] = Rotation.from_rotvec(axis * angles.get(name, 0.0)).as_matrix()
            transform = transform @ local0 @ motion @ local1_inverse
        return transform

    def solve(self, position, orientation, seed=None):
        seed = np.zeros(7) if seed is None else np.asarray(seed)
        seed = np.clip(seed, self.lower + 1e-5, self.upper - 1e-5)
        rng = np.random.default_rng(42)
        best = None
        def residual(q):
            transform = self.forward(q)
            return np.r_[4 * (transform[:3, 3] - position),
                         Rotation.from_matrix(orientation @ transform[:3, :3].T).as_rotvec(),
                         0.003 * (q - seed)]
        for attempt in range(12):
            start = seed if attempt == 0 else rng.uniform(self.lower + 1e-4, self.upper - 1e-4)
            result = least_squares(residual, start, bounds=(self.lower, self.upper), max_nfev=220)
            if best is None or np.linalg.norm(residual(result.x)[:6]) < best[0]:
                best = (np.linalg.norm(residual(result.x)[:6]), result.x)
            if best[0] < 0.003:
                break
        actual = self.forward(best[1])
        error = np.linalg.norm(actual[:3, 3] - position)
        angle = np.linalg.norm(Rotation.from_matrix(orientation @ actual[:3, :3].T).as_rotvec())
        if error > 0.006 or angle > 0.08:
            raise IKResidualError(position, error, angle)
        return best[1]
