"""CPU-only candidate geometry for an OpenArmX block regrasp inside a bowl.

This finds balanced first contact against the actual convex block and native
convex finger colliders. It is not a collision, force-closure, IK or hardware
safety certificate. The caller must separately check the complete motion,
container contact, actual tracking, and sustained two-finger lifting.
"""
import hashlib

import numpy as np
from scipy.optimize import linprog
from scipy.spatial import ConvexHull, QhullError
from scipy.spatial.transform import Rotation


GEOMETRY_VERSION = 'context_block_bowl_regrasp_v1'
FINGERS = ('left_finger', 'right_finger')


class GraspGeometryError(RuntimeError):
    """No admitted geometry candidate; do not execute a partial plan."""


def _vector(value, name):
    value = np.asarray(value, dtype=float)
    if value.shape != (3,) or not np.isfinite(value).all():
        raise ValueError(f'{name} must be a finite xyz vector')
    return value.copy()


def _rotation(value, name):
    value = np.asarray(value, dtype=float)
    if (value.shape != (3, 3) or not np.isfinite(value).all()
            or not np.allclose(value.T @ value, np.eye(3), atol=1e-6, rtol=0)
            or not np.isclose(np.linalg.det(value), 1, atol=1e-6, rtol=0)):
        raise ValueError(f'{name} must be a finite proper rotation matrix')
    return value.copy()


def _positive(value, name, *, allow_zero=False):
    if isinstance(value, (bool, np.bool_, str, bytes)) or not np.isscalar(value):
        raise ValueError(f'{name} must be a finite numeric scalar')
    value = float(value)
    if not np.isfinite(value) or value < 0 or (value == 0 and not allow_zero):
        raise ValueError(f'{name} must be finite and positive')
    return value


def _vertices(value, name):
    value = np.asarray(value, dtype=float)
    if value.ndim != 2 or value.shape[1] != 3 or len(value) < 4 or not np.isfinite(value).all():
        raise ValueError(f'{name} must contain at least four finite xyz vertices')
    value = np.unique(value, axis=0)
    try:
        hull = ConvexHull(value)
    except QhullError as exc:
        raise ValueError(f'{name} must span a nonzero convex volume') from exc
    return value, hull.equations.copy()


def _first_contact(finger_equations, axis, position, rotation, block_equations, max_opening):
    # The LP variable is [world_x, world_y, world_z, finger_joint_opening].
    # Finger vertices translate by g*axis in TCP space, not by a USD world pose.
    normal = finger_equations[:, :3]
    world_normal = normal @ rotation.T
    constant = finger_equations[:, 3] - world_normal @ position
    constraints = np.vstack((
        np.column_stack((world_normal, -normal @ axis)),
        np.column_stack((block_equations[:, :3], np.zeros(len(block_equations)))),
    ))
    limits = -np.r_[constant, block_equations[:, 3]]
    result = linprog([0, 0, 0, -1], A_ub=constraints, b_ub=limits,
                     bounds=[(None, None)] * 3 + [(0, max_opening)], method='highs')
    if not result.success or result.x is None or not np.isfinite(result.x).all():
        raise GraspGeometryError(f'No finite finger/block first-contact solution: {result.message}')
    if np.max(constraints @ result.x - limits) > 1e-7:
        raise GraspGeometryError('First-contact LP violated geometry constraints')
    return float(result.x[3]), result.x[:3].copy()


def plan_block_bowl_regrasp(object_vertices_local, object_position, object_rotation,
                            grasp_local_offset, grasp_rotation, finger_geometry, *,
                            object_kind='block', vertical_offset=0.020,
                            opening_margin=0.003, max_opening=0.044):
    """Return ``{point, opening, contact_opening, metadata}`` or fail closed.

    Vertices must already have the actual asset scale applied, but remain in
    object-local coordinates. Pose and rotation are the current measured object
    pose. ``finger_geometry`` is returned by ``load_finger_geometry`` or contains
    a ``fingers`` mapping with two zero-opening TCP-space vertex sets and their
    opposite unit translation axes. Only convex BLOCK candidates are in scope.

    Start at the prior asset-specific grasp offset plus a WORLD-z raise. Compute
    the largest opening that touches the block for each finger, then translate
    the TCP along the closing axis to equalize those two openings. The requested
    open position adds real clearance; it is rejected, never clamped, if it
    exceeds the supplied joint range. No actual object or robot pose is changed.
    """
    if object_kind != 'block':
        raise ValueError('This planner is restricted to block bowl regrasp, not fruits or generic assets')
    vertices, _ = _vertices(object_vertices_local, 'object_vertices_local')
    position = _vector(object_position, 'object_position')
    object_rotation = _rotation(object_rotation, 'object_rotation')
    offset = _vector(grasp_local_offset, 'grasp_local_offset')
    rotation = _rotation(grasp_rotation, 'grasp_rotation')
    vertical_offset = _positive(vertical_offset, 'vertical_offset', allow_zero=True)
    opening_margin = _positive(opening_margin, 'opening_margin')
    max_opening = _positive(max_opening, 'max_opening')
    if not isinstance(finger_geometry, dict) or not isinstance(finger_geometry.get('fingers'), dict):
        raise ValueError('finger_geometry must contain a fingers mapping')
    equations, axes = {}, {}
    for name in FINGERS:
        spec = finger_geometry['fingers'].get(name)
        if not isinstance(spec, dict) or not {'vertices_tcp_zero', 'translation_axis_tcp'} <= spec.keys():
            raise ValueError(f'Missing zero-opening geometry/translation axis for {name}')
        _, equations[name] = _vertices(spec['vertices_tcp_zero'], name + ' vertices')
        axes[name] = _vector(spec['translation_axis_tcp'], name + ' translation axis')
        if not np.isclose(np.linalg.norm(axes[name]), 1, atol=1e-6, rtol=0):
            raise ValueError('Finger translation axes must have unit metres-per-metre scale')
    if not np.allclose(axes[FINGERS[0]], -axes[FINGERS[1]], atol=1e-6, rtol=0):
        raise ValueError('This planner requires opposite parallel finger translation axes')
    world_vertices = vertices @ object_rotation.T + position
    _, block_equations = _vertices(world_vertices, 'world block vertices')
    base_point = position + object_rotation @ offset + [0, 0, vertical_offset]
    first = {name: _first_contact(equations[name], axes[name], base_point, rotation,
                                  block_equations, max_opening) for name in FINGERS}
    left, right = [first[name][0] for name in FINGERS]
    adjustment_scalar = (left - right) / 2
    adjustment = rotation @ axes[FINGERS[0]] * adjustment_scalar
    point = base_point + adjustment
    contact_opening = (left + right) / 2
    opening = contact_opening + opening_margin
    if opening > max_opening + 1e-9:
        raise GraspGeometryError(f'Required open joint position {opening:.6f} exceeds {max_opening:.6f}; not clamped')
    balanced = {name: _first_contact(equations[name], axes[name], point, rotation,
                                     block_equations, max_opening) for name in FINGERS}
    if any(abs(value[0] - contact_opening) > 1e-6 for value in balanced.values()):
        raise GraspGeometryError('First-contact centering failed verification')
    return {
        'point': point, 'opening': float(opening), 'contact_opening': float(contact_opening),
        'metadata': {
            'geometry_planner_version': GEOMETRY_VERSION,
            'candidate_scope': 'central bowl convex block regrasp only',
            'object_pose_source': 'current measured pose; privileged scripted-expert geometry',
            'world_vertical_offset_m': vertical_offset,
            'base_point_world_m': base_point.tolist(),
            'centering_adjustment_world_m': adjustment.tolist(),
            'centering_along_left_finger_axis_m': float(adjustment_scalar),
            'point_world_m': point.tolist(), 'grasp_rotation_matrix': rotation.tolist(),
            'initial_first_contact_openings_m': {k: float(v[0]) for k, v in first.items()},
            'balanced_first_contact_openings_m': {k: float(v[0]) for k, v in balanced.items()},
            'first_contact_points_world_m': {k: v[1].tolist() for k, v in balanced.items()},
            'contact_opening_m': float(contact_opening), 'commanded_opening_m': float(opening),
            'opening_margin_per_finger_m': opening_margin, 'maximum_opening_m': max_opening,
            'finger_geometry_sha256': finger_geometry.get('metadata', {}).get('geometry_sha256'),
            'geometry_semantics': 'convex collision hull first contact; not pad-area or force-closure certification',
            'container_collision_validated': False, 'full_path_ik_validated': False,
            'actual_grasp_validated': False, 'hardware_calibrated': False,
        },
    }


def load_finger_geometry(stage, side, model, robot_root='/world/OpenArmX'):
    """Build native convex finger geometry in zero-opening TCP coordinates.

    No simulator imports or GPU calls. USD joint local frames, not live body
    world transforms, determine articulation FK. Body/mesh USD transforms are
    used ONLY as a relative local-geometry transform, so physics-updated body
    poses cancel. ``model`` is the matching ArmKinematics for the same stage.
    The calling runtime should cache this result once per side and record its
    metadata with the source hashes. Importing this module does not load USD.
    """
    if side not in ('left', 'right'):
        raise ValueError('side must be left or right')
    from pxr import Usd, UsdGeom, UsdPhysics

    def matrix(position, quaternion):
        transform = np.eye(4)
        transform[:3, 3] = position
        transform[:3, :3] = Rotation.from_quat([*quaternion.GetImaginary(), quaternion.GetReal()]).as_matrix()
        return transform

    nodes = {}
    for prim in stage.Traverse():
        if not prim.IsA(UsdPhysics.Joint):
            continue
        joint = UsdPhysics.Joint(prim)
        parent, child = joint.GetBody0Rel().GetTargets(), joint.GetBody1Rel().GetTargets()
        if not parent or not child:
            continue
        kind, axis = 'fixed', None
        if prim.IsA(UsdPhysics.RevoluteJoint):
            kind = 'revolute'
            axis = np.eye(3)['XYZ'.index(UsdPhysics.RevoluteJoint(prim).GetAxisAttr().Get())]
        elif prim.IsA(UsdPhysics.PrismaticJoint):
            kind = 'prismatic'
            axis = np.eye(3)['XYZ'.index(UsdPhysics.PrismaticJoint(prim).GetAxisAttr().Get())]
        nodes[str(child[0])] = (
            str(parent[0]), prim.GetName(), matrix(joint.GetLocalPos0Attr().Get(), joint.GetLocalRot0Attr().Get()),
            np.linalg.inv(matrix(joint.GetLocalPos1Attr().Get(), joint.GetLocalRot1Attr().Get())), kind, axis)
    joint_values = dict(zip(model.names, np.zeros(len(model.names))))

    def body_fk(path, visiting=None):
        visiting = set() if visiting is None else visiting
        if path in visiting:
            raise GraspGeometryError('Cycle in imported USD articulation joint graph')
        if path not in nodes:
            prim = stage.GetPrimAtPath(path)
            if not prim:
                raise GraspGeometryError(f'Missing base body {path}')
            return np.array(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)).T
        parent, name, local0, local1_inverse, kind, axis = nodes[path]
        motion = np.eye(4)
        if kind == 'revolute':
            motion[:3, :3] = Rotation.from_rotvec(axis * joint_values.get(name, 0.0)).as_matrix()
        elif kind == 'prismatic':
            motion[:3, 3] = axis * joint_values.get(name, 0.0)
        return body_fk(parent, visiting | {path}) @ local0 @ motion @ local1_inverse

    tcp_inverse = np.linalg.inv(np.asarray(model.forward(np.zeros(len(model.names))), dtype=float))
    samples, mesh_paths = {}, {}
    for opening in (0.0, 0.01):
        joint_values[f'openarmx_{side}_finger_joint1'] = opening
        joint_values[f'openarmx_{side}_finger_joint2'] = opening
        samples[opening] = {}
        for suffix in FINGERS:
            body_path = f'{robot_root}/openarmx_{side}_{suffix}'
            body = stage.GetPrimAtPath(body_path)
            if not body:
                raise GraspGeometryError(f'Missing finger body {body_path}')
            inverse_body = np.linalg.inv(np.array(UsdGeom.Xformable(body).ComputeLocalToWorldTransform(0)).T)
            collected, paths = [], []
            for prim in Usd.PrimRange(body, Usd.TraverseInstanceProxies()):
                if not prim.IsA(UsdGeom.Mesh) or '/collisions/' not in str(prim.GetPath()):
                    continue
                # Imported OpenArmX applies its collision API to the ancestor
                # /collisions Xform, not necessarily to the instance mesh.
                collider = prim
                while collider and str(collider.GetPath()) != body_path and not collider.HasAPI(UsdPhysics.MeshCollisionAPI):
                    collider = collider.GetParent()
                if not collider or not collider.HasAPI(UsdPhysics.MeshCollisionAPI):
                    raise GraspGeometryError(f'No native mesh collision schema for {prim.GetPath()}')
                approximation = UsdPhysics.MeshCollisionAPI(collider).GetApproximationAttr().Get()
                if approximation != 'convexHull':
                    raise GraspGeometryError(f'Expected native convexHull finger collider, got {approximation}')
                points = np.asarray(UsdGeom.Mesh(prim).GetPointsAttr().Get(), dtype=float)
                relative_mesh = inverse_body @ np.array(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(0)).T
                transform = tcp_inverse @ body_fk(body_path) @ relative_mesh
                collected.append(points @ transform[:3, :3].T + transform[:3, 3])
                paths.append(str(prim.GetPath()))
            if not collected:
                raise GraspGeometryError(f'No native finger collision vertices found for {body_path}')
            samples[opening][suffix] = np.vstack(collected)
            mesh_paths[suffix] = paths
    fingers, digest = {}, hashlib.sha256()
    for name in FINGERS:
        zero = samples[0.0][name]
        delta = (samples[0.01][name] - zero) / 0.01
        axis = delta.mean(axis=0)
        if not np.allclose(delta, axis, atol=1e-7, rtol=0) or not np.isclose(np.linalg.norm(axis), 1, atol=1e-6):
            raise GraspGeometryError('Imported finger is not a pure unit-scale prismatic translation')
        _vertices(zero, name)
        fingers[name] = {'vertices_tcp_zero': zero, 'translation_axis_tcp': axis}
        digest.update(name.encode('utf8'))
        digest.update(np.asarray(zero, dtype='<f8').tobytes())
        digest.update(np.asarray(axis, dtype='<f8').tobytes())
    if not np.allclose(fingers[FINGERS[0]]['translation_axis_tcp'], -fingers[FINGERS[1]]['translation_axis_tcp'], atol=1e-6):
        raise GraspGeometryError('Imported finger joint axes are not opposite')
    return {'fingers': fingers, 'metadata': {
        'geometry_version': GEOMETRY_VERSION, 'side': side, 'mesh_paths': mesh_paths,
        'geometry_sha256': digest.hexdigest(), 'collider_approximation': 'native convexHull',
        'coordinate_frame': 'TCP, zero finger joint opening, metres',
        'fk_source': 'USD static joint local frames; relative body-to-mesh transform only',
        'vertex_counts': {name: len(spec['vertices_tcp_zero']) for name, spec in fingers.items()},
    }}
