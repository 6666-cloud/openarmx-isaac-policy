"""Bounded one-IK wrist reorientation planning; pure CPU, no Isaac/ROS imports.

This is joint-space interpolation inside a caller-specified sampled TCP corridor,
NOT a Cartesian stationary-or-straight-line motion, swept-volume certificate, or
hardware controller. Use only for free-space ipsilateral prealignment; runtime
must still verify collisions, actual tracking, and any held-object grasp.
"""
import math
import time

import numpy as np
from scipy.spatial.transform import Rotation

from context_motion_planning import MotionPlanningError, command_metrics

PLANNER_VERSION = 'context_joint_reorientation_preflight_v1'


def _positive(value, name):
    if isinstance(value, (bool, np.bool_, str, bytes)) or not np.isscalar(value):
        raise ValueError(f'{name} must be a finite positive scalar')
    value = float(value)
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be a finite positive scalar')
    return value


def _caps(value, size, name):
    original = np.asarray(value)
    if original.dtype.kind not in 'iuf':
        raise ValueError(f'{name} must contain numeric positive caps')
    value = np.asarray(value, dtype=float)
    if value.ndim == 0:
        value = np.full(size, float(value))
    if value.shape != (size,) or not np.isfinite(value).all() or np.any(value <= 0):
        raise ValueError(f'{name} must be positive finite scalar or shape ({size},)')
    return value.copy()


def _rotation(value, name):
    value = np.asarray(value, dtype=float)
    if (value.shape != (3, 3) or not np.isfinite(value).all()
            or not np.allclose(value.T @ value, np.eye(3), atol=1e-5, rtol=0)
            or not np.isclose(np.linalg.det(value), 1, atol=1e-5, rtol=0)):
        raise ValueError(f'{name} must be a finite proper rotation matrix')
    return value.copy()


def plan_joint_reorientation(model, start_q, goal, R, duration, fps=30,
                             velocity_cap=1.5, acceleration_cap=5.0, *,
                             corridor_min, corridor_max, max_retimes=6,
                             max_duration=120.0, position_tolerance=0.006,
                             rotation_tolerance=0.08, max_planning_seconds=45.0,
                             max_frames=100000):
    """Return ``(joint_targets, metadata)`` only after complete preflight.

    ``start_q`` is the LAST COMMANDED target, not the measured lagging position.
    ``model`` must provide finite ``lower``/``upper`` limits, ``forward(q)`` and
    ``solve(goal, R, seed)``. Exactly one endpoint IK solve is attempted. Retiming
    regenerates quintic joint samples without solving IK at intermediate points.

    Inclusive ``corridor_min``/``corridor_max`` bound xyz in the model's FK frame;
    negative-y corridors must still use increasing numeric min/max. Start,
    endpoint, and EVERY returned command's FK position are checked. This says
    nothing about continuous swept geometry or a held object's extent. No
    fixed intermediate Cartesian position/orientation path is promised.

    Rows correspond to t=1/fps..N/fps, with no duplicate starting row. Rest-padded
    discrete velocity/acceleration caps include zero-velocity boundaries. The
    final command MUST be held at least one frame before another segment.
    Default1.5rad/s and5rad/s^2 caps are expert-quality settings, not measured
    hardware limits. Endpoint residual tolerances may be tightened, not relaxed
    beyond6mm/0.08rad. The45s default wall budget is checked around the single
    synchronous non-preemptible IK call and each FK call; a late result is rejected.
    """
    started = time.monotonic()
    wall_budget = _positive(max_planning_seconds, 'max_planning_seconds')
    deadline = started + wall_budget

    def check_deadline(context):
        if time.monotonic() >= deadline:
            raise MotionPlanningError(f'Planning wall-time budget exceeded {context}; execute nothing')

    q0 = np.asarray(start_q, dtype=float)
    goal = np.asarray(goal, dtype=float)
    lo = np.asarray(corridor_min, dtype=float)
    hi = np.asarray(corridor_max, dtype=float)
    if q0.ndim != 1 or not len(q0) or not np.isfinite(q0).all():
        raise ValueError('start_q must be a nonempty finite vector')
    if goal.shape != (3,) or not np.isfinite(goal).all():
        raise ValueError('goal must be a finite xyz vector')
    if lo.shape != (3,) or hi.shape != (3,) or not np.isfinite(lo).all() or not np.isfinite(hi).all() or np.any(lo > hi):
        raise ValueError('corridor bounds must be finite xyz vectors with min <= max')
    q0, goal, lo, hi = q0.copy(), goal.copy(), lo.copy(), hi.copy()
    R = _rotation(R, 'R')
    duration, fps = _positive(duration, 'duration'), _positive(fps, 'fps')
    max_duration = _positive(max_duration, 'max_duration')
    ptol = _positive(position_tolerance, 'position_tolerance')
    rtol = _positive(rotation_tolerance, 'rotation_tolerance')
    if ptol > 0.006 or rtol > 0.08:
        raise ValueError('Endpoint tolerances cannot exceed6mm/0.08rad')
    if not isinstance(max_retimes, (int, np.integer)) or isinstance(max_retimes, (bool, np.bool_)) or max_retimes < 0:
        raise ValueError('max_retimes must be a nonnegative integer')
    if not isinstance(max_frames, (int, np.integer)) or isinstance(max_frames, (bool, np.bool_)) or max_frames < 2:
        raise ValueError('max_frames must be an integer >=2')
    velocity_cap = _caps(velocity_cap, len(q0), 'velocity_cap')
    acceleration_cap = _caps(acceleration_cap, len(q0), 'acceleration_cap')
    lower = np.asarray(getattr(model, 'lower', None), dtype=float)
    upper = np.asarray(getattr(model, 'upper', None), dtype=float)
    if (lower.shape != q0.shape or upper.shape != q0.shape or not np.isfinite(lower).all()
            or not np.isfinite(upper).all() or np.any(lower >= upper)):
        raise ValueError('Model must provide finite valid lower/upper joint limits matching start_q')
    if duration > max_duration:
        raise MotionPlanningError('Requested duration exceeds maximum planning duration')

    def check_joints(q, context):
        if q.shape != q0.shape or not np.isfinite(q).all():
            raise MotionPlanningError(f'Invalid joint vector {context}; execute nothing')
        if np.any(q < lower - 1e-9) or np.any(q > upper + 1e-9):
            raise MotionPlanningError(f'Joint limit violation {context}; execute nothing')

    def check_corridor(point, context):
        if np.any(point < lo - 1e-9) or np.any(point > hi + 1e-9):
            raise MotionPlanningError(f'FK outside Cartesian corridor {context}: xyz={point.tolist()}; execute nothing')

    def forward(q, context):
        check_deadline('before FK ' + context)
        try:
            transform = np.asarray(model.forward(q.copy()), dtype=float)
        except Exception as error:
            raise MotionPlanningError(f'FK failed {context}; execute nothing: {error}') from error
        check_deadline('after FK ' + context)
        if (transform.shape != (4, 4) or not np.isfinite(transform).all()
                or not np.allclose(transform[3], [0, 0, 0, 1], atol=1e-7, rtol=0)):
            raise MotionPlanningError(f'Invalid FK homogeneous transform {context}; execute nothing')
        try:
            _rotation(transform[:3, :3], 'FK rotation')
        except ValueError as error:
            raise MotionPlanningError(f'Invalid FK rotation {context}; execute nothing') from error
        check_corridor(transform[:3, 3], context)
        return transform

    check_joints(q0, 'at previous commanded target')
    start_transform = forward(q0, 'at previous commanded target')
    check_corridor(goal, 'at requested endpoint')
    check_deadline('before endpoint IK')
    try:
        q1 = np.asarray(model.solve(goal.copy(), R.copy(), q0.copy()), dtype=float)
    except Exception as error:
        raise MotionPlanningError(f'Endpoint IK failed; execute nothing: {error}') from error
    check_deadline('after endpoint IK')
    check_joints(q1, 'at endpoint IK')
    q1 = q1.copy()
    endpoint = forward(q1, 'at endpoint IK')
    position_error = float(np.linalg.norm(endpoint[:3, 3] - goal))
    rotation_error = float(Rotation.from_matrix(R @ endpoint[:3, :3].T).magnitude())
    if position_error > ptol + 1e-9 or rotation_error > rtol + 1e-9:
        raise MotionPlanningError(f'Endpoint IK residual exceeds tolerance: position={position_error}m rotation={rotation_error}rad; execute nothing')
    frames = max(2, math.ceil(duration * fps))
    attempts = []
    for attempt in range(int(max_retimes) + 1):
        check_deadline(f'before retime {attempt}')
        actual_duration = frames / fps
        if actual_duration > max_duration + 1e-12 or frames > max_frames:
            raise MotionPlanningError(f'Time scaling exceeds duration/frame budget; last attempts={attempts[-2:]}')
        u = np.arange(1, frames + 1, dtype=float) / frames
        blend = u**3 * (10 - 15*u + 6*u*u)
        trajectory = q0[None, :] + blend[:, None] * (q1 - q0)[None, :]
        trajectory[-1] = q1
        metrics = command_metrics(q0, trajectory, fps)
        vr = float(np.max(metrics['peak_velocity_by_joint'] / velocity_cap))
        ar = float(np.max(metrics['peak_acceleration_by_joint'] / acceleration_cap))
        attempts.append({'frames': frames, 'duration_s': actual_duration,
                         'velocity_ratio': vr, 'acceleration_ratio': ar})
        if vr <= 1 + 1e-8 and ar <= 1 + 1e-8:
            points = [start_transform[:3, 3]]
            for index, q in enumerate(trajectory):
                check_joints(q, f'at command {index + 1}/{frames}')
                points.append(forward(q, f'at command {index + 1}/{frames}')[:3, 3])
            points = np.asarray(points)
            check_deadline('after complete path preflight')
            return trajectory, {
                'planner_version': PLANNER_VERSION, 'status': 'kinematic_preflight_passed',
                'planning_wall_seconds': time.monotonic() - started,
                'max_planning_seconds': wall_budget,
                'planning_deadline_semantics': 'checked before/after the one non-preemptible endpoint IK call and each FK call',
                'requested_duration_s': duration, 'duration_s': actual_duration,
                'fps': fps, 'frames': frames, 'retime_count': attempt,
                'maximum_ik_position_error_m': position_error,
                'maximum_ik_rotation_error_rad': rotation_error,
                'ik_position_tolerance_m': ptol, 'ik_rotation_tolerance_rad': rtol,
                'ik_residual_scope': 'endpoint only; intermediate commands are quintic joint interpolation',
                'ik_solve_count': 1, 'joint_limits_validated': True,
                'velocity_cap_by_joint': velocity_cap.tolist(),
                'acceleration_cap_by_joint': acceleration_cap.tolist(),
                **{key: value.tolist() for key, value in metrics.items()},
                'retime_attempts': attempts,
                'caps_semantics': 'chosen scripted-expert quality caps; not hardware-calibrated limits',
                'start_semantics': 'previous commanded joint target',
                'acceleration_boundary_semantics': 'zero commanded velocity immediately before and after segment',
                'required_final_hold_frames_min': 1,
                'corridor_min_m': lo.tolist(), 'corridor_max_m': hi.tolist(),
                'sampled_fk_xyz_min_m': points.min(axis=0).tolist(),
                'sampled_fk_xyz_max_m': points.max(axis=0).tolist(),
                'corridor_sample_count': len(points),
                'corridor_semantics': 'start and every commanded TCP FK sample only; not continuous swept geometry or object-extent containment',
                'cartesian_path_semantics': 'endpoint-constrained joint interpolation, not stationary/straight-line Cartesian motion',
                'collision_and_contact_validated': False, 'actual_tracking_validated': False,
                'hardware_deployment_validated': False,
            }
        stretch = max(vr, math.sqrt(ar), 1.01) * 1.05
        frames = max(frames + 1, math.ceil(frames * stretch))
    raise MotionPlanningError(f'Command derivative caps not met after{max_retimes} retimes; attempts={attempts}')
