"""Measured yaw candidate for CTX01 initial tabletop block grasps only.

Pure pose arithmetic, never an object transform or actuator command. Keeping
the fingers parallel to the measured block faces avoids deliberately rotating
a sampled block to the old fixed world-yaw grasp during squeeze. Physical
contact, full-path IK, return pose and A/B checks remain mandatory.
"""
import numpy as np
from scipy.spatial.transform import Rotation


def initial_table_block_yaw(*, task, name, asset, location, surface, point,
                            object_quaternion_wxyz, strict_pitch=False):
    """Return a measured yaw, or None outside the narrowly reviewed scope.

    No yaw clamp, sampled-domain reduction, cube-symmetry remapping or fallback
    to world yaw is permitted for an eligible block. Non-upright or out-of-domain
    observations fail closed instead of silently changing the scene.
    """
    if (task != 'CTX01' or name not in ('red', 'blue')
            or not str(asset).endswith('_block.usd')
            or location != 'initial:' + name or surface != 'table'
            or strict_pitch):
        return None
    point = np.asarray(point, dtype=float)
    if point.shape != (3,) or not np.isfinite(point).all():
        raise ValueError('Initial tabletop block point must be finite xyz')
    if abs(point[1]) < .12:
        return None
    q = np.asarray(object_quaternion_wxyz, dtype=float)
    if (q.shape != (4,) or not np.isfinite(q).all()
            or abs(float(np.linalg.norm(q)) - 1.) > .001):
        raise ValueError('Measured tabletop block quaternion must be normalized wxyz')
    rotation = Rotation.from_quat(np.r_[q[1:], q[0]]).as_matrix()
    tilt = float(np.arccos(np.clip(rotation[2, 2], -1., 1.)))
    if tilt > .02:
        raise ValueError('Measured initial tabletop block is not upright')
    yaw = float(np.arctan2(rotation[1, 0], rotation[0, 0]))
    # Source sampling is [-.10,+.10] rad. The additional .02 is a measured
    # settling check, NOT a clamp, new source distribution or pair tolerance.
    if abs(yaw) > .12:
        raise ValueError('Measured initial tabletop yaw is outside the reviewed range')
    return yaw
