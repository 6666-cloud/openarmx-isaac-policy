"""Pure-CPU native-collider push geometry, not a physical safety certificate.

Use measured finger apertures AFTER closing, never the commanded zero. The
caller must still preflight and physically verify motion, tracking, contacts,
object stability and placement. This module never modifies a stage or robot.
USD is imported lazily only by the two native-scene readback helpers.
"""
import itertools

import numpy as np
from scipy.optimize import linprog
from scipy.spatial import ConvexHull, QhullError

GEOMETRY_VERSION = 'context_native_push_v1'
FINGERS = ('left_finger', 'right_finger')


class PushGeometryError(RuntimeError):
    """No admitted candidate: do not execute an incomplete/guessed plan."""


def _scalar(value, name, *, zero=False):
    if isinstance(value, (bool, np.bool_, str, bytes)) or not np.isscalar(value):
        raise ValueError(f'{name} must be a finite numeric scalar')
    value = float(value)
    if not np.isfinite(value) or value < 0 or (value == 0 and not zero):
        raise ValueError(f'{name} must be finite and positive')
    return value


def _vector(value, name):
    value = np.asarray(value, dtype=float)
    if value.shape != (3,) or not np.isfinite(value).all():
        raise ValueError(f'{name} must be a finite xyz vector')
    return value.copy()


def _rotation(value):
    value = np.asarray(value, dtype=float)
    if (value.shape != (3, 3) or not np.isfinite(value).all()
            or not np.allclose(value.T @ value, np.eye(3), atol=1e-6, rtol=0)
            or not np.isclose(np.linalg.det(value), 1, atol=1e-6, rtol=0)):
        raise ValueError('rotation must be a finite proper rotation matrix')
    return value.copy()


def _vertices(value, name):
    value = np.asarray(value, dtype=float)
    if (value.ndim != 2 or value.shape[1] != 3 or len(value) < 4
            or not np.isfinite(value).all()):
        raise ValueError(f'{name} must contain at least four finite xyz vertices')
    value = np.unique(value, axis=0)
    try:
        equations = ConvexHull(value).equations.copy()
    except QhullError as exc:
        raise ValueError(f'{name} must span a nonzero convex volume') from exc
    return value, equations


def derive_push_geometry(finger_geometry, actual_openings, block_world_vertices,
                         block_center, rotation, direction, tcp_z, *,
                         approach_clearance=0.006, contact_margin=0.0005,
                         max_opening=0.044, max_contact_offset=0.15):
    """Exact convex first contact with TCP = anchor - distance*direction.

    anchor=[block_center.x, block_center.y, tcp_z]. The four LP variables are
    world contact xyz plus distance behind the block. The maximum feasible
    distance across both fingers is first/leading contact. This respects the
    vertical/lateral contact slab instead of combining unrelated projections.
    Inputs must describe native finger convex hulls and the actual world block
    collider (use load_bounding_cube_world_vertices for supported scene blocks).
    """
    direction = _vector(direction, 'direction')
    if abs(direction[2]) > 1e-10 or not np.isclose(np.linalg.norm(direction), 1, atol=1e-8, rtol=0):
        raise ValueError('direction must be a horizontal unit vector')
    rotation = _rotation(rotation)
    block_center = _vector(block_center, 'block_center')
    _, block_equations = _vertices(block_world_vertices, 'block_world_vertices')
    if isinstance(tcp_z, (bool, np.bool_, str, bytes)) or not np.isscalar(tcp_z) or not np.isfinite(tcp_z):
        raise ValueError('tcp_z must be a finite numeric scalar')
    approach_clearance = _scalar(approach_clearance, 'approach_clearance')
    contact_margin = _scalar(contact_margin, 'contact_margin', zero=True)
    max_opening = _scalar(max_opening, 'max_opening')
    max_contact_offset = _scalar(max_contact_offset, 'max_contact_offset')
    if contact_margin > .002:
        raise ValueError('contact_margin must not exceed 2 mm')
    if not isinstance(finger_geometry, dict) or not isinstance(finger_geometry.get('fingers'), dict):
        raise ValueError('finger_geometry must contain a fingers mapping')
    if set(finger_geometry['fingers']) != set(FINGERS) or not isinstance(actual_openings, dict) or set(actual_openings) != set(FINGERS):
        raise ValueError('Exactly the two named native fingers and measured openings are required')
    equations_by_finger, openings, axes = {}, {}, {}
    # Validate BOTH fingers before solving, including the inactive one.
    for name in FINGERS:
        spec = finger_geometry['fingers'][name]
        if not isinstance(spec, dict) or not {'vertices_tcp_zero', 'translation_axis_tcp'} <= spec.keys():
            raise ValueError(f'Missing native geometry/translation axis for {name}')
        vertices, _ = _vertices(spec['vertices_tcp_zero'], name + ' vertices')
        axis = _vector(spec['translation_axis_tcp'], name + ' translation axis')
        if not np.isclose(np.linalg.norm(axis), 1, atol=1e-6, rtol=0):
            raise ValueError('Finger translation axis must have unit metres-per-metre scale')
        opening = _scalar(actual_openings[name], name + ' measured opening', zero=True)
        if opening > max_opening:
            raise ValueError('Measured finger opening exceeds admitted maximum')
        _, equations_by_finger[name] = _vertices(vertices + opening * axis, name + ' measured vertices')
        axes[name], openings[name] = axis, opening
    if not np.allclose(axes[FINGERS[0]], -axes[FINGERS[1]], atol=1e-6, rtol=0):
        raise ValueError('Native two-finger axes must be opposite parallel axes')
    anchor = np.r_[block_center[:2], float(tcp_z)]
    candidates, infeasible = {}, []
    for name in FINGERS:
        equations = equations_by_finger[name]
        normals = equations[:, :3] @ rotation.T
        constants = equations[:, 3] - normals @ anchor
        constraints = np.vstack((np.c_[normals, normals @ direction],
                                 np.c_[block_equations[:, :3], np.zeros(len(block_equations))]))
        limits = -np.r_[constants, block_equations[:, 3]]
        try:
            result = linprog([0, 0, 0, -1], A_ub=constraints, b_ub=limits,
                             bounds=[(None, None)] * 3 + [(0, max_contact_offset)], method='highs')
        except Exception as exc:
            raise PushGeometryError(f'First-contact LP raised for {name}: {exc}') from exc
        if result.status == 2 and not result.success:
            infeasible.append(name)  # No intersection in the admitted sweep.
            continue
        if result.status != 0 or not result.success:
            raise PushGeometryError(f'First-contact solver failed for {name}: status={result.status}, {result.message}')
        solution = np.asarray(result.x, dtype=float)
        if (solution.shape != (4,) or not np.isfinite(solution).all()
                or np.max(constraints @ solution - limits) > 1e-7):
            raise PushGeometryError('Invalid or constraint-violating first-contact LP result')
        if not 0 < solution[3] < max_contact_offset - 1e-6:
            raise PushGeometryError('First contact touches admitted sweep limit')
        candidates[name] = {'offset_m': float(solution[3]), 'point_world_m': solution[:3].tolist(),
                            'measured_opening_m': openings[name]}
    if not candidates:
        raise PushGeometryError('Neither finger overlaps the block in the admitted sweep')
    leading = max(candidates, key=lambda name: candidates[name]['offset_m'])
    distance = candidates[leading]['offset_m']
    if distance <= contact_margin:
        raise PushGeometryError('Contact margin would move TCP beyond admitted contact geometry')
    return {'geometry_version': GEOMETRY_VERSION, 'contact_offset_m': distance,
            'leading_finger': leading, 'behind_offset_m': distance + approach_clearance,
            'endpoint_offset_m': distance - contact_margin,
            'approach_clearance_m': approach_clearance, 'contact_margin_m': contact_margin,
            'contacts': candidates, 'no_overlap_fingers': infeasible,
            'actual_openings_m': openings, 'finger_geometry_sha256': finger_geometry.get('metadata', {}).get('geometry_sha256'),
            'physical_contact_and_placement_validated': False, 'full_path_ik_validated': False,
            'full_body_collision_validated': False, 'hardware_calibrated': False}


def measured_finger_openings(stage, side, joint_names, joint_positions, *,
                             robot_root='/world/OpenArmX', max_opening=0.044):
    """Resolve each finger's actual prismatic coordinate by native USD Body1.

    Returns (openings, mapping evidence). This reads current joint_positions;
    it cannot prove that the caller allowed sufficient settling time.
    """
    if side not in ('left', 'right'):
        raise ValueError('side must be left or right')
    if not isinstance(joint_names, (list, tuple)) or not joint_names or not all(isinstance(x, str) and x for x in joint_names) or len(set(joint_names)) != len(joint_names):
        raise ValueError('joint_names must be unique nonempty strings')
    positions = np.asarray(joint_positions, dtype=float)
    if positions.shape != (len(joint_names),) or not np.isfinite(positions).all():
        raise ValueError('joint_positions must be finite and match joint_names')
    max_opening = _scalar(max_opening, 'max_opening')
    from pxr import UsdPhysics
    expected = {f'{robot_root}/openarmx_{side}_{name}': name for name in FINGERS}
    found, evidence = {}, {}
    for prim in stage.Traverse():
        if not prim.IsA(UsdPhysics.PrismaticJoint):
            continue
        bodies = UsdPhysics.Joint(prim).GetBody1Rel().GetTargets()
        matches = [str(body) for body in bodies if str(body) in expected]
        if not matches:
            continue
        if len(bodies) != 1 or len(matches) != 1:
            raise PushGeometryError('Ambiguous prismatic Body1 relationship')
        name = expected[matches[0]]
        if name in found or prim.GetName() not in joint_names:
            raise PushGeometryError('Duplicate or missing measured prismatic joint mapping')
        value = float(positions[joint_names.index(prim.GetName())])
        if not 0 <= value <= max_opening:
            raise PushGeometryError('Measured aperture outside admitted range; not clamped')
        found[name] = value
        evidence[name] = {'body_path': matches[0], 'joint_path': str(prim.GetPath()),
                          'joint_name': prim.GetName(), 'measured_opening_m': value}
    if set(found) != set(FINGERS):
        raise PushGeometryError('Missing native finger prismatic mapping')
    return found, evidence


def load_bounding_cube_world_vertices(stage, collider_path, object_root_path,
                                      object_position, object_rotation, *, applied_scale=1.0):
    """Read one enabled native boundingCube mesh collider into measured world.

    applied_scale is the rigid object's root scale, excluded by the relative
    collider-to-root transform; pass the scene config's actual applied_scale.
    Reject unsupported shapes instead of silently using a visual mesh hull.
    """
    position, rotation = _vector(object_position, 'object_position'), _rotation(object_rotation)
    scale = np.asarray(applied_scale, dtype=float)
    if scale.ndim == 0:
        scale = np.full(3, float(scale))
    if scale.shape != (3,) or not np.isfinite(scale).all() or np.any(scale <= 0):
        raise ValueError('applied_scale must be finite positive scalar or xyz scale')
    from pxr import UsdGeom, UsdPhysics
    collider, root = stage.GetPrimAtPath(collider_path), stage.GetPrimAtPath(object_root_path)
    if not collider or not root or not collider.GetPath().HasPrefix(root.GetPath()) or not collider.IsA(UsdGeom.Mesh):
        raise PushGeometryError('Expected native mesh collider underneath the object root')
    if not collider.HasAPI(UsdPhysics.CollisionAPI) or not UsdPhysics.CollisionAPI(collider).GetCollisionEnabledAttr().Get():
        raise PushGeometryError('Expected enabled native collision mesh')
    if not collider.HasAPI(UsdPhysics.MeshCollisionAPI) or UsdPhysics.MeshCollisionAPI(collider).GetApproximationAttr().Get() != 'boundingCube':
        raise PushGeometryError('Only native boundingCube block colliders are supported')
    points, _ = _vertices(UsdGeom.Mesh(collider).GetPointsAttr().Get(), 'native mesh points')
    corners = np.array(list(itertools.product(*zip(points.min(0), points.max(0)))))
    relative, reset = UsdGeom.XformCache().ComputeRelativeTransform(collider, root)
    matrix = np.asarray(relative, dtype=float).T
    if reset or matrix.shape != (4, 4) or not np.isfinite(matrix).all():
        raise PushGeometryError('Unsupported reset/nonfinite native collider transform')
    local = (corners @ matrix[:3, :3].T + matrix[:3, 3]) * scale
    world = local @ rotation.T + position
    _vertices(world, 'world native boundingCube')
    return world
