"""Pure CPU shape-aware container geometry, independent of Isaac runtime.

No policy threshold changes: functions expose measurements; callers retain
their existing 95% horizontal containment and rim-minus-8mm requirements.
Outside tests use a conservative WHOLE-object AABB, never vertex-only radii.
"""
import itertools
import numpy as np

SCHEMA = 'container_footprint_v1'


def _finite(value, shape=None):
    out=np.asarray(value,dtype=float)
    if not np.isfinite(out).all() or (shape is not None and out.shape!=shape):
        raise ValueError('Expected finite geometry of shape '+str(shape))
    return out


def validate_geometry(geometry):
    if not isinstance(geometry,dict) or geometry.get('footprint_schema')!=SCHEMA:
        raise ValueError('Explicit container_footprint_v1 geometry required; no implicit circle fallback')
    shape=geometry.get('shape')
    if shape not in ('rectangle','ellipse','circle'):
        raise ValueError('Unsupported container shape')
    center=_finite(geometry['center'])
    if center.shape not in ((2,),(3,)):
        raise ValueError('Expected XY or XYZ center')
    yaw=float(geometry.get('yaw',0.0))
    if not np.isfinite(yaw):raise ValueError('Invalid yaw')
    if shape=='circle':
        inner=np.repeat(float(geometry['inner_radius']),2)
        outer=np.repeat(float(geometry['outer_radius']),2)
    else:
        if 'inner_radius' in geometry or 'outer_radius' in geometry:
            raise ValueError('Noncircular container must not pretend to have a scalar radius')
        inner=_finite(geometry['inner_half_extents'],(2,))
        outer=_finite(geometry['outer_half_extents'],(2,))
    if not (np.isfinite(inner).all() and np.isfinite(outer).all()) or np.any(inner<=0) or np.any(outer<inner):
        raise ValueError('Positive inner extents and enclosing outer extents required')
    rim=float(geometry['rim_z']);floor=float(geometry['floor_z'])
    if not np.isfinite(rim+floor) or rim<=floor:
        raise ValueError('Rim must be above floor')
    rotation=np.array([[np.cos(yaw),-np.sin(yaw)],[np.sin(yaw),np.cos(yaw)]])
    return dict(shape=shape,center=center[:2].copy(),rotation=rotation,inner=inner,outer=outer,rim=rim,floor=floor)


def local_xy(vertices,geometry):
    value=_finite(vertices)
    if value.ndim!=2 or value.shape[1] not in (2,3) or not len(value):
        raise ValueError('Nonempty Nx2 or Nx3 native vertices required')
    spec=validate_geometry(geometry)
    return (value[:,:2]-spec['center'])@spec['rotation']


def contains_xy(vertices,geometry):
    spec=validate_geometry(geometry)
    xy=local_xy(vertices,geometry)
    if spec['shape']=='rectangle':
        return np.all(np.abs(xy)<spec['inner'],axis=1)
    return np.sum((xy/spec['inner'])**2,axis=1)<1.0


def contains_xy_compatible(vertices, geometry):
    """Explicit shape geometry, or strictly identified historical circles.

    A legacy radial placement check only requires center and inner_radius;
    do not invent a floor, rim, or outer radius to fit the new schema. Any
    declared shape/extents without its schema is rejected, not reinterpreted
    as a circle. Existing genuine circle comparisons retain their exact math.
    """
    if not isinstance(geometry, dict):
        raise ValueError('Expected container geometry object')
    if 'footprint_schema' in geometry:
        return contains_xy(vertices, geometry)
    if any(key in geometry for key in ('shape','inner_half_extents','outer_half_extents')):
        raise ValueError('Nonlegacy container geometry requires an explicit footprint schema')
    if 'inner_radius' not in geometry or 'center' not in geometry:
        raise ValueError('Legacy circle requires center and inner_radius')
    center = _finite(geometry['center'])
    value = _finite(vertices)
    radius = float(geometry['inner_radius'])
    if (center.shape not in ((2,),(3,)) or value.ndim != 2
            or value.shape[1] not in (2,3) or not len(value)
            or not np.isfinite(radius) or radius <= 0):
        raise ValueError('Invalid legacy circle geometry or native vertices')
    return np.linalg.norm(value[:,:2]-center[:2],axis=1) < radius


def containment_metrics(vertices,geometry):
    value=_finite(vertices)
    if value.ndim!=2 or value.shape[1]!=3 or not len(value):
        raise ValueError('Expected nonempty Nx3 native object vertices')
    spec=validate_geometry(geometry)
    horizontal=contains_xy(value,geometry)
    below_rim=value[:,2]<spec['rim']+.002
    return dict(horizontal_fraction=float(horizontal.mean()),
        contained_fraction=float(np.mean(horizontal&below_rim)),
        minimum_z_m=float(value[:,2].min()),
        below_rim_depth_m=float(spec['rim']-value[:,2].min()),
        below_rim_8mm=bool(value[:,2].min()<spec['rim']-.008),
        shape=spec['shape'],footprint_schema=SCHEMA)


def whole_object_outside_footprint(vertices,geometry,*,margin=.002):
    """Conservative proof, not an assertion that one outside vertex suffices.

    Rectangle: local AABB separated on at least one axis. Circle: closest AABB
    point is farther than outer radius+margin. Ellipse: use its outer bounding
    rectangle, avoiding an unsound 'add margin to each ellipse axis' shortcut.
    """
    margin=float(margin)
    if not np.isfinite(margin) or margin<0:raise ValueError('Nonnegative finite margin required')
    spec=validate_geometry(geometry);xy=local_xy(vertices,geometry)
    lo,hi=xy.min(0),xy.max(0)
    if spec['shape']=='circle':
        distance=float(np.linalg.norm(np.clip(np.zeros(2),lo,hi)))
        outside=distance>spec['outer'][0]+margin+1e-12
        return dict(outside=bool(outside),method='whole_object_local_aabb_circle',
            distance_lower_bound_m=distance,margin_m=margin)
    axis_gap=np.maximum(lo-spec['outer'],-spec['outer']-hi)
    # A subtraction such as .062-.060 can exceed exactly .002 by ~2e-18.
    # The tolerance is conservative: it requires MORE than the margin, never
    # accepts a point on or inside the 2 mm boundary as exterior.
    return dict(outside=bool(np.any(axis_gap>margin+1e-12)),
        method='whole_object_local_aabb_outer_rectangle',axis_gap_m=axis_gap.tolist(),margin_m=margin)


def outer_world_aabb(geometry):
    spec=validate_geometry(geometry)
    corners=np.array(list(itertools.product(*zip(-spec['outer'],spec['outer']))))
    corners=corners@spec['rotation'].T+spec['center']
    return corners.min(0),corners.max(0)


def container_spacing(first,second,*,required_gap=.05):
    """Conservative lower bound; exact for these unrotated, X-separated boxes."""
    required_gap=float(required_gap)
    if not np.isfinite(required_gap) or required_gap<.05:
        raise ValueError('Container clearance cannot relax the 50mm requirement')
    a=validate_geometry(first);b=validate_geometry(second)
    if a['shape']==b['shape']=='circle':
        gap=float(np.linalg.norm(a['center']-b['center'])-a['outer'][0]-b['outer'][0])
        method='exact_circle_distance'
    else:
        alo,ahi=outer_world_aabb(first);blo,bhi=outer_world_aabb(second)
        axis_gap=np.maximum(alo-bhi,blo-ahi)
        gap=float(np.linalg.norm(np.maximum(axis_gap,0)))
        method='conservative_world_aabb_distance'
    return dict(separation_lower_bound_m=gap,required_gap_m=required_gap,
        passed=bool(gap>=required_gap-1e-12),method=method)


def shallow_rectangle_geometry(center,*,yaw=0.0,base_z=.30):
    center=_finite(center)
    if center.shape!=(2,):raise ValueError('Expected XY center')
    if not np.isfinite(base_z):raise ValueError('Expected finite base height')
    result=dict(footprint_schema=SCHEMA,kind='bowl',shape='rectangle',
        center=[*center,float(base_z)],yaw=float(yaw),inner_half_extents=[.057,.122],
        outer_half_extents=[.060,.125],floor_z=float(base_z+.003),rim_z=float(base_z+.025))
    validate_geometry(result)
    return result


def shallow_rectangle_components():
    """Local native collision boxes, origin at center of bottom surface."""
    return {'floor':dict(center=[0,0,.0015],size=[.12,.25,.003]),
        'near_wall':dict(center=[-.0585,0,.014],size=[.003,.25,.022]),
        'far_wall':dict(center=[.0585,0,.014],size=[.003,.25,.022]),
        'left_wall':dict(center=[0,.1235,.014],size=[.114,.003,.022]),
        'right_wall':dict(center=[0,-.1235,.014],size=[.114,.003,.022])}
