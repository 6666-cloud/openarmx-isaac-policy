"""Canonical English policy text; Chinese is strictly human-display metadata.

The guard is a conservative ASCII English-contract check, not a general language
detector. Approved English wording lives in the catalog below. Never pass the
whole bilingual catalog to a policy: select only the ``en`` string.
"""
import re

POLICY_LANGUAGE = 'en'
LANGUAGE_CONTRACT = 'openarmx_context_en_v1'
CTX12_INSTRUCTIONS = {
    'initial': {
        'en': 'In the order red, blue, then brown, pick up each block, hold it briefly, and return it to its original position.',
        'zh_display': '按红、蓝、棕的顺序，逐个拿起、保持一下，再放回原处。',
    },
    'update': {
        'en': 'For this round only, swap the remaining blue and brown steps: brown first, then blue.',
        'zh_display': '仅这一轮，把剩下的蓝和棕调换顺序，先棕再蓝。',
    },
    'query': {
        'en': 'Continue with the remaining steps.',
        'zh_display': '继续完成剩余步骤。',
    },
}


def require_policy_english(value):
    """Reject blank, non-ASCII or control-character policy instructions.

This deliberately fails closed for Chinese rather than silently translating
unknown instructions. Future tasks must supply reviewed English strings.
    """
    if not isinstance(value, str) or not value.strip() or not value.isascii():
        raise ValueError('Policy instructions must be English-only ASCII text; Chinese is display-only')
    if not re.search(r'[A-Za-z]', value) or any(ord(char) < 32 and char not in '\n\t' for char in value):
        raise ValueError('Invalid English policy instruction')
    return value


def instruction_key(text):
    """Resolve the current palette's reviewed CTX12 English or display strings.

    Historical color wordings are not silently relabelled into the new palette.
    """
    if not isinstance(text, str):
        raise ValueError('Instruction must be a string')
    for key, entry in CTX12_INSTRUCTIONS.items():
        if text == entry['en'] or text.rstrip('。') == entry['zh_display'].rstrip('。'):
            return key
    raise ValueError(f'Unrecognized CTX12 instruction; an explicit reviewed translation is required: {text!r}')


def normalize_ctx12_instruction(text):
    """Explicit migration/display helper, not an automatic model-input translator."""
    return require_policy_english(CTX12_INSTRUCTIONS[instruction_key(text)]['en'])


def display_zh_for_instruction(text):
    """For UI/preview only. Never put the returned value in policy inputs."""
    return CTX12_INSTRUCTIONS[instruction_key(text)]['zh_display']


for _entry in CTX12_INSTRUCTIONS.values():
    require_policy_english(_entry['en'])
