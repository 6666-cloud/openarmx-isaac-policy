"""Read-only raw-video-v2 storage auditor and synchronous RGB source.

This module never imports metadata-named source files, writes recordings, changes
state/action semantics, encodes video, or grants dataset/training acceptance.
"""
from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
from collections import OrderedDict
from copy import deepcopy
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re

import av
import numpy as np
from PIL import Image


SCHEMA = "context_raw_video_v2"
CAMERAS = ("chest", "left_wrist", "right_wrist")
MAX_JSON_BYTES = 1024 * 1024
MAX_ROW_BYTES = 96 * 1024
SHA256 = re.compile(r"^[0-9a-f]{64}$")


class _VideoAuditCache:
    """Ephemeral successes only; never load an on-disk report as a cache entry."""

    def __init__(self, max_entries, keyframe_cache_bytes):
        self.owner_pid = os.getpid()
        self.max_entries = max_entries
        self.entries = {}
        self.metrics = {"full_audits": 0, "verified_reuses": 0, "invalidations": 0}
        self.keyframe_cache_bytes = keyframe_cache_bytes
        self.keyframes = OrderedDict()
        self.keyframe_bytes = 0
        self.keyframe_metrics = {"decoded": 0, "hash_verified_reuses": 0,
                                 "peak_bytes": 0, "budget_bytes": keyframe_cache_bytes}

    def current_process(self):
        # ContextVars may survive fork. Child workers must independently audit.
        return self.owner_pid == os.getpid()


_VIDEO_AUDIT_CACHE = ContextVar("context_video_storage_audit_cache", default=None)


@contextmanager
def video_audit_cache_scope(*, max_entries=8, keyframe_cache_bytes=64 * 1024 * 1024):
    """Reuse full *storage* audits only within this explicit CPU worker scope.

    First use performs the original metadata, PNG, PTS, codec and PSNR audits.
    Every reuse reloads/validates the receipt and hashes ALL audited artifacts,
    including lossless PNGs. Identical bytes permit reuse of the storage result,
    never of physical, pixel, language, mapping or official-reader checks. No
    persistent result is trusted; exiting the scope discards the cache. A new
    independent worker (or nested scope) starts empty. This is an immutable-file
    contract, not an OS writer lock; the original before/after checks remain.

    Independently verified PNG pixels/statistics may also be reused under the
    bounded keyframe budget. Canonical paths and file hashes are rechecked on
    every access, and source-pixel hash/mean/std are part of the cache identity.
    Set keyframe_cache_bytes=0 for the original uncached PNG decode path.
    """
    if type(max_entries) is not int or max_entries < 1:
        raise ValueError("max_entries must be a positive integer")
    if type(keyframe_cache_bytes) is not int or not 0 <= keyframe_cache_bytes <= 128 * 1024 * 1024:
        raise ValueError("keyframe_cache_bytes must be an integer from 0 to 128 MiB")
    cache = _VideoAuditCache(max_entries, keyframe_cache_bytes)
    token = _VIDEO_AUDIT_CACHE.set(cache)
    try:
        yield cache
    finally:
        cache.entries.clear()
        cache.keyframes.clear()
        cache.keyframe_bytes = 0
        _VIDEO_AUDIT_CACHE.reset(token)


class VideoSourceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise VideoSourceError(message)


def sha256_file(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def _integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f"{label}: expected integer >= {minimum}")
    return value


def _digest(value, label):
    require(isinstance(value, str) and SHA256.fullmatch(value) is not None, f"{label}: missing/invalid SHA256")
    return value


def _strict_json(value, label):
    def no_duplicates(pairs):
        result = {}
        for key, item in pairs:
            require(key not in result, f"{label}: duplicate JSON key {key}")
            result[key] = item
        return result
    def no_constant(value):
        raise VideoSourceError(f"{label}: nonfinite JSON number {value}")
    try:
        return json.loads(value, object_pairs_hook=no_duplicates, parse_constant=no_constant)
    except (ValueError, UnicodeError) as error:
        raise VideoSourceError(f"{label}: invalid strict JSON: {error}") from error


def _read_json(path):
    require(path.stat().st_size <= MAX_JSON_BYTES, f"{path.name}: oversized metadata")
    value = _strict_json(path.read_bytes(), path.name)
    require(isinstance(value, dict) and bool(value), f"{path.name}: missing/non-object/empty evidence")
    return value


def _exact_timestamp(origin, frame):
    return origin + round(Fraction(frame * 1_000_000_000, 30))


@dataclass
class SynchronizedVideoFrame:
    frame_id: int
    timestamp_ns: int
    images: dict[str, np.ndarray]
    events: list[dict]
    render_metadata: dict | None
    source_rgb_sha256: dict[str, str]


class VideoEpisodeSource:
    """A finalized prototype directory, NOT a training-approved episode.

    audit() reads and independently validates full storage evidence. An optional
    expected_receipt_sha256 must come from a trusted external episode manifest;
    without it, hashes establish internal consistency, not external provenance.

    iter_synchronized() first audits (unless already audited), then decodes three
    streams in lockstep and yields one current pre-action observation at a time.
    It validates current-event indices; semantic truth of event text is outside
    storage verification. Use immutable/frozen artifacts: hashes are checked
    before and after iteration, not an OS-level concurrent-writer lock.
    """

    def __init__(self, root, *, expected_receipt_sha256=None):
        self.root = Path(root).resolve(strict=True)
        require(self.root.is_dir(), "Episode source is not a directory")
        self.expected_receipt_sha256 = expected_receipt_sha256
        if expected_receipt_sha256 is not None:
            _digest(expected_receipt_sha256, "expected_receipt_sha256")
        self._audit = None
        self._snapshot = None

    def _path(self, relative, *, canonical=None):
        require(isinstance(relative, str) and bool(relative), "Artifact path must be nonempty relative text")
        path = PurePosixPath(relative)
        require(not path.is_absolute() and ".." not in path.parts and "\\" not in relative,
                f"Artifact path escapes episode root: {relative}")
        require(str(path) == relative, f"Artifact path is not canonical: {relative}")
        if canonical is not None:
            require(relative == canonical, f"Noncanonical camera artifact path: {relative}, expected {canonical}")
        local = self.root.joinpath(*path.parts)
        try:
            resolved = local.resolve(strict=True)
        except OSError as error:
            raise VideoSourceError(f"Missing artifact {relative}: {error}") from error
        require(resolved.is_relative_to(self.root), f"Artifact symlink escapes episode root: {relative}")
        require(local.is_file(), f"Artifact is not a regular file: {relative}")
        # A same-root symlink can still disguise one stream as another. Hardlinks
        # to an external export location are fine; aliases among the three views
        # of this episode are rejected separately by inode identity.
        require(resolved == local, f"Artifact symlink aliases another canonical path: {relative}")
        return resolved

    def _load(self):
        require(not (self.root / ".incomplete").exists(), "Recording has .incomplete marker")
        require(not (self.root / "FAILURE.json").exists(), "Recording has FAILURE receipt")
        receipt_path = self._path("FINALIZED.json")
        receipt_hash = sha256_file(receipt_path)
        if self.expected_receipt_sha256 is not None:
            require(receipt_hash == self.expected_receipt_sha256, "External finalized-receipt hash mismatch")
        receipt = _read_json(receipt_path)
        config_path = self._path("recording_config.json")
        config = _read_json(config_path)
        require(receipt.get("schema") == SCHEMA and config.get("schema") == SCHEMA, "Unknown/missing video schema")
        require(receipt.get("status") == "storage_finalized_prototype_not_training_accepted", "Unexpected completion status")
        require(receipt.get("storage_finalized") is True, "Missing affirmative storage-finalization evidence")
        require(receipt.get("training_ready") is False and config.get("training_ready") is False,
                "Prototype storage must not claim training acceptance")
        require(receipt.get("synchronous_input_and_rational_pts_verified") is True, "Missing recorded synchronization evidence")
        require(receipt.get("camera_names") == list(CAMERAS), "Canonical camera names/order mismatch")
        self.count = _integer(receipt.get("frame_count"), "frame_count", 1)
        require(receipt.get("fps") == 30 and type(receipt.get("fps")) is int, "fps must be30")
        self.origin = _integer(receipt.get("source_origin_ns"), "source_origin_ns")
        self.settings = config.get("config")
        require(isinstance(self.settings, dict) and bool(self.settings), "Missing recording settings")
        require(self.settings.get("camera_names") == list(CAMERAS), "Config camera names/order mismatch")
        require((self.settings.get("width"), self.settings.get("height"), self.settings.get("fps")) == (640, 480, 30),
                "Unsupported image geometry/rate")
        require(self.settings.get("pixel_format") == "yuv420p", "Unsupported pixel format")
        blank_limit = self.settings.get("blank_spatial_std_max")
        require(type(blank_limit) in (float, int) and np.isfinite(blank_limit) and blank_limit >= 0, "Missing blank diagnostic threshold")
        self.blank_limit = float(blank_limit)
        require(config.get("source_hash_semantics") == "SHA256 of contiguous source uint8 RGB bytes, before lossy encoding",
                "Source RGB hash semantics missing/changed")
        require(isinstance(receipt.get("videos"), dict) and set(receipt["videos"]) == set(CAMERAS), "Missing/extra video camera evidence")
        require(isinstance(receipt.get("camera_source_statistics"), dict) and set(receipt["camera_source_statistics"]) == set(CAMERAS),
                "Missing/extra source-statistics evidence")
        metadata_path = self._path("frames.jsonl")
        expected = _digest(receipt.get("frames_jsonl_sha256"), "frames_jsonl_sha256")
        require(sha256_file(metadata_path) == expected, "Frame-index JSONL hash mismatch")
        self.receipt, self.config, self.metadata_path = receipt, config, metadata_path
        self._snapshot = {receipt_path: receipt_hash, config_path: sha256_file(config_path), metadata_path: expected}
        self.video_paths = {}
        identities = set()
        for camera in CAMERAS:
            entry = receipt["videos"][camera]
            require(isinstance(entry, dict) and bool(entry), f"{camera}: empty/missing video audit evidence")
            path = self._path(entry.get("path"), canonical=f"videos/{camera}.mp4")
            identity = (path.stat().st_dev, path.stat().st_ino)
            require(identity not in identities, "Multiple camera views alias the same underlying video file")
            identities.add(identity)
            require(entry.get("decoded_frames") == self.count and type(entry.get("decoded_frames")) is int, f"{camera}: receipt frame count mismatch")
            require(entry.get("pts_exactly_verified") is True, f"{camera}: missing recorded PTS verification")
            require(entry.get("codec") == "h264" and entry.get("pixel_format") == "yuv420p", f"{camera}: incompatible recorded codec")
            require(_integer(entry.get("bytes"), f"{camera}.bytes", 1) == path.stat().st_size, f"{camera}: video size mismatch")
            digest = _digest(entry.get("sha256"), f"{camera}.sha256")
            require(sha256_file(path) == digest, f"{camera}: video SHA256 mismatch")
            time_base = entry.get("stream_time_base")
            require(isinstance(time_base, dict), f"{camera}: missing stream timebase")
            _integer(time_base.get("numerator"), f"{camera}.timebase.numerator", 1)
            _integer(time_base.get("denominator"), f"{camera}.timebase.denominator", 1)
            self.video_paths[camera] = path
            self._snapshot[path] = digest

    def _rows(self):
        with self.metadata_path.open("rb") as handle:
            for index in range(self.count):
                line = handle.readline(MAX_ROW_BYTES + 1)
                require(0 < len(line) <= MAX_ROW_BYTES and line.endswith(b"\n"), f"Frame{index}: truncated/missing/oversized JSONL row")
                row = _strict_json(line, f"frame{index}")
                require(isinstance(row, dict), f"Frame{index}: non-object metadata")
                yield index, row
            require(handle.read(1) == b"", "Extra frame-index records after declared episode end")

    def _validate_row(self, index, row):
        require(row.get("schema") == SCHEMA, f"Frame{index}: schema mismatch")
        require(_integer(row.get("frame_id"), "frame_id") == index, f"Frame{index}: noncontiguous frame index")
        timestamp = _integer(row.get("timestamp_ns"), "timestamp_ns")
        require(timestamp == _exact_timestamp(self.origin, index), f"Frame{index}: observation timestamp lattice mismatch")
        require(row.get("video_time") == {"numerator": index, "denominator": 30}, f"Frame{index}: video-time binding mismatch")
        require(isinstance(row.get("cameras"), dict) and set(row["cameras"]) == set(CAMERAS), f"Frame{index}: missing/extra cameras")
        events = row.get("events")
        require(isinstance(events, list) and len(events) <= 64, f"Frame{index}: invalid/missing current events")
        for event in events:
            require(isinstance(event, dict) and event.get("kind") in ("instruction", "grasp", "release", "annotation"), f"Frame{index}: invalid event")
            require(_integer(event.get("frame_id"), "event.frame_id") == index, f"Frame{index}: future or retroactive event frame")
            require(self.origin <= _integer(event.get("timestamp_ns"), "event.timestamp_ns") <= timestamp, f"Frame{index}: event has not arrived yet")
        render = row.get("render_metadata")
        require(render is None or (isinstance(render, dict) and set(render).issubset(CAMERAS)), f"Frame{index}: invalid render metadata")
        if render is not None:
            for entry in render.values():
                require(isinstance(entry, dict), f"Frame{index}: invalid render entry")
                for key in ("frame_id", "timestamp_ns"):
                    if key in entry:
                        _integer(entry[key], f"render.{key}")
        reasons = (["initial"] if index == 0 else []) + [event["kind"] for event in events]
        for camera in CAMERAS:
            entry = row["cameras"][camera]
            require(isinstance(entry, dict) and bool(entry), f"Frame{index}/{camera}: empty RGB evidence")
            _digest(entry.get("source_rgb_sha256"), f"Frame{index}/{camera}.source_rgb_sha256")
            for field in ("mean_rgb", "spatial_std_rgb"):
                value = entry.get(field)
                require(isinstance(value, list) and len(value) == 3 and all(type(v) in (float, int) and np.isfinite(v) and 0 <= v <= 255 for v in value),
                        f"Frame{index}/{camera}: invalid {field}")
            require(type(entry.get("nearly_blank")) is bool and type(entry.get("identical_to_previous_source_frame")) is bool,
                    f"Frame{index}/{camera}: missing typed quality flags")
            require(entry["nearly_blank"] == (max(entry["spatial_std_rgb"]) <= self.blank_limit), f"Frame{index}/{camera}: source blank metric inconsistency")
            if reasons:
                keyframe = entry.get("lossless_keyframe")
                require(isinstance(keyframe, dict) and bool(keyframe), f"Frame{index}/{camera}: missing required initial/event lossless keyframe")
                require(keyframe.get("reasons") == reasons, f"Frame{index}/{camera}: keyframe event binding mismatch")
                self._path(keyframe.get("path"), canonical=f"keyframes/{camera}/frame_{index:09d}.png")
                _digest(keyframe.get("file_sha256"), f"Frame{index}/{camera}.PNG hash")
            else:
                require("lossless_keyframe" not in entry, f"Frame{index}/{camera}: unexplained/future-selected keyframe")

    def _verify_png(self, index, camera, entry):
        keyframe = entry.get("lossless_keyframe")
        if keyframe is None:
            return None
        path = self._path(keyframe["path"], canonical=f"keyframes/{camera}/frame_{index:09d}.png")
        require(sha256_file(path) == keyframe["file_sha256"], f"Frame{index}/{camera}: PNG file hash mismatch")
        # Bind every decoded keyframe too, so a later audit reuse / iterator
        # cannot overlook a PNG modification after the full audit completed.
        self._snapshot[path] = keyframe["file_sha256"]
        cache = _VIDEO_AUDIT_CACHE.get()
        if cache is not None and not cache.current_process():
            cache = None
        # Share only a verified decode/proof for identical bytes and metadata.
        # Path validation and the actual PNG SHA above run on EVERY invocation;
        # this never uses size/mtime as an integrity shortcut. A zero budget
        # selects the original decode/statistics path for paired benchmarks.
        proof_key = (path, keyframe["file_sha256"], entry["source_rgb_sha256"],
                     tuple(entry["mean_rgb"]), tuple(entry["spatial_std_rgb"]))
        if cache is not None and proof_key in cache.keyframes:
            pixels = cache.keyframes.pop(proof_key)
            cache.keyframes[proof_key] = pixels
            cache.keyframe_metrics["hash_verified_reuses"] += 1
            return pixels
        with Image.open(path) as image:
            require(image.format == "PNG" and image.mode == "RGB" and image.size == (640, 480), f"Frame{index}/{camera}: invalid lossless PNG geometry/mode")
            pixels = np.asarray(image).copy()
        digest = hashlib.sha256(memoryview(np.ascontiguousarray(pixels))).hexdigest()
        require(digest == entry["source_rgb_sha256"], f"Frame{index}/{camera}: PNG does not match original source RGB hash")
        flattened = pixels.reshape(-1, 3)
        require(np.allclose(flattened.mean(axis=0), entry["mean_rgb"], rtol=0, atol=1e-5)
                and np.allclose(flattened.std(axis=0), entry["spatial_std_rgb"], rtol=0, atol=1e-5),
                f"Frame{index}/{camera}: lossless PNG disagrees with recorded source pixel metrics")
        if cache is not None:
            cache.keyframe_metrics["decoded"] += 1
            if pixels.nbytes <= cache.keyframe_cache_bytes:
                while cache.keyframes and cache.keyframe_bytes + pixels.nbytes > cache.keyframe_cache_bytes:
                    _, expired = cache.keyframes.popitem(last=False)
                    cache.keyframe_bytes -= expired.nbytes
                pixels.setflags(write=False)
                cache.keyframes[proof_key] = pixels
                cache.keyframe_bytes += pixels.nbytes
                cache.keyframe_metrics["peak_bytes"] = max(cache.keyframe_metrics["peak_bytes"],
                                                          cache.keyframe_bytes)
        return pixels

    def _metadata_audit(self):
        previous = {camera: None for camera in CAMERAS}
        stats = {camera: dict(input_frames=0, nearly_blank_frames=0, consecutive_duplicate_frames=0,
                              identical_run=0, longest_identical_run=0, lossless_keyframes=0) for camera in CAMERAS}
        event_count = 0
        for index, row in self._rows():
            self._validate_row(index, row)
            event_count += len(row["events"])
            for camera in CAMERAS:
                entry, count = row["cameras"][camera], stats[camera]
                duplicate = previous[camera] == entry["source_rgb_sha256"]
                require(entry["identical_to_previous_source_frame"] == duplicate, f"Frame{index}/{camera}: duplicate hash flag mismatch")
                previous[camera] = entry["source_rgb_sha256"]
                count["input_frames"] += 1
                count["nearly_blank_frames"] += int(entry["nearly_blank"])
                count["consecutive_duplicate_frames"] += int(duplicate)
                count["identical_run"] = count["identical_run"] + 1 if duplicate else 1
                count["longest_identical_run"] = max(count["longest_identical_run"], count["identical_run"])
                if self._verify_png(index, camera, entry) is not None:
                    count["lossless_keyframes"] += 1
        for camera in CAMERAS:
            recorded_stats = self.receipt["camera_source_statistics"][camera]
            require(isinstance(recorded_stats, dict) and set(recorded_stats) == set(stats[camera])
                    and all(type(value) is int and value >= 0 for value in recorded_stats.values()),
                    f"{camera}: missing/invalid typed source counters")
            require(self.receipt["camera_source_statistics"][camera] == stats[camera], f"{camera}: receipt source-statistics mismatch/empty evidence")
            require(self.receipt["videos"][camera].get("keyframe_quality_samples") == stats[camera]["lossless_keyframes"], f"{camera}: receipt keyframe count mismatch")
        return {"records_verified": self.count, "events_verified_for_current_frame": event_count,
                "source_statistics_recomputed_from_index": stats,
                "source_rgb_hash_scope": "All rows have valid hash syntax; only lossless PNG frames permit exact source pixel hash re-verification. Lossy videos cannot recover hashes for remaining source RGB frames."}

    def _open_video(self, stack, camera):
        container = stack.enter_context(av.open(str(self.video_paths[camera]), mode="r"))
        require(len(container.streams.video) == 1 and len(container.streams.audio) == 0, f"{camera}: unsupported stream inventory")
        stream = container.streams.video[0]
        stream.codec_context.thread_count = 1
        require(stream.codec_context.name == "h264" and stream.codec_context.format.name == "yuv420p", f"{camera}: actual codec/pixel format mismatch")
        require(stream.width == 640 and stream.height == 480, f"{camera}: actual video dimensions mismatch")
        require(stream.average_rate == Fraction(30, 1), f"{camera}: actual frame rate mismatch")
        time_base = self.receipt["videos"][camera]["stream_time_base"]
        require(stream.time_base == Fraction(time_base["numerator"], time_base["denominator"]), f"{camera}: actual timebase mismatch")
        return container.decode(stream)

    def _next_frame(self, decoder, camera, index):
        try:
            frame = next(decoder)
        except StopIteration as error:
            raise VideoSourceError(f"{camera}: decoded stream ended before frame{index}") from error
        require(frame.width == 640 and frame.height == 480, f"{camera}: decoded frame dimensions changed")
        require(frame.pts is not None and frame.time_base is not None and Fraction(frame.pts) * frame.time_base == Fraction(index, 30),
                f"{camera}: decoded PTS does not equal frame_id/30 at frame{index}")
        return frame

    @staticmethod
    def _require_end(decoder, camera):
        try:
            next(decoder)
        except StopIteration:
            return
        raise VideoSourceError(f"{camera}: extra decoded frames beyond declared end")

    def _video_audit(self, camera):
        samples, worst_psnr = 0, None
        with ExitStack() as stack:
            decoder = self._open_video(stack, camera)
            for index, row in self._rows():
                frame = self._next_frame(decoder, camera, index)
                original = self._verify_png(index, camera, row["cameras"][camera])
                if original is not None:
                    decoded = frame.to_ndarray(format="rgb24").astype(np.float32)
                    mse = float(np.mean((decoded - original.astype(np.float32)) ** 2))
                    psnr = None if mse == 0 else float(10 * np.log10(255 ** 2 / mse))
                    if psnr is not None:
                        worst_psnr = psnr if worst_psnr is None else min(worst_psnr, psnr)
                    samples += 1
            self._require_end(decoder, camera)
        recorded = self.receipt["videos"][camera].get("worst_finite_keyframe_psnr_db", "missing")
        if worst_psnr is None:
            require(recorded is None, f"{camera}: source/decode quality evidence missing or inconsistent")
        else:
            require(type(recorded) in (float, int) and np.isfinite(recorded) and abs(recorded - worst_psnr) < 1e-5,
                    f"{camera}: recorded PSNR evidence missing or inconsistent")
        return {"canonical_path": f"videos/{camera}.mp4", "actual_sha256": self._snapshot[self.video_paths[camera]],
                "actual_frames_decoded": self.count, "exact_rational_pts_verified": True,
                "lossless_keyframes_checked": samples, "recomputed_worst_finite_keyframe_psnr_db": worst_psnr}

    def _check_snapshot(self):
        require(not (self.root / ".incomplete").exists() and not (self.root / "FAILURE.json").exists(), "Source became incomplete/failed")
        for path, expected in self._snapshot.items():
            self._path(str(path.relative_to(self.root)))
            require(sha256_file(path) == expected, f"Artifact changed during/after audit: {path.name}")

    def audit(self):
        self._audit = None
        cache = _VIDEO_AUDIT_CACHE.get()
        if cache is not None and not cache.current_process():
            cache = None
        cache_key = (self.root, self.expected_receipt_sha256)
        try:
            self._load()
            if cache is not None and cache_key in cache.entries:
                snapshot, report = cache.entries[cache_key]
                # _load() has independently revalidated the whole receipt,
                # canonical paths, camera inode identities and video hashes.
                # A self-consistent new recording is a miss, not a stale pass.
                if all(snapshot.get(path) == digest for path, digest in self._snapshot.items()):
                    self._snapshot = dict(snapshot)
                    try:
                        self._check_snapshot()
                    except (OSError, VideoSourceError):
                        cache.entries.pop(cache_key, None)
                        cache.metrics["invalidations"] += 1
                        raise
                    cache.metrics["verified_reuses"] += 1
                    self._audit = deepcopy(report)
                    return self._audit
                cache.entries.pop(cache_key, None)
                cache.metrics["invalidations"] += 1
            metadata = self._metadata_audit()
            videos = {camera: self._video_audit(camera) for camera in CAMERAS}
            self._check_snapshot()
        except VideoSourceError:
            raise
        except (OSError, ValueError, KeyError, TypeError, av.FFmpegError) as error:
            raise VideoSourceError(f"Storage evidence validation failed: {type(error).__name__}: {error}") from error
        hashes = [videos[camera]["actual_sha256"] for camera in CAMERAS]
        self._audit = {
            "schema": "context_raw_video_v2_independent_storage_audit_v1",
            "root": str(self.root), "storage_integrity_passed": True,
            "dataset_quality_passed": False, "dataset_quality_status": "not_evaluated",
            "training_ready": False, "frame_count": self.count, "fps": 30,
            "camera_names": list(CAMERAS), "metadata": metadata, "videos": videos,
            "finalized_receipt_sha256": self._snapshot[self.root / "FINALIZED.json"],
            "recording_config_sha256": self._snapshot[self.root / "recording_config.json"],
            "frame_index_sha256": self._snapshot[self.metadata_path],
            "external_receipt_anchor_verified": self.expected_receipt_sha256 is not None,
            "identical_camera_video_hashes": len(set(hashes)) < len(hashes),
            "identical_camera_content_policy": "Distinct canonical files may have identical hashes; this is a quality flag, not proof of correct camera poses.",
            "not_verified": ["physical/task success", "state/action/contact alignment", "English instruction semantic truth",
                             "real camera/action calibration", "paired benchmark quality", "official LeRobot compatibility",
                             "source RGB identities without lossless PNG or original pixels"],
        }
        if cache is not None:
            if len(cache.entries) >= cache.max_entries:
                cache.entries.pop(next(iter(cache.entries)))
            cache.entries[cache_key] = (dict(self._snapshot), deepcopy(self._audit))
            cache.metrics["full_audits"] += 1
        return self._audit

    def iter_synchronized(self, *, rgb_indices=None):
        """Validate/decode every frame; optionally materialize RGB only at indices.

        The sparse mode yields every frame, with an empty ``images`` mapping at
        unselected indices. It skips RGB conversion only: PTS, end-of-stream,
        JSONL, lossless PNG integrity and before/after hashes are unchanged.
        """
        if self._audit is None:
            self.audit()
        if rgb_indices is not None:
            rgb_indices = frozenset(rgb_indices)
            require(all(type(i) is int and 0 <= i < self.count for i in rgb_indices),
                    "RGB selection outside recorded frame range")
        self._check_snapshot()
        with ExitStack() as stack:
            decoders = {camera: self._open_video(stack, camera) for camera in CAMERAS}
            for index, row in self._rows():
                self._validate_row(index, row)
                images = {}
                for camera in CAMERAS:
                    frame = self._next_frame(decoders[camera], camera, index)
                    if rgb_indices is None or index in rgb_indices:
                        images[camera] = frame.to_ndarray(format="rgb24")
                    self._verify_png(index, camera, row["cameras"][camera])
                yield SynchronizedVideoFrame(index, row["timestamp_ns"], images,
                    row["events"], row["render_metadata"],
                    {camera: row["cameras"][camera]["source_rgb_sha256"] for camera in CAMERAS})
            for camera in CAMERAS:
                self._require_end(decoders[camera], camera)
        self._check_snapshot()
