"""Pure-CPU physics-step clock guard; not yet integrated with the collector.

The authoritative count is an integer engine step index, with exact decimation
and sequential control-frame indices. Seconds are independently checked against
the explicitly measured, constant physics callback step_size. A nominal getter
is not a callback measurement. This helper never changes camera tolerances,
logical dataset timestamps, physics dt, or an engine's time/step state.
"""
import math
import numbers
import struct
import sys

SCHEMA = 'context_physics_clock_candidate_v1'
_UNIT_ROUNDOFF = sys.float_info.epsilon / 2
_SECONDS_FLOOR = 1e-9


class PhysicsClockError(RuntimeError):
    """Clock discontinuity or unverified model; do not record the frame."""


def _integer(value, name, *, minimum=0):
    if isinstance(value, bool) or not isinstance(value, numbers.Integral) or value < minimum:
        raise ValueError(name+' must be an integer >= '+str(minimum))
    return int(value)


def _number(value, name, *, positive=False):
    if isinstance(value, bool) or not isinstance(value,numbers.Real):
        raise ValueError(name+' must be a finite numeric scalar')
    result=float(value)
    if not math.isfinite(result) or (positive and result<=0):
        raise ValueError(name+' must be finite'+(' and positive' if positive else ''))
    return result


def _float32(value):
    try:
        return struct.unpack('!f',struct.pack('!f',value))[0]
    except (OverflowError,struct.error) as error:
        raise ValueError('Nominal dt is not representable as finite float32') from error


def validate_callback_step_samples(step_sizes, *, nominal_dt, minimum_samples=8):
    """Verify actual callback observations; does not infer dt from timestamps.

    Register a passive physics callback during existing warmup, collect its
    step_size arguments, remove it after warmup, and pass the values here.
    Only the requested binary64 dt or its binary32 quantization is recognized.
    No per-frame clock fitting or automatic acceptance of changed dt is allowed.
    """
    nominal=_number(nominal_dt,'nominal_dt',positive=True)
    minimum=_integer(minimum_samples,'minimum_samples',minimum=8)
    try:
        values=[_number(value,'callback step_size',positive=True) for value in step_sizes]
    except TypeError as error:
        raise ValueError('Callback samples must be an iterable of numeric values') from error
    if len(values)<minimum:
        raise ValueError('At least '+str(minimum)+' actual callback samples are required')
    if any(value!=values[0] for value in values):
        raise PhysicsClockError('Physics callback step_size changed during the probe')
    if values[0] not in (nominal,_float32(nominal)):
        raise PhysicsClockError('Measured callback dt does not match nominal64 or nominal float32 quantization')
    return {'engine_step_dt':values[0], 'nominal_dt':nominal,
            'sample_count':len(values),
            'model':'exact_nominal64' if values[0]==nominal else 'nominal_quantized_float32',
            'source':'measured_physics_callback_step_size', 'constant_samples_verified':True}


def _accumulation_error_bound(step_index, step_dt):
    # Standard gamma_n bound for n nonnegative binary64 additions from zero.
    # Include one product-rounding term for step_index*dt used in the check.
    nu=step_index*_UNIT_ROUNDOFF
    if nu>=.01:
        raise PhysicsClockError('Clock step count exceeds the bounded binary64 error model')
    magnitude=step_index*step_dt
    return nu/(1-nu)*magnitude+_UNIT_ROUNDOFF*abs(magnitude)


class PhysicsClockGuard:
    """Validate pre-action boundaries in order, without advancing any clock.

    The engine in scope resets both seconds and its integer step index to zero
    together. ``start_*`` must be one snapshot taken after warmup; an arbitrary
    independent wall-clock offset is not accepted. ``callback_probe`` comes
    from validate_callback_step_samples, not world.get_physics_dt().
    """
    def __init__(self, *, nominal_dt, substeps, fps, start_step, start_time, callback_probe):
        self.nominal_dt=_number(nominal_dt,'nominal_dt',positive=True)
        self.substeps=_integer(substeps,'substeps',minimum=1)
        self.fps=_integer(fps,'fps',minimum=1)
        if not math.isclose(self.nominal_dt*self.substeps,1/self.fps,rel_tol=0,abs_tol=1e-15):
            raise ValueError('Nominal dt, decimation and control fps disagree')
        self.start_step=_integer(start_step,'start_step')
        self.start_time=_number(start_time,'start_time')
        if self.start_time<0:
            raise ValueError('start_time must be nonnegative')
        if not isinstance(callback_probe,dict):
            raise ValueError('An explicit measured callback probe is required')
        if callback_probe.get('source')!='measured_physics_callback_step_size' or callback_probe.get('constant_samples_verified') is not True:
            raise ValueError('Callback probe source is not verified measurement')
        count=_integer(callback_probe.get('sample_count'),'callback sample count',minimum=8)
        actual=_number(callback_probe.get('engine_step_dt'),'engine_step_dt',positive=True)
        # Revalidate the metadata without allocating memory proportional to a
        # caller-supplied count. The observations themselves were validated by
        # validate_callback_step_samples at the measured warmup boundary.
        probe=validate_callback_step_samples([actual]*8,nominal_dt=self.nominal_dt)
        probe['sample_count']=count
        if callback_probe!=probe:
            raise ValueError('Callback probe metadata disagrees with the explicit clock model')
        self.probe=dict(probe)
        self.engine_step_dt=actual
        self.max_seconds_tolerance=min(self.nominal_dt/1000,1e-5)
        self._next_frame=0
        # Establish engine clock origin once; do not fit the start offset to a
        # corrupted counter/time pair or refit it on each subsequent frame.
        tolerance=self._absolute_tolerance(self.start_step)
        if abs(self.start_time-self.start_step*self.engine_step_dt)>tolerance:
            raise PhysicsClockError('Start step/time snapshot disagrees with the measured callback clock')

    def _bounded(self,value):
        if not math.isfinite(value) or value>self.max_seconds_tolerance:
            raise PhysicsClockError('Double-roundoff bound exceeds strict clock budget; a new verified epoch is required')
        return value

    def _absolute_tolerance(self,step):
        return self._bounded(_SECONDS_FLOOR+_accumulation_error_bound(step,self.engine_step_dt))

    def check(self, frame_index, engine_step_index, engine_time):
        frame=_integer(frame_index,'frame_index')
        step=_integer(engine_step_index,'engine_step_index')
        seconds=_number(engine_time,'engine_time')
        if frame!=self._next_frame:
            raise PhysicsClockError('Control frame was dropped, duplicated or reordered')
        expected_step=self.start_step+frame*self.substeps
        if step!=expected_step:
            raise PhysicsClockError('Engine step index violates exact control decimation')
        absolute_expected=step*self.engine_step_dt
        absolute_tolerance=self._absolute_tolerance(step)
        absolute_error=seconds-absolute_expected
        if abs(absolute_error)>absolute_tolerance:
            raise PhysicsClockError('Engine seconds disagree with the explicit constant callback dt')
        elapsed=seconds-self.start_time
        expected_elapsed=(step-self.start_step)*self.engine_step_dt
        relative_tolerance=self._bounded(_SECONDS_FLOOR
            +_accumulation_error_bound(step,self.engine_step_dt)
            +_accumulation_error_bound(self.start_step,self.engine_step_dt)
            +_UNIT_ROUNDOFF*(abs(seconds)+abs(self.start_time)+abs(expected_elapsed)))
        residual=elapsed-expected_elapsed
        if abs(residual)>relative_tolerance:
            raise PhysicsClockError('Elapsed physics seconds disagree with the verified start snapshot')
        self._next_frame+=1
        return {'frame_index':frame,'engine_step_index':step,'expected_engine_step_index':expected_step,
                'logical_time_s':frame/self.fps,'engine_elapsed_time_s':elapsed,
                'expected_engine_elapsed_time_s':expected_elapsed,
                'nominal_quantization_drift_s':expected_elapsed-frame/self.fps,
                'absolute_clock_residual_s':absolute_error,'elapsed_clock_residual_s':residual,
                'absolute_tolerance_s':absolute_tolerance,'elapsed_tolerance_s':relative_tolerance,
                'camera_alignment_validated':False}

    def metadata(self):
        return {'schema':SCHEMA,'nominal_dt':self.nominal_dt,'substeps':self.substeps,'fps':self.fps,
                'start_step':self.start_step,'start_time':self.start_time,'callback_probe':dict(self.probe),
                'clock_origin':'engine resets time and step index together to zero',
                'roundoff_model':'binary64 positive-sum gamma_n plus subtraction/product roundoff',
                'seconds_floor_s':_SECONDS_FLOOR,'maximum_seconds_tolerance_s':self.max_seconds_tolerance,
                'exact_step_decimation_required':True,'consecutive_control_frames_required':True,
                'dataset_timestamps_remain_frame_over_fps':True,'camera_tolerances_changed':False,
                'collector_integration_validated':False}
