"""Operator-only Isaac UI; never supplies pixels or labels to the recorder.

This module is CPU-importable. SDK imports happen only when a GUI collector
explicitly creates the panel. It does not step physics, render, or move bodies.
"""


def status_text(task, variant, pair_id, frame=0, phase='initializing', instruction=''):
    return (f'{task} / {variant}    {pair_id}\n'
            f'Frame {frame}   |   {phase}\n'
            f'{instruction or "Preparing scene and cameras..."}')


class LiveCollectionView:
    def __init__(self, task, variant, pair_id):
        import omni.ui as ui
        from omni.kit.viewport.utility import get_active_viewport
        from omni.kit.window.title import get_main_window_title

        self.task, self.variant, self.pair_id = task, variant, pair_id
        viewport = get_active_viewport()
        if viewport is None:
            raise RuntimeError('GUI requested but no active Isaac viewport is available')
        # This observer camera is separate from all three recorded camera prims.
        viewport.camera_path = '/world/OverviewCamera'
        self.title = get_main_window_title()
        self.title.set_title(f'OpenArmX LIVE collection | {task} {variant}')
        self.window = ui.Window('Collection status (operator only)', width=410, height=170)
        with self.window.frame:
            with ui.VStack(spacing=6):
                self.label = ui.Label(status_text(task, variant, pair_id), word_wrap=True)
                ui.Label('LIVE physics, not playback. Minimize to keep collecting.\n'
                         'Do not move objects or use Play / Stop during recording.',
                         word_wrap=True, style={'color': 0xFF88CCFF})
        # Keep the status panel off the robot/table view. A custom user layout
        # without Stage falls back to the right side of the desktop window.
        if not self.window.dock_in_window('Stage', ui.DockPosition.BOTTOM, .35):
            self.window.setPosition(1000, 80)

    def update(self, frame, phase, instruction):
        self.label.text = status_text(self.task, self.variant, self.pair_id,
                                      frame, phase, instruction)
        self.title.set_title(f'OpenArmX LIVE | {self.task} {self.variant} | {phase} | frame {frame}')
