"""CPU-only verification of fixed, pre-episode camera warmup observations.

Integration: after the rig is initialized and robot settling has completed,
repeat exactly 60 times: hold targets, advance eight physics steps, render,
capture(require_new=True, expected_time=world.current_time), then call observe.
After finalize succeeds, define episode t=0 from the current engine snapshot;
the last capture may be the initial pre-action observation. Save this report
outside policy inputs. No already-recorded episode frames may be dropped.

The caller owns physics stepping/rendering. This module does neither and cannot
certify the caller's eight-step schedule. SDK NEW_FRAME can update frequency=-1
cameras even at static time: no stale-buffer or RTX root cause is assumed here.
"""
from collections.abc import Mapping
from copy import deepcopy
import hashlib
import math
import numbers

import numpy as np

CAMERAS = ('chest', 'left_wrist', 'right_wrist')
REQUIRED_CAPTURES = 60
STABLE_TRANSITIONS = 5
MAX_ADJACENT_MAE_UINT8 = 0.75
MIN_IMAGE_STD_UINT8 = 1.0
TIME_TOLERANCE_S = 1e-4
SCHEMA = 'context_camera_warmup_v1'


class CameraWarmupError(RuntimeError):
    """Do not start recording an episode from this warmup attempt."""


def _integer(value, name, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Integral) or value < minimum:
        raise ValueError(name + ' must be an integer >= ' + str(minimum))
    return int(value)


def _number(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Real):
        raise ValueError(name + ' must be a finite numeric scalar')
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise ValueError(name + ' must be finite and nonnegative')
    return result


class CameraWarmupGuard:
    """Fail-closed streaming gate with one previous RGB frame per camera.

    Only resolution is configurable for small synthetic CPU tests. Production
    defaults are 640x480, exactly three canonical cameras, 60 new captures, and
    <=.75 uint8 MAE for each of the final five adjacent transitions per camera.
    A new timestamp/frame with identical static RGB is legitimate (MAE zero);
    duplicated/non-progressing frame IDs or times are always rejected.
    """
    def __init__(self, *, resolution_wh=(640, 480)):
        if not isinstance(resolution_wh, (tuple, list)) or len(resolution_wh) != 2:
            raise ValueError('resolution_wh must contain width and height')
        self.resolution_wh = tuple(_integer(v, 'resolution dimension', 1) for v in resolution_wh)
        self._previous = {}
        self._records = []
        self._failure = None
        self._final = None

    def _reject(self, message):
        self._failure = message
        raise CameraWarmupError(message)

    def observe(self, captures, *, expected_engine_time):
        """Accept one complete simultaneous capture, never a render call count.

        Input entries use ContextCameraRig.capture's rgb, rendering_frame,
        rendering_time and world_pose_wxyz keys. Returns small metadata only.
        Invalid input poisons this attempt; it cannot be skipped/retried into
        an apparent 60-frame pass. Create a new guard for a new attempt.
        """
        if self._final is not None:
            raise CameraWarmupError('Warmup already finalized; no extra captures allowed')
        if self._failure is not None:
            raise CameraWarmupError('Warmup already rejected: ' + self._failure)
        try:
            return self._observe(captures, expected_engine_time)
        except (ValueError, TypeError, KeyError, CameraWarmupError) as error:
            self._failure = str(error)
            raise CameraWarmupError(str(error)) from error

    def _observe(self, captures, expected_engine_time):
        if len(self._records) >= REQUIRED_CAPTURES:
            self._reject('More than 60 warmup captures supplied')
        engine_time = _number(expected_engine_time, 'expected_engine_time')
        if self._records and engine_time <= self._records[-1]['expected_engine_time_s']:
            self._reject('Engine time did not strictly advance between warmup captures')
        if not isinstance(captures, Mapping) or set(captures) != set(CAMERAS):
            self._reject('Warmup requires exactly chest, left_wrist and right_wrist')
        width, height = self.resolution_wh
        records, frames, times, arrays = {}, [], [], {}
        for name in CAMERAS:
            entry = captures[name]
            if not isinstance(entry, Mapping):
                self._reject(name + ': capture entry must be a mapping')
            frame = _integer(entry['rendering_frame'], name + ' rendering_frame')
            timestamp = _number(entry['rendering_time'], name + ' rendering_time')
            if self._records:
                previous = self._records[-1]['cameras'][name]
                if frame <= previous['rendering_frame'] or timestamp <= previous['rendering_time_s']:
                    self._reject(name + ': duplicate or non-progressing render frame/time')
            if abs(timestamp - engine_time) > TIME_TOLERANCE_S:
                self._reject(name + ': camera time differs from expected engine time')
            rgb = entry['rgb']
            if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.shape != (height, width, 3):
                self._reject(name + ': expected uint8 HWC RGB at the configured resolution')
            pose = np.asarray(entry['world_pose_wxyz'])
            if pose.shape != (7,) or pose.dtype.kind not in 'fiu' or not np.isfinite(pose).all():
                self._reject(name + ': invalid finite world pose')
            pose = pose.astype(np.float64)
            if abs(float(np.linalg.norm(pose[3:])) - 1.0) > 1e-3:
                self._reject(name + ': camera quaternion is not unit length')
            image_std = float(rgb.std())
            spatial_std = float(rgb.std(axis=(0, 1)).mean())
            if image_std < MIN_IMAGE_STD_UINT8 or spatial_std < MIN_IMAGE_STD_UINT8:
                self._reject(name + ': nearly blank image')
            mae = (float(np.abs(rgb.astype(np.int16) - self._previous[name].astype(np.int16)).mean())
                   if name in self._previous else None)
            records[name] = {'rendering_frame': frame, 'rendering_time_s': timestamp,
                'engine_alignment_error_s': timestamp - engine_time,
                'world_pose_wxyz': pose.tolist(),
                'rgb_sha256': hashlib.sha256(np.ascontiguousarray(rgb).tobytes()).hexdigest(),
                'rgb_mean_uint8': float(rgb.mean()), 'rgb_std_uint8': image_std,
                'mean_per_channel_spatial_std_uint8': spatial_std,
                'adjacent_mae_uint8': mae}
            arrays[name] = rgb
            frames.append(frame)
            times.append(timestamp)
        if len(set(frames)) != 1:
            self._reject('Camera render frame IDs are not synchronized')
        if max(times) - min(times) > TIME_TOLERANCE_S:
            self._reject('Camera render times are not synchronized')
        record = {'capture_index': len(self._records), 'expected_engine_time_s': engine_time,
                  'synchronization_spread_s': max(times) - min(times), 'cameras': records}
        # Commit only after all three views pass; retain one owned previous
        # image per camera so callers may safely reuse/mutate their buffers.
        self._previous = {name: arrays[name].copy(order='C') for name in CAMERAS}
        self._records.append(record)
        return deepcopy(record)

    def report(self):
        """Small JSON-safe diagnostics including failures, never RGB or actions."""
        if self._final is not None:
            return deepcopy(self._final)
        return {'schema': SCHEMA, 'passed': False,
            'status': 'rejected' if self._failure is not None else 'collecting_warmup',
            'failure': self._failure, 'successful_new_synchronized_captures': len(self._records),
            'required_captures': REQUIRED_CAPTURES, 'cameras': list(CAMERAS),
            'resolution_wh': list(self.resolution_wh), 'records': deepcopy(self._records),
            'render_call_count_measured': False,
            'render_call_count_is_not_successful_new_capture_count': True,
            'training_frames_created': 0, 'recorded_episode_frames_discarded': 0,
            'time_tolerance_s': TIME_TOLERANCE_S, 'minimum_image_std_uint8': MIN_IMAGE_STD_UINT8,
            'minimum_mean_per_channel_spatial_std_uint8': MIN_IMAGE_STD_UINT8,
            'last_adjacent_transitions_required': STABLE_TRANSITIONS,
            'maximum_adjacent_mae_uint8': MAX_ADJACENT_MAE_UINT8,
            'rgb_storage': 'Only previous one frame per camera; metadata includes per-frame hashes/statistics.',
            'caller_schedule': 'Caller advances eight physics steps then render/capture before episode t0; not independently certified by this helper.',
            'limits': ['Engineering image-stability gate, not a universal RTX-noise or visual-correctness certificate.',
                'SDK frequency=-1 NEW_FRAME callbacks may update with static time; no stale-buffer root cause is asserted.',
                'This helper does not render, step physics, crop images, relabel timestamps or discard t0-and-later data.',
                'Exact repeated static RGB with advancing timestamps/frame IDs is allowed; SHA and zero MAE remain explicit.',
                'Visual identity/geometry/calibration and learned-policy suitability require separate review.']}

    def finalize(self):
        if self._final is not None:
            return deepcopy(self._final)
        if self._failure is not None:
            raise CameraWarmupError('Warmup already rejected: ' + self._failure)
        if len(self._records) != REQUIRED_CAPTURES:
            self._reject('Warmup requires exactly 60 successfully verified new captures')
        final_mae = {name: [r['cameras'][name]['adjacent_mae_uint8']
                           for r in self._records[-STABLE_TRANSITIONS:]] for name in CAMERAS}
        if any(value is None or value > MAX_ADJACENT_MAE_UINT8
               for values in final_mae.values() for value in values):
            self._reject('Last five adjacent transitions are not stable in every camera')
        result = self.report()
        result.update(passed=True, status='verified_pre_episode_engineering_warmup',
                      last_five_adjacent_mae_uint8=final_mae,
                      final_capture_engine_time_s=self._records[-1]['expected_engine_time_s'])
        self._final = result
        return deepcopy(result)
