"""Static, render-only paper labels for the v0.7 tabletop regions.

Labels describe spatial references, never task answers. A tiny bitmap font is
authored as planar ink meshes, so exported scenes have no external texture or
font dependency. No physics APIs, lights, animation, object names, or A/B input.
"""
import numpy as np

SCHEMA = 'context_neutral_paper_markers_v1'
GLYPHS = {
    'N': ('10001','11001','11001','10101','10011','10011','10001'),
    'E': ('11111','10000','10000','11110','10000','10000','11111'),
    'A': ('01110','10001','10001','11111','10001','10001','10001'),
    'R': ('11110','10001','10001','11110','10100','10010','10001'),
    'F': ('11111','10000','10000','11110','10000','10000','10000'),
    'S': ('01111','10000','10000','01110','00001','00001','11110'),
    '1': ('00100','01100','00100','00100','00100','00100','01110'),
    '2': ('01110','10001','00001','00010','00100','01000','11111'),
}


def add_paper_marker(stage, *, path, center, lines, size=.04):
    """Author one matte paper/ink mesh, 0.2 mm above the real tabletop.

    The caller places it OUTSIDE the target region. This does not add support
    geometry or change table friction/collisions. Pixel readability and actual
    grasp clearance remain acceptance checks, not claims made by this author.
    """
    from pxr import Gf, Sdf, UsdGeom, UsdShade, UsdPhysics, Usd
    center = np.asarray(center, dtype=float)
    if center.shape != (3,) or not np.isfinite(center).all() or not 0.02 <= size <= .06:
        raise ValueError('Expected finite XYZ and a 2–6 cm paper marker')
    if not lines or len(lines) > 2 or any(not line or set(line) - set(GLYPHS) for line in lines):
        raise ValueError('Only reviewed static spatial-reference labels are permitted')
    root = UsdGeom.Xform.Define(stage, path)
    UsdGeom.Xformable(root).AddTranslateOp().Set(Gf.Vec3d(*center))

    def mesh(name, squares, color, z):
        points, indices = [], []
        for x0, y0, x1, y1 in squares:
            # Printed text reads toward +X (away from the robot); +Y is left.
            vertices = [(y0, -x0, z), (y0, -x1, z), (y1, -x1, z), (y1, -x0, z)]
            indices.extend(range(len(points), len(points) + 4))
            points.extend(vertices)
        geom = UsdGeom.Mesh.Define(stage, path + '/' + name)
        geom.CreatePointsAttr(points)
        geom.CreateFaceVertexCountsAttr([4] * len(squares))
        geom.CreateFaceVertexIndicesAttr(indices)
        geom.CreateSubdivisionSchemeAttr('none')
        geom.CreateDoubleSidedAttr(True)
        geom.CreateDisplayColorAttr([Gf.Vec3f(*color)])
        material = UsdShade.Material.Define(stage, path + '/Materials/' + name)
        shader = UsdShade.Shader.Define(stage, str(material.GetPath()) + '/Shader')
        shader.CreateIdAttr('UsdPreviewSurface')
        shader.CreateInput('diffuseColor', Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
        shader.CreateInput('roughness', Sdf.ValueTypeNames.Float).Set(1.)
        shader.CreateInput('metallic', Sdf.ValueTypeNames.Float).Set(0.)
        material.CreateSurfaceOutput().ConnectToSource(shader.ConnectableAPI(), 'surface')
        UsdShade.MaterialBindingAPI.Apply(geom.GetPrim()).Bind(material)

    mesh('Paper', [(-size/2, -size/2, size/2, size/2)], (.92, .88, .57), 0.)
    squares = []
    for row, text in enumerate(lines):
        pixel = min(size*.55/(6*len(text)-1), size*(.34 if len(lines) == 1 else .22)/7)
        width = (6*len(text)-1)*pixel
        top = size*.17 if len(lines) == 1 else (size*.30 if row == 0 else -size*.02)
        for index, char in enumerate(text):
            for gy, bits in enumerate(GLYPHS[char]):
                for gx, bit in enumerate(bits):
                    if bit == '1':
                        x = -width/2 + (index*6 + gx)*pixel
                        y = top - (gy+1)*pixel
                        squares.append((x,y,x+pixel,y+pixel))
    mesh('Ink', squares, (.015,.015,.015), .00003)
    for prim in Usd.PrimRange(root.GetPrim()):
        if prim.HasAPI(UsdPhysics.CollisionAPI) or prim.HasAPI(UsdPhysics.RigidBodyAPI):
            raise RuntimeError('Paper labels must never have physics APIs')
    return dict(schema=SCHEMA, path=path, center=center.tolist(), size_m=size,
                text=' / '.join(lines), color='same pale yellow paper with black ink',
                collision_enabled=False, rigid_body=False, dynamic=False,
                branch_input_used=False, answer_highlight=False, texture_dependency=None)
