"""CPU-only USD packaging from a lawful existing asset installation; no simulation.

Flatten composition into a new directory, retain native meshes/joints/colliders,
copy texture dependencies by SHA, and rewrite only file references. Never edits
the source installation. Generated assets are NOT part of the GitHub source.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

KEEP = {'OpenArmX', 'table', 'franka_table', 'GroundPlane', 'Looks', 'PhysicsScene',
        'EnvironmentLight', 'KeyLight', 'OverviewCamera', 'Render'}
ASSETS = ['objects/basic/red_block.usd', 'objects/basic/blue_block.usd',
          'objects/vomp/plate_large/plate_large.usd']


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def native_signature(stage):
    """Exact composed numeric/relationship fingerprint, excluding asset URLs/UI."""
    rows = []
    geometry = {'points', 'normals', 'faceVertexCounts', 'faceVertexIndices', 'extent',
                'size', 'radius', 'height', 'axis', 'subdivisionScheme'}
    for prim in stage.Traverse():
        # Unused material definitions can be pruned without affecting physics.
        if str(prim.GetPath()).startswith('/world/Looks'):
            continue
        attrs = {x.GetName(): str(x.Get()) for x in prim.GetAttributes()
                 if x.GetName().startswith(('physics:', 'physx', 'drive:', 'xformOp'))
                 or x.GetName() in geometry}
        rels = {x.GetName(): [str(v) for v in x.GetTargets()]
                for x in prim.GetRelationships() if x.GetName().startswith(('physics:', 'physx'))}
        if attrs or rels:
            rows.append({'prim': str(prim.GetPath()), 'type': prim.GetTypeName(),
                         'attributes': attrs, 'relationships': rels})
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root', required=True, type=Path,
                   help='Existing project root containing RoboLab/assets and native robot USD')
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    source = a.source_root.resolve(strict=True)
    output = a.output.expanduser().resolve()
    if output == source or output.is_relative_to(source / 'RoboLab'):
        raise ValueError('Output must be separate from source assets')
    from pxr import Sdf, Usd, UsdUtils
    inputs = [(source / 'RoboLab/assets/scenes/openarmx_banana_loop.usda',
               Path('RoboLab/assets/scenes/openarmx_banana_loop.usda'))]
    inputs += [(source / 'RoboLab/assets' / x, Path('RoboLab/assets') / x) for x in ASSETS]
    if not all(x.is_file() for x, _ in inputs):
        raise FileNotFoundError('Missing native CTX01 inputs; see docs/ASSETS.md')
    output.mkdir(parents=True, exist_ok=False)
    # MDL files refer to sibling resources internally. Preserve their directory
    # structure instead of renaming individual modules by digest.
    materials = source / 'RoboLab/assets/materials'
    if not materials.is_dir():
        raise FileNotFoundError('Missing native material library')
    shutil.copytree(materials, output / 'RoboLab/assets/materials')
    observations = []
    for number, (src, relative) in enumerate(inputs):
        stage = Usd.Stage.Open(str(src))
        if not stage:
            raise ValueError('Cannot compose native asset: ' + src.name)
        if number == 0:
            # Author deactivation only on a session layer, never the source layer.
            stage.SetEditTarget(stage.GetSessionLayer())
            world = stage.GetPrimAtPath('/world')
            if not world:
                raise ValueError('Missing /world in source base scene')
            for child in world.GetChildren():
                if child.GetName() not in KEEP:
                    child.SetActive(False)
            for path in ('/world/OpenArmX/root_joint', '/world/table/table_01/top'):
                if not stage.GetPrimAtPath(path):
                    raise ValueError('Native scene structure changed: ' + path)
        before = native_signature(stage)
        layer = stage.Flatten()
        if number == 0:
            # Remove inactive prim specs from the derived layer, not the original.
            flat_stage = Usd.Stage.Open(layer)
            for child in list(flat_stage.GetPrimAtPath('/world').GetAllChildren()):
                if child.GetName() not in KEEP:
                    flat_stage.RemovePrim(child.GetPath())
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        builtin = set()

        def relocate(value):
            if not value:
                return value
            asset = Path(value)
            if asset.name in ('OmniPBR.mdl', 'OmniGlass.mdl') and not asset.is_absolute():
                builtin.add(value)
                return value
            if value.startswith(('http:', 'https:')):
                # Old scene layers contain normalized http:/ asset strings.
                # Resolve only the exact existing native materials, no download.
                if '/Materials/' not in value:
                    raise ValueError('Unmapped remote asset: ' + value)
                asset = materials / value.split('/Materials/', 1)[1]
            if not asset.is_absolute():
                asset = src.parent / asset
            asset = asset.resolve(strict=True)
            if not asset.is_file():
                raise ValueError('Non-file USD dependency: ' + asset.name)
            if asset.is_relative_to(materials):
                dest = output / 'RoboLab/assets/materials' / asset.relative_to(materials)
            else:
                name = digest(asset) + asset.suffix.lower()
                dest = output / 'textures' / name
                dest.parent.mkdir(exist_ok=True)
                if not dest.exists():
                    shutil.copyfile(asset, dest)
            import os
            return os.path.relpath(dest, target.parent).replace('\\', '/')

        UsdUtils.ModifyAssetPaths(layer, relocate)
        if not layer.Export(str(target)):
            raise RuntimeError('USD export failed')
        # Full dependency closure check on each newly materialized file.
        layers, assets, missing = UsdUtils.ComputeAllDependencies(Sdf.AssetPath(str(target)))
        missing = [x for x in missing if x not in builtin]
        if missing:
            raise ValueError('Unresolved packaged USD dependencies: ' + repr(missing))
        composed = Usd.Stage.Open(str(target))
        after = native_signature(composed)
        if before != after:
            raise ValueError('Native geometry/transform/physics fingerprint changed: ' + relative.as_posix())
        observations.append({'path': relative.as_posix(), 'source_sha256': digest(src),
                             'builtin_renderer_assets': sorted(builtin),
                             'native_composed_fingerprint_sha256': after,
                             'native_composed_fingerprint_unchanged': True,
                             'composed_prim_count': len(list(composed.Traverse()))})
    files = [{'path': x.relative_to(output).as_posix(), 'bytes': x.stat().st_size,
              'sha256': digest(x)} for x in sorted(output.rglob('*')) if x.is_file()]
    doc = {'schema': 'openarmx_ctx01_portable_assets_v1', 'task': 'CTX01',
           'native_geometry_replaced': False, 'simulation_run': False,
           'changes': 'Flatten composition; remove inactive non-demo scene objects; relocate external file assets; preserve MDL resource tree.',
           'redistribution_permission_granted': False,
           'license_note': 'See docs/ASSETS.md; original third-party terms still apply.',
           'inputs': observations, 'files': files}
    (output / 'ASSET_MANIFEST.json').write_text(json.dumps(doc, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'files': len(files),
                      'bytes': sum(x['bytes'] for x in files), 'simulation_started': False}))


if __name__ == '__main__':
    main()
