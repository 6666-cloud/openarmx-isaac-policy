"""CTX01 script-expert example: validate/print the plan, or launch Isaac explicitly."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path(__file__).resolve().parents[1]


def verify_assets(root):
    root = root.resolve(strict=True)
    manifest = json.loads((root / 'ASSET_MANIFEST.json').read_text())
    if manifest.get('schema') != 'openarmx_ctx01_portable_assets_v1':
        raise ValueError('Not a CTX01 demo asset bundle')
    for row in manifest['files']:
        p = (root / row['path']).resolve(strict=True)
        if not p.is_relative_to(root):
            raise ValueError('Asset inventory path escapes bundle')
        data = p.read_bytes()
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Asset changed: ' + row['path'])
    return root


def command(a):
    if a.scene_seed < 0:
        raise ValueError('Use a nonnegative scene seed')
    return [sys.executable, '-B', str(REPO / 'expert/run_context_collection.py'),
            '--suite', '--task', 'CTX01', '--variant', a.variant,
            '--scene-seed', str(a.scene_seed), '--pair-id', 'demo-ctx01',
            '--output', str(a.output), '--shader-cache-dir', str(a.cache),
            *(['--gui'] if a.gui else []), *(['--probe'] if a.probe else []),
            *(['--no-images'] if a.no_images else ['--stream-video'])]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--variant', choices=['A', 'B'], default='A')
    p.add_argument('--scene-seed', type=int, default=101)
    p.add_argument('--assets', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--cache', type=Path)
    p.add_argument('--gui', action='store_true')
    p.add_argument('--probe', action='store_true', help='Setup/camera inspection, not task completion')
    p.add_argument('--no-images', action='store_true', help='Physics diagnostic only')
    p.add_argument('--plan-only', action='store_true', help='CPU plan inspection; no Isaac or writes')
    a = p.parse_args()
    if a.plan_only:
        # Protocol creation only stores asset names; it does not read them or launch Isaac.
        os.environ.setdefault('OPENARMX_DEMO_ASSETS', str(REPO))
        sys.path.insert(0, str(REPO / 'expert'))
        import runtime_paths
        runtime_paths.asset_root = lambda: REPO  # Explicit dry-run sentinel, never used for execution.
        from context_task_protocols import get_protocol, policy_commands
        protocol = get_protocol('CTX01', a.variant)
        print(json.dumps({'task': 'CTX01', 'variant': a.variant,
            'controller': 'scripted oracle expert, not a learned model',
            'physics_hz': 240, 'control_hz': 30,
            'instructions': policy_commands(protocol), 'expected': protocol['expected'],
            'simulation_started': False, 'training_eligible': False}, indent=2))
        return
    if not all((a.assets, a.output, a.cache)):
        p.error('Execution requires explicit --assets, --output and --cache')
    a.assets = verify_assets(a.assets)
    a.output, a.cache = a.output.expanduser().resolve(), a.cache.expanduser().resolve()
    if a.output.exists():
        raise FileExistsError('Use a fresh output directory')
    if any(x.is_relative_to(REPO) or x.is_relative_to(a.assets) for x in (a.output, a.cache)):
        raise ValueError('Keep recordings/cache outside source and immutable assets')
    if a.output == a.cache or a.cache.is_relative_to(a.output) or a.output.is_relative_to(a.cache):
        raise ValueError('Separate output and cache directories')
    env = {**os.environ, 'OPENARMX_DEMO_ASSETS': str(a.assets),
           'OPENARMX_DEMO_CACHE': str(a.cache), 'PYTHONDONTWRITEBYTECODE': '1'}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.cache.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(command(a), env=env)
    report = a.output / 'result.json'
    if result.returncode or not report.is_file():
        raise SystemExit(result.returncode or 1)
    doc = json.loads(report.read_text())
    passed = doc.get('probe_success') is True if a.probe else doc.get('success') is True
    print(json.dumps({'demo_passed': passed, 'result': str(report),
                      'training_acceptance_claimed': False}))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
