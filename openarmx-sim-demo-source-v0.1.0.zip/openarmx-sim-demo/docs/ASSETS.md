# 资产搭建与许可

源代码仓库不重新分发第三方 USD、mesh、纹理、Isaac 软件或数据集。`prepare_assets.py` 不是下载器，也不是 URDF 导入器；它把你已经合法持有的原生资产安装组合成 demo 所需的本地 bundle。

预期的输入根目录：

```text
existing-openarmx-project/
  RoboLab/assets/scenes/openarmx_banana_loop.usda
  RoboLab/assets/objects/basic/red_block.usd
  RoboLab/assets/objects/basic/blue_block.usd
  RoboLab/assets/objects/vomp/plate_large/plate_large.usd
  ...以上 USD 引用的原生机器人、桌子、材质、纹理及其依赖
```

其中 OpenArmX 机器人和场景层是本工程的自定义构建，单独克隆上游 RoboLab 不保证包含它们。没有这套原生资产时，仍可运行 `--plan-only`；不能声称可直接执行完整物理 demo。

准备器只在新目录中展开 USD composition，保留机器人/桌面和三个指定对象的原生 mesh、关节、碰撞/质量属性；去掉未使用的场景对象，把外部文件改成相对引用。MDL 材质及其内部纹理保持原目录结构，其他纹理按内容 SHA256 拷贝；旧场景远程材质地址只映射到已存在的本地同名材质，不下载或替换材质。它不会改源文件、启动 Isaac、重建凸包、改变物体尺寸或移动运行中的物体。`ASSET_MANIFEST.json` 记录生成文件尺寸与 SHA256；输出不加入 Git。

原工程使用 [NVlabs/RoboLab](https://github.com/NVlabs/RoboLab) 资产。随工程的第三方声明列出 `basic`、桌/材质/场景等为 CC BY-NC-SA 4.0，`vomp` 为 CC BY 4.0；子目录自带许可优先。OpenArmX 自定义模型还需核对其自身来源与授权。此处不是新授权，也不把所有资产统一改成 Apache/MIT；保留并遵守原始 attribution、非商业及 share-alike 等适用条件。公开发布资产包前必须单独确认。

本地准备示例应使用数据盘目录。原工作区：

```bash
python3 storage_cleanup_20261019/data_storage.py run -- \
  /path/to/isaac-python /path/to/repo/scripts/prepare_assets.py \
  --source-root /data/openarmx_isaac \
  --output /data/openarmx_isaac/demo_assets/ctx01-v1
```

如果 USD 或纹理引用缺失，准备器应失败；不能用方块代理机器人或空材质偷偷替代后宣称原生资产就绪。
