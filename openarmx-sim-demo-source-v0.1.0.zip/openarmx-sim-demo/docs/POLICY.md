# 脚本控制策略

policy 在此指一个 scripted oracle expert，不是 learned policy。专家可读取任务计划和真实仿真状态，不能把它的任务成功率当作视觉语言模型的推理能力。

```text
英语历史指令 → 抓起已指定积木 → 保持 → 放回 → 等待
英语查询指令 → 选择未操作积木 → 抓取 → 移到中央盘 → 释放 → 归位
```

动作经过以下层次：`context_task_protocols.get_protocol` 生成计划；`context_suite_runtime.episode_class` 执行状态机；`kinematics.ArmKinematics` 从 USD 关节帧求 FK/IK；`context_motion_planning` 与 `context_joint_motion` 生成有界轨迹；执行器用 `ArticulationAction` 下发绝对关节位置目标。转动关节用 rad，滑动关节用 m。没有真实机器人通信。

冻结源中的规划、跟踪、碰撞、接触、支撑和包含率检查在路径适配时不改变。抓取依赖接触和摩擦；初始化之后不通过附件、运动学跟随或直接改物体位姿来完成任务。初始化摆放与运行中作弊写位姿不是同一回事。

A 分支历史操作红块，查询目标蓝块；B 分支相反。相同 `scene-seed` 用于对照，分支不进入场景 RNG。示例默认不启用额外多样性采样。`--plan-only` 只打印计划，不执行动作，不生成数据、不认证物理成功。

要接学习策略，需另加 observation→action adapter、关节名称映射、归一化与时序控制，并保留已有执行安全门槛；本仓库未实现、未验证这条接口。不要直接把状态机的隐藏任务计划作为模型观测。
