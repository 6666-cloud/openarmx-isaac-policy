# 原生 30 Hz LeRobot 导出

此增量为公开 CTX01 脚本专家 demo 增加本地 LeRobot 导出器。它读取已经成功结束、完整封盘的三相机录制，在独立 CPU 进程中写出 **LeRobot v2.1** 目录，并用 **官方 `lerobot==0.3.3`** 读回。不是生产采集器升级，不改物理、动作、相机、英语或验收阈值；不是训练自动启动器，也不会上传 Hugging Face。

旧源码 demo 已经能采集 `trajectory.hdf5`、事件/英语时间线及三路 MP4，但不包含此导出步骤。本版只支持该 demo 的成功 `--stream-video` CTX01 episode，拒绝 probe、无图像、失败及未封盘目录。不要把其他任务/其他原始格式改名后输入。

## 独立 CPU 环境

不要将这些依赖装进 Isaac Sim 的 Python。使用 Python 3.10 的独立环境，`requirements-export.txt` 固定公开 API 的关键直接依赖版本；它不是私有修改版运行时，也不是所有平台/所有传递依赖的通用 lock。Isaac 环境仍使用原 `requirements.txt`。示例路径均为占位符，请替换为自己的数据盘与解释器路径。

```bash
python3.10 -m venv /path/on/data-volume/openarmx-export-env
/path/on/data-volume/openarmx-export-env/bin/python -m pip install -r requirements-export.txt
/path/on/data-volume/openarmx-export-env/bin/python -m pip check
```

若只在 CPU 上使用，可先按 PyTorch 官方说明安装与固定版本相容的 CPU wheel，再安装本文件；导出命令不训练模型，也不需要 CUDA。环境、pip/模型缓存、临时目录及输出应位于你的数据盘。本工程工作机仍必须经 `storage_cleanup_20261019/data_storage.py run -- ...` 预检；继承环境变量不代替预检，数据盘不可用时不得回退到 home 或根盘。

## 已有录制：先检查，再导出

```bash
EXPORT_PY=/path/on/data-volume/openarmx-export-env/bin/python
RAW=/path/on/data-volume/openarmx-demo/runs/demo-A-001
LEROBOT_OUT=/path/on/data-volume/openarmx-demo/lerobot/demo-A-001

# 完整只读检查：源数值、哈希、逐帧索引与三路视频解码；不创建输出。
"$EXPORT_PY" -B scripts/export_lerobot.py --source "$RAW" --inspect-only

# 必须提供新的独立输出和 namespace/dataset 元数据标识，不触发上传。
"$EXPORT_PY" -B scripts/export_lerobot.py --source "$RAW" \
  --output "$LEROBOT_OUT" --repo-id example/openarmx-ctx01-demo
```

输出不得已经存在，不得与原始录制、源码仓库或不可变资产目录重叠。失败目录保留证据，不用同一路径覆盖重试。`--inspect-only` 不接受 `--output`；它执行完整源审核，可能需要读完整三路视频，不只是快速元信息检查。

## 采集结束后自动导出

```bash
ISAAC_PY=/path/to/isaac-sim/python.sh
EXPORT_PY=/path/on/data-volume/openarmx-export-env/bin/python
DEMO_DATA=/path/on/data-volume/openarmx-demo

"$ISAAC_PY" -B scripts/demo.py --assets "$DEMO_DATA/assets-v1" \
  --output "$DEMO_DATA/runs/demo-A-002" --cache "$DEMO_DATA/cache" \
  --variant A --lerobot-output "$DEMO_DATA/lerobot/demo-A-002" \
  --lerobot-python "$EXPORT_PY" --repo-id example/openarmx-ctx01-demo
```

此入口先等待 Isaac 子进程退出，再检查退出码和 `result.json.success == true`，之后才启动独立 CPU 导出子进程。导出器再次验证原始封盘证据。不会将解码、转换或训练读取插进采集主循环；`--probe`、`--no-images`、`--plan-only` 不能同时请求导出。原始录制保留不动。

## 字段与验证边界

导出保留 30 Hz 的原生帧格和胸前、左腕、右腕三路视角。原 MP4 按字节复制到独立 LeRobot 目录并绑定 SHA256，不生成 PNG，不二次编码，不用可变硬链接。state/action 根据原 `joint_names` 顺序对应；动作仍是绝对关节位置目标，转动关节为 rad、滑动关节为 m，观察是动作前状态，不擅自压缩夹爪或改成相对动作。

每帧 LeRobot `task` 是公共协议加截至该帧已经到达的完整英语历史；不会提前泄露未来指令。原当前 `instruction`、`phase`、`turn_id` 和 `action_loss_mask` 同步保留到 `annotations/frames.jsonl`，应和源帧索引一起检查。历史可见但 `action_loss_mask=0` 的帧不能被误当作有监督动作；普通 LeRobot 训练脚本不会自动消费此自定义 sidecar，接入训练必须显式应用原 mask/终止安全协议。

导出器通过官方 CPU reader 检查后才发布 `FORMAT_READY.json`。`format_ready=true` 只表示文件格式及实际读取检查通过，始终 `training_ready=false`；它不授予正式数据训练资格，不替代真实物理结果、人工视频质量检查、A/B 配对/去重、终止安全、曝光平衡或真机标定。本单任务演示不是历史全部任务训练数据集，也不是对其他采集版本的自动适配。

不要将生成的 HDF5、MP4、LeRobot 数据、模型权重或原生资产提交到源码仓库。源资产仍遵守原授权；此导出器不新增数据/模型/第三方资产许可。
