"""Export one successful, sealed demo to official LeRobot 0.3.3 / v2.1.

No Isaac, GPU, PNG staging, video encoding, Hub upload, or formal task acceptance.
Public metadata APIs own the standard v2.1 layout; source MP4 bytes are copied.
The stock reader's task contains only the complete English history arrived by t.
This format view preserves raw masks and the FULL home tail: it is NOT the
terminal-safe supervision view used by the project's separately accepted runs.
"""
from __future__ import annotations

from bisect import bisect_right
from contextlib import contextmanager
import ast
import hashlib
import importlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import re
import shutil
import sys

import h5py
import numpy as np

PINNED_LEROBOT = '0.3.3'
CAMERAS = {'chest': 'cam_head', 'left_wrist': 'cam_left', 'right_wrist': 'cam_right'}
SIM_NAMES = [f'openarmx_{side}_{part}' for side in ('left', 'right')
             for part in [*[f'joint{i}' for i in range(1, 8)], 'finger_joint1', 'finger_joint2']]
FEATURE_NAMES = [name + '.pos' for name in SIM_NAMES if not name.endswith('finger_joint2')]
UNITS = (['rad'] * 7 + ['m']) * 2
MASK = 'supervision.action_loss_mask'
HOLD_MARKERS = ('QUALITY_HOLD.json', 'ACCEPTANCE_REVOKED.json', 'pair_quality_rejection.json',
                'SOURCE_NOT_CURRENTLY_ELIGIBLE.json', 'DIAGNOSTIC_ONLY.json',
                'ISAAC6_DIAGNOSTIC_ONLY.json', 'SMOKE_ONLY.json')
FORMAT_WARNING = ('Format/readback only; raw action masks and complete home tail preserved. '
                  'No terminal-safe E, safe action-chunk sampler, task QA, train/eval split, '
                  'training acceptance, or real-hardware calibration is certified.')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def _json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _text(value):
    return value.decode('utf-8') if isinstance(value, bytes) else str(value)


def english(value):
    require(isinstance(value, str) and value.strip() and value.isascii()
            and re.search('[A-Za-z]', value) and '\x00' not in value
            and not any(ord(c) < 32 and c not in '\n\t' for c in value),
            'Nonempty ASCII English policy instruction required')
    require(not re.search(r'\b(?:CTX\d+|pair_\d+|history_variant|scene_seed)\b', value, re.I),
            'Audit-only identity cannot enter policy language')
    return value


def build_history(events, instructions, times):
    """Exact arrival frames, no future text and no repetition on unchanged frames."""
    count = len(instructions)
    require(count > 0 and np.asarray(times).shape == (count,), 'Missing source instruction clock')
    arrivals = [e for e in events if e.get('kind') == 'instruction']
    require(arrivals and arrivals[0].get('first_effective_frame') == 0,
            'Initial public protocol must arrive at frame zero')
    frames, texts = [], []
    for i, event in enumerate(arrivals):
        f = event.get('first_effective_frame')
        require(type(f) is int and 0 <= f < count and (not frames or f > frames[-1]),
                'Instruction arrival frames must strictly increase within the episode')
        require(type(event.get('time')) in (float, int) and np.isfinite(event['time'])
                and abs(event['time'] - f / 30) < 1e-6, 'Instruction event time/30 Hz frame mismatch')
        text = english(event.get('text'))
        end = arrivals[i + 1]['first_effective_frame'] if i + 1 < len(arrivals) else count
        require(type(end) is int and f < end <= count
                and all(command == text for command in instructions[f:end]),
                'Per-frame instruction and delivered event timeline differ')
        frames.append(f)
        texts.append(text)
    histories = [' '.join(texts[:i + 1]) for i in range(len(texts))]
    indices = np.asarray([bisect_right(frames, f) - 1 for f in range(count)], dtype=np.int64)
    return histories, indices, arrivals


def map_numeric(names, state, action):
    """Select named coordinates, never infer units, sum fingers, clip, or rescale."""
    require(len(names) == len(set(names)) == 18 and set(names) == set(SIM_NAMES),
            'Expected the exact 18 unique named OpenArmX simulation coordinates')
    state, action = np.asarray(state), np.asarray(action)
    require(state.ndim == 2 and state.shape == action.shape and state.shape[1] == 18
            and len(state) > 0 and np.isfinite(state).all() and np.isfinite(action).all(),
            'Invalid source state/action shape or nonfinite values')
    symmetry = {}
    for side in ('left', 'right'):
        a, b = [names.index(f'openarmx_{side}_finger_joint{i}') for i in (1, 2)]
        symmetry[side] = float(np.max(np.abs(action[:, a] - action[:, b])))
        require(symmetry[side] <= 1e-6, 'Asymmetric commanded finger targets cannot map to 16D')
    indices = [names.index(name.removesuffix('.pos')) for name in FEATURE_NAMES]
    # Measured fingers can differ under contact; preserve finger1 rather than
    # inventing symmetry of measured states or averaging their two coordinates.
    mapped_state, mapped_action = state[:, indices].astype(np.float32), action[:, indices].astype(np.float32)
    require(np.isfinite(mapped_state).all() and np.isfinite(mapped_action).all(), 'Float32 conversion overflow')
    return mapped_state, mapped_action, symmetry


def _common_setup(expert_dir):
    """Read trusted code's constant without executing asset discovery or Isaac."""
    source = Path(expert_dir) / 'context_task_protocols.py'
    tree = ast.parse(source.read_text(encoding='utf-8'))
    values = [node.value for node in tree.body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == 'COMMON_SETUP_EN' for target in node.targets)]
    require(len(values) == 1, 'Trusted package has no unique public protocol constant')
    return english(ast.literal_eval(values[0]))


@contextmanager
def _expert_modules(expert_dir):
    expert_dir = Path(expert_dir).resolve(strict=True)
    for name in ('context_recording_adapter', 'context_video_source'):
        require((expert_dir / (name + '.py')).is_file(), 'Missing trusted packaged expert audit: ' + name)
        if name in sys.modules:
            require(Path(sys.modules[name].__file__).resolve() == expert_dir / (name + '.py'),
                    'A different expert audit module is already imported')
    sys.path.insert(0, str(expert_dir))
    try:
        yield importlib.import_module('context_recording_adapter')
    finally:
        sys.path.remove(str(expert_dir))


def _not_held(raw):
    for parent in (raw, *raw.parents):
        for marker in HOLD_MARKERS:
            require(not os.path.lexists(parent / marker), 'Source has authoritative hold: ' + str(parent / marker))
        require(not any(parent.glob('CTX14_PROTOCOL_SUPERSEDED_*.json')), 'Source protocol superseded')


def _load_source(raw, expert_dir):
    raw = Path(raw).expanduser().absolute()
    require(not raw.is_symlink(), 'Source directory symlink is not accepted')
    raw = raw.resolve(strict=True)
    require(raw.is_dir(), '--source must be the raw directory containing RAW_FINALIZED.json')
    _not_held(raw)
    with _expert_modules(expert_dir) as audit:
        storage = audit.validate_outer_recording(raw, audit_video=True)
    require(storage.get('storage_integrity_passed') is True
            and storage.get('physical_result_success') is True, 'Source storage or physical success failed')
    result = _read(raw / 'result.json')
    require(result.get('success') is True and result.get('probe_success') is not True
            and result.get('diagnostic_only') is not True and result.get('smoke_only') is not True,
            'Probe/diagnostic/failed episodes cannot be exported as successful demos')
    with h5py.File(raw / 'trajectory.hdf5', 'r') as handle:
        group = handle['data/demo_0']
        require(_text(group.attrs['task_id']) == 'CTX01', 'This public exporter supports the CTX01 demo only')
        require(bool(group.attrs['success']) and float(group.attrs['fps']) == 30,
                'Expected successful native 30 Hz source')
        require(_text(group.attrs['observation_timing']) == 'pre_action'
                and _text(group.attrs['action_semantics']) ==
                'absolute_joint_position_targets; revolute=rad; prismatic=m',
                'Unrecognized observation/action semantics; no automatic conversion')
        require(_text(group.attrs['instruction_language']) == 'en'
                and _text(group.attrs['language_contract']) == 'openarmx_context_en_v1',
                'Missing source English language contract')
        require(not bool(group.attrs['grasp_attachment'])
                and not bool(group.attrs['mid_episode_pose_reset']), 'Attached/teleported source forbidden')
        names = json.loads(_text(group.attrs['joint_names']))
        state, action, symmetry = map_numeric(names, group['obs/joint_position'][:], group['actions'][:])
        count = len(state)
        times = np.asarray(group['time'][:], dtype=np.float64)
        mask = np.asarray(group['action_loss_mask'][:], dtype=np.float32).reshape(-1)
        require(count == storage['frame_count'] and times.shape == mask.shape == (count,)
                and np.isfinite(times).all() and np.isin(mask, (0, 1)).all()
                and np.max(np.abs(times - np.arange(count) / 30)) < 1e-9,
                'Invalid clock/count/raw supervision mask')
        events = _read(raw / 'events.json')
        require(events == json.loads(_text(group.attrs['events'])), 'Event sidecar differs from raw')
        instructions = group['instruction'].asstr()[:].tolist()
        histories, history_index, arrivals = build_history(events, instructions, times)
        require(histories[0] == _common_setup(expert_dir),
                'Frame-zero public protocol differs from the trusted CTX01 package')
        phases = group['phase'].asstr()[:].tolist()
        turns = np.asarray(group['turn_id'][:])
        require(len(phases) == count and turns.shape == (count,) and turns.dtype.kind in 'iu',
                'Invalid raw phase/turn annotations')
        calibration = json.loads(_text(group.attrs['camera_calibration']))
    return dict(raw=raw, count=count, state=state, action=action, mask=mask, times=times,
                instructions=instructions, histories=histories, history_index=history_index,
                arrivals=arrivals, phases=phases, turns=turns, calibration=calibration,
                symmetry=symmetry, storage=storage)


def inspect_source(raw, expert_dir):
    """Full read-only audit, including video decoding; creates no dataset."""
    source = _load_source(raw, expert_dir)
    return {'source': str(source['raw']), 'frames': source['count'], 'fps': 30,
            'physical_success': True, 'storage_audit_passed': True,
            'source_manifest_sha256': source['storage']['outer_manifest_sha256'],
            'state_action_feature_names': FEATURE_NAMES, 'units': UNITS,
            'instruction_events': source['arrivals'], 'history_tasks': source['histories'],
            'format_ready': False, 'training_ready': False, 'warning': FORMAT_WARNING}


def _features():
    return {'observation.state': {'dtype': 'float32', 'shape': (16,), 'names': FEATURE_NAMES},
            'action': {'dtype': 'float32', 'shape': (16,), 'names': FEATURE_NAMES},
            MASK: {'dtype': 'float32', 'shape': (1,), 'names': ['raw_supervised_action']},
            **{'observation.images.' + alias: {'dtype': 'video', 'shape': (480, 640, 3),
                    'names': ['height', 'width', 'channels']} for alias in CAMERAS.values()}}


def _video_stats_and_checks(source):
    import av
    from lerobot.datasets.compute_stats import sample_indices, auto_downsample_height_width, get_feature_stats
    sampled = sample_indices(source['count'])
    check = {0, source['count'] - 1}
    for event in source['arrivals']:
        f = event['first_effective_frame']
        check.update(x for x in (f - 1, f, f + 1) if 0 <= x < source['count'])
    stats, checks = {}, {}
    for camera, alias in CAMERAS.items():
        path = source['raw'] / 'rgb_stream/videos' / (camera + '.mp4')
        images, hashes, n = {}, {}, 0
        with av.open(str(path)) as container:
            stream = container.streams.video[0]
            stream.codec_context.thread_count = 1
            require(stream.average_rate == 30 and (stream.height, stream.width) == (480, 640),
                    'Source video clock/resolution changed')
            for n, frame in enumerate(container.decode(video=0), 1):
                index = n - 1
                require(n <= source['count'] and frame.time is not None
                        and abs(float(frame.time) - index / 30) < 1e-6, 'Video PTS/count mismatch')
                if index in sampled or index in check:
                    rgb = frame.to_ndarray(format='rgb24')
                    if index in sampled:
                        images[index] = auto_downsample_height_width(rgb.transpose(2, 0, 1))
                    if index in check:
                        hashes[str(index)] = hashlib.sha256(rgb.tobytes()).hexdigest()
        require(n == source['count'], 'Video missing frames')
        key = 'observation.images.' + alias
        values = get_feature_stats(np.stack([images[i] for i in sampled]), axis=(0, 2, 3), keepdims=True)
        stats[key] = {k: v if k == 'count' else np.squeeze(v / 255., axis=0) for k, v in values.items()}
        checks[key] = hashes
    return stats, checks


def exact_rgb(value):
    value = value.detach().cpu().numpy() if hasattr(value, 'detach') else np.asarray(value)
    if value.shape == (3, 480, 640):
        value = value.transpose(1, 2, 0)
    require(value.shape == (480, 640, 3), 'Official reader RGB shape mismatch')
    if value.dtype == np.uint8:
        return np.ascontiguousarray(value)
    require(value.dtype == np.float32 and np.isfinite(value).all()
            and np.all(value >= 0) and np.all(value <= 1), 'Reader image dtype/range mismatch')
    pixels = np.rint(value.astype(np.float64) * 255).astype(np.uint8)
    require(np.array_equal(value, pixels.astype(np.float32) / np.float32(255)),
            'Reader pixels are not exactly reversible uint8/255 values')
    return np.ascontiguousarray(pixels)


def _verify(output, source, manifest):
    from lerobot.datasets.lerobot_dataset import LeRobotDataset
    require(version('lerobot') == PINNED_LEROBOT, 'Use pinned official LeRobot 0.3.3')
    for relative, item in manifest['payload_files'].items():
        path = output / relative
        require(path.resolve(strict=True).is_relative_to(output.resolve()) and not path.is_symlink()
                and path.stat().st_size == item['bytes'] and sha256(path) == item['sha256'],
                'Export payload changed: ' + relative)
    dataset = LeRobotDataset(manifest['repo_id'], root=output, video_backend='pyav', download_videos=False)
    require(dataset.fps == 30 and len(dataset) == source['count'] and dataset.num_episodes == 1
            and dataset.meta.info['codebase_version'] == 'v2.1', 'Official reader clock/count/schema mismatch')
    columns = ['frame_index', 'episode_index', 'index', 'timestamp', 'task_index',
               'observation.state', 'action', MASK]
    rows = dataset.hf_dataset.select_columns(columns)
    for i, row in enumerate(rows):
        require(int(row['frame_index']) == int(row['index']) == i and int(row['episode_index']) == 0,
                'Official loaded table frame identity mismatch')
        require(abs(float(row['timestamp']) - i / 30) < 1e-5, 'Official table timestamp mismatch')
        for key, expected in (('observation.state', source['state'][i]), ('action', source['action'][i]),
                              (MASK, source['mask'][i:i + 1])):
            value = row[key].detach().cpu().numpy() if hasattr(row[key], 'detach') else row[key]
            require(np.array_equal(np.asarray(value, dtype=np.float32).reshape(expected.shape), expected),
                    f'Official reader numeric mismatch at {i}: {key}')
        require(dataset.meta.tasks[int(row['task_index'])] == source['histories'][source['history_index'][i]],
                'Official task contains missing/future/repeated instruction history')
    checked = []
    check_frames = sorted({int(frame) for hashes in manifest['rgb_checks'].values() for frame in hashes})
    for frame in check_frames:
        sample = dataset[frame]
        require(sample['task'] == source['histories'][source['history_index'][frame]],
                'Official indexed reader task differs from causal history')
        for key, hashes in manifest['rgb_checks'].items():
            expected = hashes[str(frame)]
            digest = hashlib.sha256(exact_rgb(sample[key]).tobytes()).hexdigest()
            require(digest == expected, 'Official indexed RGB changed at language boundary')
            checked.append({'camera': key, 'frame': frame, 'rgb_sha256': digest})
    for item in manifest['videos'].values():
        require(sha256(item['source']) == item['sha256'] == sha256(output / item['path']),
                'Original/export MP4 bytes changed')
    require(sha256(source['raw'] / 'RAW_FINALIZED.json') == manifest['source_manifest_sha256'],
            'Source outer manifest changed')
    require(sha256(source['raw'] / 'trajectory.hdf5') == manifest['source_hdf5_sha256']
            and sha256(source['raw'] / 'events.json') == manifest['source_events_sha256'],
            'Source numeric/events changed during export')
    annotations = [json.loads(line) for line in (output / 'annotations/frames.jsonl').read_text().splitlines()]
    require(len(annotations) == source['count'], 'Missing per-frame raw annotations')
    for i, row in enumerate(annotations):
        require(row == _annotation(source, i), 'Raw frame annotation changed')
    _not_held(source['raw'])
    return {'official_reader_passed': True, 'official_reader_version': version('lerobot'),
            'all_numeric_task_mask_frames_checked': len(rows), 'indexed_rgb_checks': checked,
            'video_reencodes': 0, 'png_staging': False, 'original_mp4_bytes_unchanged': True,
            'training_ready': False, 'warning': FORMAT_WARNING}


def _annotation(source, index):
    return {'frame_index': index, 'timestamp': index / 30,
            'instruction': source['instructions'][index], 'phase': source['phases'][index],
            'turn_id': int(source['turns'][index]), 'raw_action_loss_mask': float(source['mask'][index]),
            'history_task_index': int(source['history_index'][index])}


def verify_export(output, expert_dir=None):
    """Read-only official CPU reader check using explicitly trusted package code.

    Never import the manifest's recorded expert_dir: dataset metadata is data,
    not authority to execute arbitrary Python on the receiving workstation.
    """
    output = Path(output).resolve(strict=True)
    manifest = _read(output / 'EXPORT_MANIFEST.json')
    expert_dir = Path(expert_dir) if expert_dir is not None else Path(__file__).resolve().parents[1] / 'expert'
    source = _load_source(manifest['source'], expert_dir)
    return _verify(output, source, manifest)


def export_episode(raw, output, repo_id, expert_dir):
    """Create one new v2.1 dataset; FORMAT_READY appears only after real readback."""
    require(version('lerobot') == PINNED_LEROBOT, 'Use pinned official LeRobot 0.3.3')
    output = Path(output).expanduser().absolute()
    require(not os.path.lexists(output), 'Refusing existing/partial output; choose a fresh directory')
    source = _load_source(raw, expert_dir)
    resolved = output.resolve()
    code_root = Path(expert_dir).resolve().parent
    require(not any(resolved.is_relative_to(path) or path.is_relative_to(resolved)
                    for path in (source['raw'], code_root)),
            'Keep dataset outside source and immutable asset/code directories')
    require(isinstance(repo_id, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*', repo_id)
            and all('..' not in part for part in repo_id.split('/')),
            'Explicit owner/dataset repo ID required; this does not upload it')
    output.parent.mkdir(parents=True, exist_ok=True)
    total_video = sum((source['raw'] / 'rgb_stream/videos' / (camera + '.mp4')).stat().st_size for camera in CAMERAS)
    require(shutil.disk_usage(output.parent).free >= total_video + 1024**3, 'Insufficient export space reserve')
    from datasets import Dataset
    from lerobot.datasets.lerobot_dataset import LeRobotDatasetMetadata
    from lerobot.datasets.utils import get_hf_features_from_features
    from lerobot.datasets.compute_stats import compute_episode_stats
    video_stats, rgb_checks = _video_stats_and_checks(source)
    meta = LeRobotDatasetMetadata.create(repo_id, fps=30, features=_features(), root=output,
                                         robot_type='openarmx_sim_nominal_uncalibrated', use_videos=True)
    _json(output / 'EXPORT_INCOMPLETE.json', {'training_ready': False, 'source': str(source['raw'])})
    videos = {}
    for camera, alias in CAMERAS.items():
        original = source['raw'] / 'rgb_stream/videos' / (camera + '.mp4')
        expected = source['storage']['video_storage_audit']['videos'][camera]['actual_sha256']
        require(sha256(original) == expected, 'Audited source video changed before copy')
        key = 'observation.images.' + alias
        destination = output / meta.get_video_file_path(0, key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive byte copy deliberately avoids a user later editing an export
        # through a shared inode and thereby changing the original recording.
        with original.open('rb') as incoming, destination.open('xb') as outgoing:
            shutil.copyfileobj(incoming, outgoing, length=8 * 1024**2)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        require(sha256(original) == expected == sha256(destination), 'MP4 changed during byte copy')
        videos[camera] = {'source': str(original), 'path': str(destination.relative_to(output)),
                         'sha256': expected, 'bytes': destination.stat().st_size,
                         'method': 'exclusive_byte_identical_copy_no_encode'}
    for task in source['histories']:
        if meta.get_task_index(task) is None:
            meta.add_task(task)
    count = source['count']
    table = {'observation.state': source['state'], 'action': source['action'], MASK: source['mask'],
             'timestamp': (np.arange(count) / 30).astype(np.float32),
             'frame_index': np.arange(count, dtype=np.int64), 'episode_index': np.zeros(count, dtype=np.int64),
             'index': np.arange(count, dtype=np.int64),
             'task_index': np.asarray([meta.get_task_index(source['histories'][i])
                                       for i in source['history_index']], dtype=np.int64)}
    hf_features = get_hf_features_from_features(meta.features)
    path = output / meta.get_data_file_path(0)
    path.parent.mkdir(parents=True, exist_ok=True)
    Dataset.from_dict(table, features=hf_features, split='train').to_parquet(path)
    numeric_features = {key: value for key, value in meta.features.items() if value['dtype'] != 'video'}
    stats = compute_episode_stats(table, numeric_features)
    meta.update_video_info()
    meta.save_episode(0, count, list(dict.fromkeys(source['histories'])), {**stats, **video_stats})
    annotations = output / 'annotations'
    annotations.mkdir()
    with (annotations / 'frames.jsonl').open('x', encoding='utf-8') as stream:
        for index in range(count):
            stream.write(json.dumps(_annotation(source, index), allow_nan=False) + '\n')
    _json(annotations / 'language_events.json', {'events': source['arrivals'],
        'history_tasks': source['histories'], 'rule': 'public protocol + arrived instruction texts, in order; never future'})
    _json(annotations / 'camera_calibration.json', source['calibration'])
    manifest = {'schema': 'openarmx_demo_lerobot_v21_export_v1', 'repo_id': repo_id,
        'source': str(source['raw']), 'expert_dir': str(Path(expert_dir).resolve()),
        'source_manifest_sha256': source['storage']['outer_manifest_sha256'],
        'source_hdf5_sha256': source['storage']['artifact_hashes']['trajectory.hdf5'],
        'source_events_sha256': source['storage']['artifact_hashes']['events.json'],
        'format': 'v2.1', 'lerobot_version': PINNED_LEROBOT, 'fps': 30, 'frames': count, 'episodes': 1,
        'features': FEATURE_NAMES, 'units': UNITS, 'finger_target_symmetry_max_error_m': source['symmetry'],
        'camera_mapping': CAMERAS, 'videos': videos, 'rgb_checks': rgb_checks,
        'task_semantics': 'public protocol plus all already-arrived English instructions in source order',
        'numeric_conversion': 'named raw18 selection to float32; finger1 only, no averaging or rescaling',
        'raw_mask_and_full_home_tail_preserved': True, 'terminal_safe_supervision_certified': False,
        'training_ready': False, 'hardware_deployment_allowed': False, 'warning': FORMAT_WARNING,
        'exporter_sha256': sha256(__file__)}
    manifest['payload_files'] = {str(path.relative_to(output)):
        {'bytes': path.stat().st_size, 'sha256': sha256(path)}
        for directory in ('data', 'meta', 'videos', 'annotations')
        for path in sorted((output / directory).rglob('*')) if path.is_file()}
    _json(output / 'EXPORT_MANIFEST.json', manifest)
    readback = _verify(output, source, manifest)
    _json(output / 'READBACK.json', readback)
    ready = {'format_ready': True, 'dataset': str(output), 'format': 'v2.1', 'fps': 30,
             'episodes': 1, 'frames': count, 'training_ready': False,
             'manifest_sha256': sha256(output / 'EXPORT_MANIFEST.json'),
             'readback_sha256': sha256(output / 'READBACK.json'), 'warning': FORMAT_WARNING}
    _json(output / 'FORMAT_READY.json', ready)
    (output / 'EXPORT_INCOMPLETE.json').rename(output / 'EXPORT_STARTED.json')
    return {**ready, 'readback': readback}
