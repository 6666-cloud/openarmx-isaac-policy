"""CPU-only, explicitly scoped LeRobot dataset export helpers."""
