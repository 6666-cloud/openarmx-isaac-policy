# OpenArmX Sim

**双臂仿真资产搭建与脚本控制策略 Demo**  
**Native scene assets and contact-driven scripted control for bimanual manipulation**

从已有 OpenArmX 仿真工程提取的、独立目录运行的源码示例。首版仅演示 **CTX01：操作历史选择**：先抓起一块积木、保持并放回，再把之前没有操作的另一块放到中央盘中。A/B 使用同一场景种子，改变历史指令和目标分支。

这里的 **policy 是脚本专家**：状态机决定操作对象，笛卡尔 IK 与有界轨迹规划生成关节位置目标，PD 驱动和接触力完成抓取。不是训练好的 VLA/RL 模型，不包含模型权重，不代表真实硬件标定或生产数据验收。

## v0.2.0：采集后直接导出 LeRobot

旧版 v0.1.0 只有原始 HDF5、三相机 MP4 和事件文件，没有 LeRobot 导出入口。
本版补齐独立 CPU 导出器和 `demo.py --lerobot-output`：采集子进程结束、原始封盘和成功检查通过后再导出，不修改物理采集主循环。

- 输出是 **标准 LeRobot Dataset v2.1**，固定验证运行时 **`lerobot==0.3.3`**；不是定制训练环境的“0.6.2”，也不冒充 v3。
- 三路原生 **30Hz / 640×480** MP4 以同字节副本复用，SHA256 不变；不二次编码、不暂存逐帧 PNG。
- `observation.state` 和 `action` 为按关节名映射的 16 维绝对关节位置；保留原动作监督 mask。
- 每帧的标准 `task` 文本包含公共协议及截至该帧已经到达的完整英语指令历史；另存原指令、phase、turn_id 和 mask 标注，避免把静态末尾指令覆盖整段数据。
- 导出后使用官方 CPU reader 回读校验。`format_ready` 只表示格式和来源绑定检查通过，不是正式训练安全验收；原始回家尾段和 mask 不会被伪造或改写。

使用方式、独立 CPU 环境和完整示例见 [LeRobot 导出指南](docs/LEROBOT.md)。导出器不会自动上传 Hugging Face、不会训练，也不会操作真机。

```bash
# EXPORT_PY 指向独立的 CPU 导出环境，不要把依赖装进 Isaac Sim。
EXPORT_PY=/path/to/export-env/bin/python
DEMO_DATA=/path/on/data-volume/openarmx-demo

"$EXPORT_PY" scripts/export_lerobot.py \
  --source "$DEMO_DATA/runs/demo-A-001" \
  --output "$DEMO_DATA/lerobot/demo-A-001" \
  --repo-id local/openarmx-ctx01-demo
```

完整导出脚本和示例包含在 v0.2.0 源码 ZIP，解压后在 `openarmx-sim-demo` 目录运行。历史 v0.1.0 ZIP 保持不变。资产、数据、录像和模型权重均未上传。

## 内容

- `expert/context_suite_scene.py`：原生机器人、桌面、积木、盘子的场景组合；碰撞、质量、摩擦和视觉配置。
- `expert/context_suite_runtime.py`：脚本专家状态机、抓取/放置、接触和任务结果检查。
- `expert/kinematics.py`、`context_motion_planning.py`：原生 USD 关节链 FK/IK 与有界运动规划。
- `scripts/prepare_assets.py`：从合法持有的原生资产生成独立、可校验的本地资产包，不启动仿真。
- `scripts/demo.py`：一个 CTX01 demo，支持纯 CPU 查看计划、场景探针、GUI 或无界面执行。
- `SOURCE_MANIFEST.json`：冻结源版本和每个源码文件的 SHA256；仅对路径可移植性做适配。

## 快速开始

第一步可用普通 Python，不需要 GPU、模型或资产：

```bash
python -B scripts/demo.py --plan-only --variant A
python -B scripts/demo.py --plan-only --variant B
# 回归测试需要 requirements.txt 中的 NumPy/SciPy。
python -B -m unittest discover -s tests -v
```

实际运行需要 Linux/NVIDIA GPU、兼容的 Isaac Sim **4.5 / Python 3.10** 环境，以及完整的原生 OpenArmX/RoboLab 资产。此版不声称兼容 Isaac Sim 5/6。[NVIDIA standalone Python 文档](https://docs.isaacsim.omniverse.nvidia.com/4.5.0/python_scripting/manual_standalone_python.html)说明如何使用仿真自带 Python；扩展 API 必须在 `SimulationApp` 启动后导入。

```bash
# 使用你自己的 Isaac Sim Python 路径和数据盘路径，不要照抄占位符。
ISAAC_PY=/path/to/isaac-sim/python.sh
DEMO_DATA=/path/on/data-volume/openarmx-demo

"$ISAAC_PY" -m pip install -r requirements.txt
"$ISAAC_PY" scripts/prepare_assets.py \
  --source-root /path/to/existing-openarmx-project \
  --output "$DEMO_DATA/assets-v1"

# 先检查场景和相机。probe 通过不等于任务成功。
"$ISAAC_PY" scripts/demo.py --assets "$DEMO_DATA/assets-v1" \
  --output "$DEMO_DATA/runs/probe-A-001" --cache "$DEMO_DATA/cache" --probe --gui

# 一个完整示例。输出目录必须是新目录，不覆盖历史结果。
"$ISAAC_PY" scripts/demo.py --assets "$DEMO_DATA/assets-v1" \
  --output "$DEMO_DATA/runs/demo-A-001" --cache "$DEMO_DATA/cache" --variant A --gui
```

去掉 `--gui` 可无界面运行；指定 `--no-images` 只做物理诊断，不能当作完整三相机示例。B 分支使用相同 `--scene-seed` 和另一个新输出目录。

在原工程工作机上，新资产、录像、日志、缓存只写 `/data/openarmx_isaac`，所有批量命令先经原工程 `storage_cleanup_20261019/data_storage.py run -- ...`；不在仓库、home 或临时根盘写数据。

## 怎么搭建这个仿真

1. 准备原生机器人 USD：双臂各 7 个转动关节、每个夹爪 2 个滑动关节，保留原始 mesh、关节帧、限位和碰撞体。
2. 组合底座桌和任务桌，单位为米、Z 轴向上；生成 CTX01 的两块积木和中央盘子。不要把视觉缩放误当作碰撞尺寸标定。
3. 启用原生关节 PD 和接触传感；物理 240 Hz，每 8 个子步发送一次目标，即控制/录像 30 Hz。
4. 配置胸前、左腕、右腕相机；图像与物理步保持同步。场景构建、相机配置、控制器分文件保留，便于阅读和替换。
5. 先跑 probe，再执行单个 episode，检查 `result.json`、`events.json`、`scene_config.json` 和原始数值/三相机输出。

详见 [资产与许可](docs/ASSETS.md)、[控制策略](docs/POLICY.md)、[验证边界](docs/VALIDATION.md)。

## 版本与边界

这是从 `context_v07_r10_ctx01_retime12_v1` 提取的 **单任务源码示例**，不是所有任务的最新版集合，也不是 CTX04 修复包或训练交接包。为复用原专家保留了一些其他任务辅助模块，但首版入口只开放 CTX01，资产包也仅覆盖 CTX01。

代码、资产和数据许可分开处理。此初稿未新增统一开源许可证；公开分发前应由权利人确认自有代码授权和第三方模型条件。仓库不包含 USD/纹理、录像、数据集、检查点、服务器地址、凭据或真实机器人项目。
