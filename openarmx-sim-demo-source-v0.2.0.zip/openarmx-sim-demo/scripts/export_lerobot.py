"""Export one closed CTX01 stream-video episode with the pinned CPU LeRobot API."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

REPO = Path(__file__).resolve().parents[1]


def validate_repo_id(value):
    if (not isinstance(value, str) or not re.fullmatch(
            r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*', value)
            or any(part in ('.', '..') or '..' in part for part in value.split('/'))):
        raise ValueError('Use an explicit namespace/dataset repo-id; this does not upload it')
    return value


def overlaps(left, right):
    return left.is_relative_to(right) or right.is_relative_to(left)


def validate_paths(source, output=None):
    source = source.expanduser().resolve(strict=True)
    if not source.is_dir() or overlaps(source, REPO):
        raise ValueError('Source recordings must be outside the source repository')
    if output is None:
        return source, None
    if output.exists() or output.is_symlink():
        raise FileExistsError('Use a fresh LeRobot output directory; failed output is preserved')
    output = output.expanduser().resolve()
    if overlaps(output, source) or overlaps(output, REPO):
        raise ValueError('Keep LeRobot output separate from raw recordings and source code')
    return source, output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path,
                        help='Successful closed raw episode, not the RGB subdirectory')
    parser.add_argument('--output', type=Path, help='Fresh independent LeRobot dataset directory')
    parser.add_argument('--repo-id', help='Local metadata identifier namespace/dataset; no upload')
    parser.add_argument('--inspect-only', action='store_true',
                        help='Read-only complete source hash/frame/video audit; no dataset writes')
    args = parser.parse_args(argv)
    if not args.inspect_only and (args.output is None or args.repo_id is None):
        parser.error('Export requires explicit --source, --output and --repo-id')
    if args.inspect_only and args.output is not None:
        parser.error('--inspect-only does not accept --output and never creates a dataset')
    if args.repo_id is not None:
        validate_repo_id(args.repo_id)
    source, output = validate_paths(args.source, args.output)
    sys.path.insert(0, str(REPO))
    from exporter.export_episode import export_episode, inspect_source
    if args.inspect_only:
        result = inspect_source(source, REPO / 'expert')
    else:
        result = export_episode(source, output, args.repo_id, REPO / 'expert')
        if result.get('format_ready') is not True or result.get('training_ready') is not False:
            raise RuntimeError('Exporter did not publish the expected format-only completion evidence')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print('LeRobot export failed: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
