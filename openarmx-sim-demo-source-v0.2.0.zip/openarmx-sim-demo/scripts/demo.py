"""CTX01 script-expert example with optional independent CPU LeRobot export."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path(__file__).resolve().parents[1]


def verify_assets(root):
    root = root.resolve(strict=True)
    manifest = json.loads((root / 'ASSET_MANIFEST.json').read_text())
    if manifest.get('schema') != 'openarmx_ctx01_portable_assets_v1':
        raise ValueError('Not a CTX01 demo asset bundle')
    for row in manifest['files']:
        p = (root / row['path']).resolve(strict=True)
        if not p.is_relative_to(root):
            raise ValueError('Asset inventory path escapes bundle')
        data = p.read_bytes()
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Asset changed: ' + row['path'])
    return root


def command(a):
    if a.scene_seed < 0:
        raise ValueError('Use a nonnegative scene seed')
    return [sys.executable, '-B', str(REPO / 'expert/run_context_collection.py'),
            '--suite', '--task', 'CTX01', '--variant', a.variant,
            '--scene-seed', str(a.scene_seed), '--pair-id', 'demo-ctx01',
            '--output', str(a.output), '--shader-cache-dir', str(a.cache),
            *(['--gui'] if a.gui else []), *(['--probe'] if a.probe else []),
            *(['--no-images'] if a.no_images else ['--stream-video'])]


def overlaps(left, right):
    return left.is_relative_to(right) or right.is_relative_to(left)


def prepare_export(a):
    """Validate export intent before launching Isaac; do not create export output."""
    supplied = (a.lerobot_output is not None, a.lerobot_python is not None, a.repo_id is not None)
    if not any(supplied):
        return
    if not all(supplied):
        raise ValueError('LeRobot export requires --lerobot-output, --lerobot-python and --repo-id')
    if a.probe or a.no_images or a.plan_only:
        raise ValueError('LeRobot export requires a complete three-camera episode, not probe/no-images/plan-only')
    from export_lerobot import validate_repo_id
    validate_repo_id(a.repo_id)
    if a.lerobot_output.exists() or a.lerobot_output.is_symlink():
        raise FileExistsError('Use a fresh LeRobot output directory')
    a.lerobot_output = a.lerobot_output.expanduser().resolve()
    a.lerobot_python = a.lerobot_python.expanduser().resolve(strict=True)
    if not a.lerobot_python.is_file() or not os.access(a.lerobot_python, os.X_OK):
        raise ValueError('--lerobot-python must be an executable independent CPU Python interpreter')
    if a.lerobot_python == Path(sys.executable).resolve():
        raise ValueError('Use an independent CPU environment, not the Isaac Python interpreter')


def export_command(a):
    return [str(a.lerobot_python), '-B', str(REPO / 'scripts/export_lerobot.py'),
            '--source', str(a.output), '--output', str(a.lerobot_output), '--repo-id', a.repo_id]


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--variant', choices=['A', 'B'], default='A')
    p.add_argument('--scene-seed', type=int, default=101)
    p.add_argument('--assets', type=Path)
    p.add_argument('--output', type=Path)
    p.add_argument('--cache', type=Path)
    p.add_argument('--gui', action='store_true')
    p.add_argument('--probe', action='store_true', help='Setup/camera inspection, not task completion')
    p.add_argument('--no-images', action='store_true', help='Physics diagnostic only')
    p.add_argument('--plan-only', action='store_true', help='CPU plan inspection; no Isaac or writes')
    p.add_argument('--lerobot-output', type=Path, help='Optional fresh independent LeRobot output')
    p.add_argument('--lerobot-python', type=Path, help='Separate CPU Python with requirements-export.txt')
    p.add_argument('--repo-id', help='Explicit namespace/dataset metadata identifier; no upload')
    a = p.parse_args(argv)
    prepare_export(a)
    if a.plan_only:
        # Protocol creation only stores asset names; it does not read them or launch Isaac.
        os.environ.setdefault('OPENARMX_DEMO_ASSETS', str(REPO))
        sys.path.insert(0, str(REPO / 'expert'))
        import runtime_paths
        runtime_paths.asset_root = lambda: REPO  # Explicit dry-run sentinel, never used for execution.
        from context_task_protocols import get_protocol, policy_commands
        protocol = get_protocol('CTX01', a.variant)
        print(json.dumps({'task': 'CTX01', 'variant': a.variant,
            'controller': 'scripted oracle expert, not a learned model',
            'physics_hz': 240, 'control_hz': 30,
            'instructions': policy_commands(protocol), 'expected': protocol['expected'],
            'simulation_started': False, 'training_eligible': False}, indent=2))
        return
    if not all((a.assets, a.output, a.cache)):
        p.error('Execution requires explicit --assets, --output and --cache')
    a.assets = verify_assets(a.assets)
    if a.output.exists() or a.output.is_symlink():
        raise FileExistsError('Use a fresh output directory')
    a.output, a.cache = a.output.expanduser().resolve(), a.cache.expanduser().resolve()
    destinations = [a.output, a.cache]
    if a.lerobot_output is not None:
        destinations.append(a.lerobot_output)
    if any(overlaps(x, REPO) or overlaps(x, a.assets) for x in destinations):
        raise ValueError('Keep recordings/export/cache separate from source and immutable assets')
    if any(overlaps(left, right) for i, left in enumerate(destinations) for right in destinations[i + 1:]):
        raise ValueError('Separate raw output, LeRobot output and cache directories')
    env = {**os.environ, 'OPENARMX_DEMO_ASSETS': str(a.assets),
           'OPENARMX_DEMO_CACHE': str(a.cache), 'PYTHONDONTWRITEBYTECODE': '1'}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.cache.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(command(a), env=env)
    report = a.output / 'result.json'
    if result.returncode or not report.is_file():
        raise SystemExit(result.returncode or 1)
    doc = json.loads(report.read_text())
    passed = doc.get('probe_success') is True if a.probe else doc.get('success') is True
    print(json.dumps({'demo_passed': passed, 'result': str(report),
                      'training_acceptance_claimed': False}))
    if not passed:
        raise SystemExit(1)
    if a.lerobot_output is not None:
        # The Isaac child has exited. Closed-source and official-reader checks run
        # only in this separate CPU child; no work enters the collection loop.
        exported = subprocess.run(export_command(a), env={**env, 'CUDA_VISIBLE_DEVICES': ''})
        if exported.returncode:
            raise SystemExit(exported.returncode)
    raise SystemExit(0)


if __name__ == '__main__':
    main()
