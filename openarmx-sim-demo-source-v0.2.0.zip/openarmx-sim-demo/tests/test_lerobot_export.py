"""Pure CPU contract tests; no simulation, videos, dataset writes, or network."""
import sys
from pathlib import Path
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from exporter.export_episode import (build_history, english, map_numeric, exact_rgb,
                                     SIM_NAMES, FEATURE_NAMES, UNITS)


class LeRobotExportTests(unittest.TestCase):
    def test_history_changes_only_at_real_arrival_without_future_query(self):
        events = [{'kind': 'instruction', 'first_effective_frame': 0, 'time': 0., 'text': 'Follow the protocol.'},
                  {'kind': 'instruction', 'first_effective_frame': 3, 'time': .1, 'text': 'Pick up the red block.'},
                  {'kind': 'instruction', 'first_effective_frame': 7, 'time': 7 / 30, 'text': 'Move the other block.'}]
        commands = ['Follow the protocol.'] * 3 + ['Pick up the red block.'] * 4 + ['Move the other block.'] * 3
        history, index, _ = build_history(events, commands, np.arange(10) / 30)
        self.assertEqual(index.tolist(), [0] * 3 + [1] * 4 + [2] * 3)
        self.assertEqual(history[0], 'Follow the protocol.')
        self.assertEqual(history[1], 'Follow the protocol. Pick up the red block.')
        self.assertEqual(history[2], 'Follow the protocol. Pick up the red block. Move the other block.')

    def test_rejects_shifted_and_missing_initial_instruction(self):
        for event in ({'kind': 'instruction', 'first_effective_frame': 1, 'time': 1 / 30, 'text': 'Go.'},
                      {'kind': 'instruction', 'first_effective_frame': 0, 'time': .1, 'text': 'Go.'}):
            with self.assertRaises(ValueError):
                build_history([event], ['Go.'] * 2, np.arange(2) / 30)

    def test_rejects_current_instruction_not_bound_to_events(self):
        event = {'kind': 'instruction', 'first_effective_frame': 0, 'time': 0., 'text': 'Go.'}
        with self.assertRaises(ValueError):
            build_history([event], ['Go.', 'Stop.'], np.arange(2) / 30)

    def test_language_does_not_accept_audit_ids_or_chinese(self):
        for text in ('CTX01 means red.', 'Use pair_0001.', 'scene_seed 2', '拿起杯子', '', 'Go.\x00'):
            with self.assertRaises(ValueError):
                english(text)

    def test_named_selection_preserves_reordered_finger1_not_sum(self):
        names = list(reversed(SIM_NAMES))
        state = np.stack([np.arange(18) + .25] * 2)
        actions = state.copy()
        for side in ('left', 'right'):
            a, b = [names.index(f'openarmx_{side}_finger_joint{i}') for i in (1, 2)]
            actions[:, b] = actions[:, a]
        mapped_state, mapped_actions, _ = map_numeric(names, state, actions)
        for i, name in enumerate(FEATURE_NAMES):
            np.testing.assert_array_equal(mapped_state[:, i], state[:, names.index(name[:-4])])
        self.assertEqual(mapped_actions.shape, (2, 16))
        self.assertEqual(UNITS, (['rad'] * 7 + ['m']) * 2)
        self.assertNotEqual(mapped_state[0, 7], sum(state[0, names.index(f'openarmx_left_finger_joint{i}')] for i in (1, 2)))

    def test_asymmetric_targets_duplicate_names_and_nonfinite_rejected(self):
        data = np.zeros((3, 18))
        bad = data.copy()
        bad[:, SIM_NAMES.index('openarmx_left_finger_joint2')] = .001
        with self.assertRaises(ValueError):
            map_numeric(SIM_NAMES, data, bad)
        with self.assertRaises(ValueError):
            map_numeric(SIM_NAMES[:-1] + [SIM_NAMES[0]], data, data)
        bad[0, 0] = np.nan
        with self.assertRaises(ValueError):
            map_numeric(SIM_NAMES, bad, data)

    def test_float_reader_rgb_requires_exact_uint8_lattice(self):
        pixels = np.zeros((480, 640, 3), np.uint8)
        pixels[..., 0] = 131
        np.testing.assert_array_equal(exact_rgb(pixels.astype(np.float32) / 255), pixels)
        with self.assertRaises(ValueError):
            exact_rgb(np.full((480, 640, 3), .5001, np.float32))


if __name__ == '__main__':
    unittest.main()
