"""CPU-only CLI orchestration tests. File operations are mocked; no Isaac/network."""
import argparse
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))


def load_script(name):
    spec = importlib.util.spec_from_file_location(name + '_cli_under_test', ROOT / 'scripts' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ExportCliTests(unittest.TestCase):
    def setUp(self):
        self.cli = load_script('export_lerobot')
        self.demo = load_script('demo')

    def test_export_requires_explicit_destination_and_identifier(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as caught:
            self.cli.main(['--source', '/nonexistent-source'])
        self.assertEqual(caught.exception.code, 2)

    def test_inspect_has_no_output(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as caught:
            self.cli.main(['--source', '/raw', '--output', '/out', '--inspect-only'])
        self.assertEqual(caught.exception.code, 2)

    def test_repo_identifier_validation(self):
        self.assertEqual(self.cli.validate_repo_id('example/ctx01-demo'), 'example/ctx01-demo')
        for value in ('', 'ctx01', '../ctx01', 'a/../b', 'a/b c', 'a/a..b'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.cli.validate_repo_id(value)

    def test_inspect_only_dispatches_read_only_source_audit(self):
        called = []
        fake = types.ModuleType('exporter.export_episode')
        fake.inspect_source = lambda raw, expert: called.append((raw, expert)) or {'training_ready': False}
        fake.export_episode = lambda *args: self.fail('inspect must not export')
        with patch.object(self.cli, 'validate_paths', return_value=(Path('/raw'), None)), \
                patch.dict(sys.modules, {'exporter.export_episode': fake}), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(self.cli.main(['--source', '/raw', '--inspect-only']), 0)
        self.assertEqual(called, [(Path('/raw'), ROOT / 'expert')])

    def test_missing_format_ready_is_not_success(self):
        fake = types.ModuleType('exporter.export_episode')
        fake.inspect_source = lambda *args: {}
        fake.export_episode = lambda *args: {'format_ready': False, 'training_ready': False}
        with patch.object(self.cli, 'validate_paths', return_value=(Path('/raw'), Path('/out'))), \
                patch.dict(sys.modules, {'exporter.export_episode': fake}), self.assertRaises(RuntimeError):
            self.cli.main(['--source', '/raw', '--output', '/out', '--repo-id', 'example/ctx01'])

    def export_args(self, **overrides):
        values = dict(lerobot_output=Path('/demo-data/lerobot/new'),
                      lerobot_python=Path('/cpu-env/bin/python'), repo_id='example/ctx01',
                      probe=False, no_images=False, plan_only=False,
                      output=Path('/demo-data/raw/new'), cache=Path('/demo-data/cache'))
        values.update(overrides)
        return argparse.Namespace(**values)

    def test_export_intent_rejected_for_diagnostics(self):
        for flag in ('probe', 'no_images', 'plan_only'):
            with self.subTest(flag=flag), self.assertRaises(ValueError):
                self.demo.prepare_export(self.export_args(**{flag: True}))

    def test_incomplete_export_intent_rejected(self):
        for flag in ('lerobot_output', 'lerobot_python', 'repo_id'):
            with self.subTest(flag=flag), self.assertRaises(ValueError):
                self.demo.prepare_export(self.export_args(**{flag: None}))

    def test_export_child_is_independent_cpu_command(self):
        args = self.export_args()
        command = self.demo.export_command(args)
        self.assertEqual(command[:3], ['/cpu-env/bin/python', '-B', str(ROOT / 'scripts/export_lerobot.py')])
        self.assertIn('--source', command)
        self.assertNotIn('--gui', command)
        self.assertNotIn('--stream-video', command)

    def test_collection_command_unchanged_and_has_no_export_work(self):
        args = self.export_args(scene_seed=101, variant='A', gui=False)
        args.no_images = args.probe = False
        command = self.demo.command(args)
        self.assertIn('--stream-video', command)
        self.assertNotIn('--lerobot-output', command)
        self.assertNotIn(str(ROOT / 'scripts/export_lerobot.py'), command)

    def test_overlap_catches_both_nesting_directions(self):
        self.assertTrue(self.cli.overlaps(Path('/data/source'), Path('/data/source/child')))
        self.assertTrue(self.demo.overlaps(Path('/data/source/child'), Path('/data/source')))
        self.assertFalse(self.demo.overlaps(Path('/data/source'), Path('/data/output')))

    def test_existing_export_directory_rejected_without_dispatch(self):
        with patch.object(Path, 'resolve', return_value=Path('/raw')), \
                patch.object(Path, 'is_dir', return_value=True), \
                patch.object(Path, 'exists', return_value=True), self.assertRaises(FileExistsError):
            self.cli.validate_paths(Path('/raw'), Path('/already-exists'))

    def test_same_isaac_interpreter_rejected(self):
        args = self.export_args(lerobot_python=Path(sys.executable))
        with patch.object(Path, 'exists', return_value=False), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'is_file', return_value=True), \
                patch.object(self.demo.os, 'access', return_value=True), self.assertRaisesRegex(ValueError, 'independent'):
            self.demo.prepare_export(args)

    def test_demo_never_exports_failed_collection(self):
        argv = ['--assets', '/demo-data/assets', '--output', '/demo-data/raw/new',
                '--cache', '/demo-data/cache', '--lerobot-output', '/demo-data/lerobot/new',
                '--lerobot-python', '/cpu-env/bin/python', '--repo-id', 'example/ctx01']
        with patch.object(self.demo, 'prepare_export'), \
                patch.object(self.demo, 'verify_assets', return_value=Path('/demo-data/assets')), \
                patch.object(Path, 'exists', return_value=False), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'mkdir'), \
                patch.object(self.demo.subprocess, 'run', return_value=subprocess.CompletedProcess([], 7)) as run, \
                self.assertRaises(SystemExit) as caught:
            self.demo.main(argv)
        self.assertEqual(caught.exception.code, 7)
        self.assertEqual(run.call_count, 1)

    def test_exit_zero_with_success_false_is_not_exportable(self):
        argv = ['--assets', '/demo-data/assets', '--output', '/demo-data/raw/new',
                '--cache', '/demo-data/cache', '--lerobot-output', '/demo-data/lerobot/new',
                '--lerobot-python', '/cpu-env/bin/python', '--repo-id', 'example/ctx01']
        with patch.object(self.demo, 'prepare_export'), \
                patch.object(self.demo, 'verify_assets', return_value=Path('/demo-data/assets')), \
                patch.object(Path, 'exists', return_value=False), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'is_file', return_value=True), \
                patch.object(Path, 'read_text', return_value=json.dumps({'success': False})), \
                patch.object(Path, 'mkdir'), \
                patch.object(self.demo.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0)) as run, \
                contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as caught:
            self.demo.main(argv)
        self.assertEqual(caught.exception.code, 1)
        self.assertEqual(run.call_count, 1)

    def test_cpu_export_failure_is_not_hidden(self):
        argv = ['--assets', '/demo-data/assets', '--output', '/demo-data/raw/new',
                '--cache', '/demo-data/cache', '--lerobot-output', '/demo-data/lerobot/new',
                '--lerobot-python', '/cpu-env/bin/python', '--repo-id', 'example/ctx01']
        with patch.object(self.demo, 'prepare_export'), \
                patch.object(self.demo, 'verify_assets', return_value=Path('/demo-data/assets')), \
                patch.object(Path, 'exists', return_value=False), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'is_file', return_value=True), \
                patch.object(Path, 'read_text', return_value=json.dumps({'success': True})), \
                patch.object(Path, 'mkdir'), \
                patch.object(self.demo.subprocess, 'run', side_effect=[
                    subprocess.CompletedProcess([], 0), subprocess.CompletedProcess([], 4)]), \
                contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as caught:
            self.demo.main(argv)
        self.assertEqual(caught.exception.code, 4)

    def test_demo_waits_for_successful_child_before_cpu_export(self):
        argv = ['--assets', '/demo-data/assets', '--output', '/demo-data/raw/new',
                '--cache', '/demo-data/cache', '--lerobot-output', '/demo-data/lerobot/new',
                '--lerobot-python', '/cpu-env/bin/python', '--repo-id', 'example/ctx01']
        with patch.object(self.demo, 'prepare_export'), \
                patch.object(self.demo, 'verify_assets', return_value=Path('/demo-data/assets')), \
                patch.object(Path, 'exists', return_value=False), \
                patch.object(Path, 'is_symlink', return_value=False), \
                patch.object(Path, 'is_file', return_value=True), \
                patch.object(Path, 'read_text', return_value=json.dumps({'success': True})), \
                patch.object(Path, 'mkdir'), \
                patch.object(self.demo.subprocess, 'run', side_effect=[
                    subprocess.CompletedProcess([], 0), subprocess.CompletedProcess([], 0)]) as run, \
                contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as caught:
            self.demo.main(argv)
        self.assertEqual(caught.exception.code, 0)
        self.assertEqual(run.call_count, 2)
        self.assertEqual(run.call_args_list[0].args[0][0], sys.executable)
        self.assertEqual(run.call_args_list[1].args[0][0], '/cpu-env/bin/python')
        self.assertEqual(run.call_args_list[1].kwargs['env']['CUDA_VISIBLE_DEVICES'], '')


if __name__ == '__main__':
    unittest.main()
